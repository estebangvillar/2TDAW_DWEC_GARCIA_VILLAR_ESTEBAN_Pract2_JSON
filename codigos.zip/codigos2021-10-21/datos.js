'use strict'
const usuarios = [
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "lara",
      "last": "birner"
    },
    "location": {
      "street": "schulweg 34",
      "city": "schwentinental",
      "state": "thüringen",
      "postcode": 20472,
      "coordinates": {
        "latitude": "-44.9293",
        "longitude": "166.1342"
      },
      "timezone": {
        "offset": "-3:00",
        "description": "Brazil, Buenos Aires, Georgetown"
      }
    },
    "email": "lara.birner@example.com",
    "login": {
      "uuid": "90155dcf-1fa0-4e4b-8663-bf09fca13975",
      "username": "brownpanda972",
      "password": "gopher",
      "salt": "0Pb3sSGA",
      "md5": "a95ec12fb40df57b8d09f530bac12d94",
      "sha1": "1b7acd6b111cb95c1218cafbcc9113bfbb4f7bf6",
      "sha256": "30ef78fef676dc8dbdd27555c0dc66ce30e529fb53fd39637549e06cbd5e9aae"
    },
    "dob": {
      "date": "1946-02-01T10:46:28Z",
      "age": 73
    },
    "registered": {
      "date": "2012-03-17T10:49:37Z",
      "age": 7
    },
    "phone": "0860-2543317",
    "cell": "0170-4999836",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/91.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/91.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/91.jpg"
    },
    "nat": "DE"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "ebbe",
      "last": "bilstad"
    },
    "location": {
      "street": "griniveien 3386",
      "city": "forland",
      "state": "trøndelag",
      "postcode": "6045",
      "coordinates": {
        "latitude": "-26.0435",
        "longitude": "-117.3776"
      },
      "timezone": {
        "offset": "-8:00",
        "description": "Pacific Time (US & Canada)"
      }
    },
    "email": "ebbe.bilstad@example.com",
    "login": {
      "uuid": "c07fefd5-a2c3-4312-842e-da0ec64ebf2d",
      "username": "blacksnake752",
      "password": "writer",
      "salt": "Pa4Vys3T",
      "md5": "2a7570a3f5a477b482739a56e0b666c3",
      "sha1": "21b4c82c88f56d1cd91a17c2c010c954855e4709",
      "sha256": "d9000aefdf070096b59dcd8d05fba3fca34da61282eac1c45986184415a02854"
    },
    "dob": {
      "date": "1960-05-10T20:50:31Z",
      "age": 59
    },
    "registered": {
      "date": "2014-01-13T11:26:48Z",
      "age": 5
    },
    "phone": "74958864",
    "cell": "94153626",
    "id": {
      "name": "FN",
      "value": "10056032423"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/93.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/93.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/93.jpg"
    },
    "nat": "NO"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "domínico",
      "last": "caldeira"
    },
    "location": {
      "street": "4280 rua três",
      "city": "foz do iguaçu",
      "state": "sergipe",
      "postcode": 43591,
      "coordinates": {
        "latitude": "40.5589",
        "longitude": "-72.9500"
      },
      "timezone": {
        "offset": "+2:00",
        "description": "Kaliningrad, South Africa"
      }
    },
    "email": "domínico.caldeira@example.com",
    "login": {
      "uuid": "bea7f8dd-a7b7-4185-a3a6-55a124186e5e",
      "username": "orangepanda720",
      "password": "wp2003wp",
      "salt": "ndA8OgsN",
      "md5": "b55fd8c7cb6f10da6f91a343f240e5d8",
      "sha1": "be6b65c48ac72222f6df8469ef5ec5326019bfce",
      "sha256": "5ef2fa04ff286d5ce24564551f0faf69ede35b0f240a78fe596e4edf6358d787"
    },
    "dob": {
      "date": "1971-07-09T08:29:59Z",
      "age": 48
    },
    "registered": {
      "date": "2003-06-12T14:32:27Z",
      "age": 16
    },
    "phone": "(83) 2812-1766",
    "cell": "(77) 6476-4570",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/59.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/59.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/59.jpg"
    },
    "nat": "BR"
  },
  {
    "gender": "female",
    "name": {
      "title": "ms",
      "first": "margot",
      "last": "garcia"
    },
    "location": {
      "street": "5694 rue abel-hovelacque",
      "city": "nancy",
      "state": "vosges",
      "postcode": 88812,
      "coordinates": {
        "latitude": "-22.8170",
        "longitude": "-100.4445"
      },
      "timezone": {
        "offset": "+4:30",
        "description": "Kabul"
      }
    },
    "email": "margot.garcia@example.com",
    "login": {
      "uuid": "16fa14af-8bb8-419d-84d2-42baacca7ca7",
      "username": "greenduck731",
      "password": "pian",
      "salt": "Yh4pavXa",
      "md5": "6f618a11d78ebffa15522967b3386d88",
      "sha1": "a4d55d30fcc874177c8777c436d098d3a9f78b8a",
      "sha256": "dfb3042e9818a12f3e4880e75222843f7c2b8495df771334ae85b5a31ad7e396"
    },
    "dob": {
      "date": "1966-06-30T03:16:41Z",
      "age": 53
    },
    "registered": {
      "date": "2008-01-17T17:52:25Z",
      "age": 11
    },
    "phone": "03-19-95-35-41",
    "cell": "06-36-76-33-26",
    "id": {
      "name": "INSEE",
      "value": "2NNaN72272796 75"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/7.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/7.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/7.jpg"
    },
    "nat": "FR"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "lea",
      "last": "walker"
    },
    "location": {
      "street": "2927 st. lawrence ave",
      "city": "selkirk",
      "state": "newfoundland and labrador",
      "postcode": "D1J 7O3",
      "coordinates": {
        "latitude": "13.4653",
        "longitude": "104.6506"
      },
      "timezone": {
        "offset": "-8:00",
        "description": "Pacific Time (US & Canada)"
      }
    },
    "email": "lea.walker@example.com",
    "login": {
      "uuid": "08fb5aa9-58fe-4c1e-805c-0b63b65182ff",
      "username": "bluebear804",
      "password": "cattle",
      "salt": "sdf6yeii",
      "md5": "cc303fef9b6720c402abd95bfa140242",
      "sha1": "00c4275ad685381506dfb1277598664a0377769b",
      "sha256": "1d6ed6368bdc2198619a2a2cb3a785f985488f5f5bb976ef3c89672c8d8f7069"
    },
    "dob": {
      "date": "1966-02-16T08:45:51Z",
      "age": 53
    },
    "registered": {
      "date": "2006-01-24T13:23:14Z",
      "age": 13
    },
    "phone": "036-722-7851",
    "cell": "936-424-5796",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/82.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/82.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/82.jpg"
    },
    "nat": "CA"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "nelson",
      "last": "gonzales"
    },
    "location": {
      "street": "6299 hunters creek dr",
      "city": "shepparton",
      "state": "queensland",
      "postcode": 7351,
      "coordinates": {
        "latitude": "15.5623",
        "longitude": "-69.1312"
      },
      "timezone": {
        "offset": "-4:00",
        "description": "Atlantic Time (Canada), Caracas, La Paz"
      }
    },
    "email": "nelson.gonzales@example.com",
    "login": {
      "uuid": "9726aba5-54ac-444b-8bfa-ca2fae124db5",
      "username": "blueladybug174",
      "password": "brown",
      "salt": "ifB7PkY1",
      "md5": "441e2f13c35d7f5ba044b3c580d18c67",
      "sha1": "21cced0769e38ca3fa2fa6242d7490a00454c2c1",
      "sha256": "f3e49fc5c909e2db207b8f628c7214dbce1fef5eb516ee10f011cf0c93cf81aa"
    },
    "dob": {
      "date": "1977-06-30T20:40:38Z",
      "age": 42
    },
    "registered": {
      "date": "2012-01-30T00:28:32Z",
      "age": 7
    },
    "phone": "05-2051-9933",
    "cell": "0482-558-429",
    "id": {
      "name": "TFN",
      "value": "258690759"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/48.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/48.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/48.jpg"
    },
    "nat": "AU"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "jayden",
      "last": "zhang"
    },
    "location": {
      "street": "8421 durham street",
      "city": "nelson",
      "state": "west coast",
      "postcode": 89763,
      "coordinates": {
        "latitude": "-34.4076",
        "longitude": "-71.3258"
      },
      "timezone": {
        "offset": "-2:00",
        "description": "Mid-Atlantic"
      }
    },
    "email": "jayden.zhang@example.com",
    "login": {
      "uuid": "01e61223-30c6-43d0-9ab4-4cd82f5a6479",
      "username": "beautifulwolf249",
      "password": "skater",
      "salt": "47y0HOKR",
      "md5": "339c65efbc812b90e91dc5756d53b171",
      "sha1": "14f68da7abfb9a3854c7fa319b44d0dacc6258f3",
      "sha256": "4997c8028402995de7404418d7cb9e8603beb689b9a5ce3998560d0b9f38dfe0"
    },
    "dob": {
      "date": "1983-05-02T15:34:07Z",
      "age": 36
    },
    "registered": {
      "date": "2018-05-14T22:33:38Z",
      "age": 1
    },
    "phone": "(737)-745-9630",
    "cell": "(471)-071-1109",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/72.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/72.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/72.jpg"
    },
    "nat": "NZ"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "diemer",
      "last": "sikkens"
    },
    "location": {
      "street": "2242 stadionlaan",
      "city": "leek",
      "state": "gelderland",
      "postcode": 53458,
      "coordinates": {
        "latitude": "49.8534",
        "longitude": "166.4957"
      },
      "timezone": {
        "offset": "+1:00",
        "description": "Brussels, Copenhagen, Madrid, Paris"
      }
    },
    "email": "diemer.sikkens@example.com",
    "login": {
      "uuid": "a226b950-2b54-4c6c-a021-7fa2cd237199",
      "username": "angryleopard257",
      "password": "cypress",
      "salt": "YA35Howc",
      "md5": "26cc3600caac06cb7fcdaa4bc37ddca7",
      "sha1": "c6b960e59399adb4c75145ef0db8e7eddd1feef0",
      "sha256": "44856cb98c8578a4357a0c9aa0c7211b9e6344307e8d516801b915698f28c196"
    },
    "dob": {
      "date": "1957-02-25T02:39:17Z",
      "age": 62
    },
    "registered": {
      "date": "2007-09-24T15:47:57Z",
      "age": 11
    },
    "phone": "(246)-185-8995",
    "cell": "(892)-799-2460",
    "id": {
      "name": "BSN",
      "value": "06701104"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/94.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/94.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/94.jpg"
    },
    "nat": "NL"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "augustin",
      "last": "ried"
    },
    "location": {
      "street": "eichenweg 140",
      "city": "breckerfeld",
      "state": "berlin",
      "postcode": 65335,
      "coordinates": {
        "latitude": "-2.3394",
        "longitude": "21.2983"
      },
      "timezone": {
        "offset": "+3:30",
        "description": "Tehran"
      }
    },
    "email": "augustin.ried@example.com",
    "login": {
      "uuid": "4082ee55-d388-4d74-a38d-9e0b8fbad28f",
      "username": "silverostrich187",
      "password": "shazam",
      "salt": "PUfjW6y6",
      "md5": "de46ae24fac280392cf930945a22b335",
      "sha1": "4edb2055bb3216091dc29754bb87c14f54526447",
      "sha256": "c3734f7825896e70ae2f6a8b7059774f73e8b5cc84f25d66a6c0f9432ee5900c"
    },
    "dob": {
      "date": "1950-03-23T23:26:00Z",
      "age": 69
    },
    "registered": {
      "date": "2018-03-28T00:48:44Z",
      "age": 1
    },
    "phone": "0918-4102639",
    "cell": "0179-7483664",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/15.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/15.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/15.jpg"
    },
    "nat": "DE"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "amado",
      "last": "monteiro"
    },
    "location": {
      "street": "3489 avenida da legalidade",
      "city": "belo horizonte",
      "state": "piauí",
      "postcode": 75250,
      "coordinates": {
        "latitude": "-18.3924",
        "longitude": "123.1862"
      },
      "timezone": {
        "offset": "+9:00",
        "description": "Tokyo, Seoul, Osaka, Sapporo, Yakutsk"
      }
    },
    "email": "amado.monteiro@example.com",
    "login": {
      "uuid": "38feef6f-8a9b-4d0e-abfb-c5bc78fa617c",
      "username": "happymeercat534",
      "password": "comfort",
      "salt": "zDTUjKTC",
      "md5": "df9680f51b0623cf08f85b2ae28d2bdd",
      "sha1": "381088d921c235eb18d244184f1fb3407e9d5054",
      "sha256": "1c46ec80161713f5895f8acfe24ad3e3d7db3ac3b705b515004d0a2e1a45dc22"
    },
    "dob": {
      "date": "1965-07-09T07:15:37Z",
      "age": 54
    },
    "registered": {
      "date": "2004-02-24T09:56:23Z",
      "age": 15
    },
    "phone": "(67) 4406-0344",
    "cell": "(32) 0059-1075",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/28.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/28.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/28.jpg"
    },
    "nat": "BR"
  },
  {
    "gender": "female",
    "name": {
      "title": "ms",
      "first": "sonia",
      "last": "gallardo"
    },
    "location": {
      "street": "9910 calle de arganzuela",
      "city": "las palmas de gran canaria",
      "state": "ceuta",
      "postcode": 35298,
      "coordinates": {
        "latitude": "-70.5252",
        "longitude": "-171.4720"
      },
      "timezone": {
        "offset": "+4:00",
        "description": "Abu Dhabi, Muscat, Baku, Tbilisi"
      }
    },
    "email": "sonia.gallardo@example.com",
    "login": {
      "uuid": "b2221fb1-3a73-4c75-bd6d-e8350408235f",
      "username": "tinyfish745",
      "password": "annabell",
      "salt": "r9UpqCqN",
      "md5": "679e3a2d8ba5a24bbd4fb3d6c6b13510",
      "sha1": "227bb1f3924f60b275b014a3d3c81e7e0d8d8826",
      "sha256": "1e06fe4032fab8f98701346614ccafcd9521c29f10d7b2d049323288f0f46e46"
    },
    "dob": {
      "date": "1968-10-11T16:09:57Z",
      "age": 50
    },
    "registered": {
      "date": "2010-05-20T08:16:43Z",
      "age": 9
    },
    "phone": "932-876-440",
    "cell": "681-083-788",
    "id": {
      "name": "DNI",
      "value": "12048638-I"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/52.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/52.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/52.jpg"
    },
    "nat": "ES"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "charles",
      "last": "barnaby"
    },
    "location": {
      "street": "5136 lakeview ave",
      "city": "killarney",
      "state": "québec",
      "postcode": "L8J 1E0",
      "coordinates": {
        "latitude": "-49.0776",
        "longitude": "-9.9566"
      },
      "timezone": {
        "offset": "+4:00",
        "description": "Abu Dhabi, Muscat, Baku, Tbilisi"
      }
    },
    "email": "charles.barnaby@example.com",
    "login": {
      "uuid": "92d8dff8-df3c-4ee3-a911-9c02317461b9",
      "username": "bluefrog529",
      "password": "lights",
      "salt": "5UitzwTi",
      "md5": "4d9ea045e6eb8f2db5f75c5f558834b9",
      "sha1": "39f1c71346158511528a9a82959e198afefc14e7",
      "sha256": "2bdce40a147a1eaea514f089e88a9f205d0b4b293fabb1949e62a5726e6615e6"
    },
    "dob": {
      "date": "1954-10-31T14:05:29Z",
      "age": 64
    },
    "registered": {
      "date": "2002-08-19T10:32:14Z",
      "age": 17
    },
    "phone": "044-391-1615",
    "cell": "992-042-1469",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/46.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/46.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/46.jpg"
    },
    "nat": "CA"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "jonas",
      "last": "jørgensen"
    },
    "location": {
      "street": "2505 poppelvænget",
      "city": "aarhus",
      "state": "nordjylland",
      "postcode": 91457,
      "coordinates": {
        "latitude": "5.8416",
        "longitude": "-87.2702"
      },
      "timezone": {
        "offset": "+3:30",
        "description": "Tehran"
      }
    },
    "email": "jonas.jørgensen@example.com",
    "login": {
      "uuid": "229ac12c-e6ec-4ca1-9f2f-2e710495fec6",
      "username": "yellowswan730",
      "password": "trojan",
      "salt": "rzqkkfvW",
      "md5": "9f5c8167b26b192486b1680ad8d17aa5",
      "sha1": "04c192b924313992a9c66db685a4cddb35e2faaf",
      "sha256": "fb1375fa0ab087d493cba415ac3b06ccf307d7a664de63388c50aa396cf73571"
    },
    "dob": {
      "date": "1989-01-17T13:41:05Z",
      "age": 30
    },
    "registered": {
      "date": "2017-03-07T07:57:50Z",
      "age": 2
    },
    "phone": "66024306",
    "cell": "14925937",
    "id": {
      "name": "CPR",
      "value": "969076-6464"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/34.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/34.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/34.jpg"
    },
    "nat": "DK"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "elias",
      "last": "wuori"
    },
    "location": {
      "street": "4724 otavalankatu",
      "city": "petäjävesi",
      "state": "ostrobothnia",
      "postcode": 38601,
      "coordinates": {
        "latitude": "61.4904",
        "longitude": "-71.7370"
      },
      "timezone": {
        "offset": "-2:00",
        "description": "Mid-Atlantic"
      }
    },
    "email": "elias.wuori@example.com",
    "login": {
      "uuid": "9a6b1419-e501-4ab6-bbb2-9b73697614ac",
      "username": "sadfish745",
      "password": "cream",
      "salt": "2L1rPqd3",
      "md5": "c628793e0d02ed12417704050606953c",
      "sha1": "41323ae7d337327b2783cb3c711ccebb368a2e4a",
      "sha256": "3ee2238ed652b17bce4442928e4398757f45b735777a4dd116b0f71476867efb"
    },
    "dob": {
      "date": "1979-10-16T02:11:30Z",
      "age": 39
    },
    "registered": {
      "date": "2005-12-04T21:15:53Z",
      "age": 13
    },
    "phone": "05-609-120",
    "cell": "041-500-21-61",
    "id": {
      "name": "HETU",
      "value": "NaNNA945undefined"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/17.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/17.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/17.jpg"
    },
    "nat": "FI"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "josep",
      "last": "arias"
    },
    "location": {
      "street": "4943 calle de alcalá",
      "city": "la palma",
      "state": "cataluña",
      "postcode": 89527,
      "coordinates": {
        "latitude": "-11.4976",
        "longitude": "-32.1204"
      },
      "timezone": {
        "offset": "+5:30",
        "description": "Bombay, Calcutta, Madras, New Delhi"
      }
    },
    "email": "josep.arias@example.com",
    "login": {
      "uuid": "1a066753-119e-420c-86ee-4d9f47744fb3",
      "username": "orangemouse610",
      "password": "hall",
      "salt": "799XcaMc",
      "md5": "5e111ee4e40ad8aac73ba859b07d615f",
      "sha1": "8194554ac32e6c7f8ba2d7b8f938792e8949c0d1",
      "sha256": "d104e09c7d7b5a32153c020f48ff8cf26d84c5b63356e7b1af683cf5754f64e8"
    },
    "dob": {
      "date": "1976-10-20T05:27:58Z",
      "age": 42
    },
    "registered": {
      "date": "2015-07-05T23:24:08Z",
      "age": 4
    },
    "phone": "972-780-681",
    "cell": "649-587-337",
    "id": {
      "name": "DNI",
      "value": "90774303-I"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/12.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/12.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/12.jpg"
    },
    "nat": "ES"
  },
  {
    "gender": "male",
    "name": {
      "title": "monsieur",
      "first": "chris",
      "last": "blanchard"
    },
    "location": {
      "street": "2441 rue baraban",
      "city": "wimmis",
      "state": "vaud",
      "postcode": 1637,
      "coordinates": {
        "latitude": "-41.6646",
        "longitude": "-15.1091"
      },
      "timezone": {
        "offset": "-5:00",
        "description": "Eastern Time (US & Canada), Bogota, Lima"
      }
    },
    "email": "chris.blanchard@example.com",
    "login": {
      "uuid": "4a1e4b78-863d-4ca7-a0c1-0d4bdd1316c9",
      "username": "greenswan796",
      "password": "logitech",
      "salt": "3hMcue1M",
      "md5": "95d48af0214b779f63f8354000672a99",
      "sha1": "271e20d74f43357760fd2baeed8c42df41d4e375",
      "sha256": "6b250e516040c076929f89ef016904048a6a312130fa5526f1213a395379051f"
    },
    "dob": {
      "date": "1992-05-15T03:32:59Z",
      "age": 27
    },
    "registered": {
      "date": "2007-10-25T16:20:12Z",
      "age": 11
    },
    "phone": "(200)-119-7561",
    "cell": "(630)-295-7433",
    "id": {
      "name": "AVS",
      "value": "756.5116.8487.76"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/68.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/68.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/68.jpg"
    },
    "nat": "CH"
  },
  {
    "gender": "male",
    "name": {
      "title": "monsieur",
      "first": "murat",
      "last": "colin"
    },
    "location": {
      "street": "7827 rue de l'abbé-gilconst",
      "city": "au (sg)",
      "state": "luzern",
      "postcode": 8940,
      "coordinates": {
        "latitude": "-25.0129",
        "longitude": "135.3500"
      },
      "timezone": {
        "offset": "+4:00",
        "description": "Abu Dhabi, Muscat, Baku, Tbilisi"
      }
    },
    "email": "murat.colin@example.com",
    "login": {
      "uuid": "52631989-7c4e-4c25-a5b2-83573071675e",
      "username": "whitefish859",
      "password": "oilers",
      "salt": "glQOiuCm",
      "md5": "06a6dfc652907bf9b759c682e787fd69",
      "sha1": "7a71065878e700d2824ce0266f6dbe0d9c35a117",
      "sha256": "e8b17047f670debf4f573531dfaf5d7053e58acd57ed26e9ee2947e3b1604692"
    },
    "dob": {
      "date": "1995-03-30T23:58:41Z",
      "age": 24
    },
    "registered": {
      "date": "2013-01-07T02:48:08Z",
      "age": 6
    },
    "phone": "(573)-276-8879",
    "cell": "(578)-549-9371",
    "id": {
      "name": "AVS",
      "value": "756.2852.8628.44"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/67.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/67.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/67.jpg"
    },
    "nat": "CH"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "victor",
      "last": "thomsen"
    },
    "location": {
      "street": "2683 brombærvej",
      "city": "aalborg s.ø.",
      "state": "sjælland",
      "postcode": 30935,
      "coordinates": {
        "latitude": "-65.6849",
        "longitude": "-118.5252"
      },
      "timezone": {
        "offset": "-3:30",
        "description": "Newfoundland"
      }
    },
    "email": "victor.thomsen@example.com",
    "login": {
      "uuid": "a29ff407-416b-4f7d-9331-516494a09e46",
      "username": "orangetiger582",
      "password": "animals",
      "salt": "2oIMEaHd",
      "md5": "a509c4b49a4a6173f4583a3f4d1259d0",
      "sha1": "64a7f7ff604ebfd2b6f091a8b1371bde975117f7",
      "sha256": "cc51d24ccda8a993e0ea97cb05383c26eb3bef475788c618b13b249f6485d1d2"
    },
    "dob": {
      "date": "1968-10-02T12:06:58Z",
      "age": 50
    },
    "registered": {
      "date": "2004-01-24T21:57:19Z",
      "age": 15
    },
    "phone": "82755093",
    "cell": "17417427",
    "id": {
      "name": "CPR",
      "value": "420259-8780"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/27.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/27.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/27.jpg"
    },
    "nat": "DK"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "faustino",
      "last": "vieira"
    },
    "location": {
      "street": "6865 avenida da legalidade",
      "city": "vitória da conquista",
      "state": "rondônia",
      "postcode": 12193,
      "coordinates": {
        "latitude": "-42.3187",
        "longitude": "-117.2551"
      },
      "timezone": {
        "offset": "-9:00",
        "description": "Alaska"
      }
    },
    "email": "faustino.vieira@example.com",
    "login": {
      "uuid": "215cefeb-de59-4a03-b61a-27e48e5bf9f0",
      "username": "blackladybug640",
      "password": "ou8122",
      "salt": "lilzNPEP",
      "md5": "584635e8912b79551acc0e61c9940f58",
      "sha1": "280448911c94fc3f2f044094ffdaccf8e9e0a90c",
      "sha256": "375f3d2a58ca5929ffaff1f06086c86c734043d165dc87b174234598107181a1"
    },
    "dob": {
      "date": "1997-03-12T21:21:35Z",
      "age": 22
    },
    "registered": {
      "date": "2009-11-15T21:58:08Z",
      "age": 9
    },
    "phone": "(01) 8653-4448",
    "cell": "(17) 1631-6095",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/0.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/0.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/0.jpg"
    },
    "nat": "BR"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "jon",
      "last": "rhodes"
    },
    "location": {
      "street": "5354 w pecan st",
      "city": "dayton",
      "state": "new hampshire",
      "postcode": 34252,
      "coordinates": {
        "latitude": "38.9014",
        "longitude": "67.6062"
      },
      "timezone": {
        "offset": "+7:00",
        "description": "Bangkok, Hanoi, Jakarta"
      }
    },
    "email": "jon.rhodes@example.com",
    "login": {
      "uuid": "a796724f-578a-485d-9d4a-40e4b4ba327a",
      "username": "sadbird768",
      "password": "tommyboy",
      "salt": "zLtMw2s5",
      "md5": "1ebf44e0b6b1b12a2fb82c31bfb2b6ae",
      "sha1": "08349f39350218be4cac576607f63c314b2c5bf0",
      "sha256": "968992d3cd1d848008406657e5fba78078804c40d7da4afcf06c39aac9b792ba"
    },
    "dob": {
      "date": "1980-11-05T18:01:54Z",
      "age": 38
    },
    "registered": {
      "date": "2018-03-01T21:08:23Z",
      "age": 1
    },
    "phone": "(091)-206-3170",
    "cell": "(001)-709-0102",
    "id": {
      "name": "SSN",
      "value": "774-02-1008"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/22.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/22.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/22.jpg"
    },
    "nat": "US"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "miguel",
      "last": "gonzalez"
    },
    "location": {
      "street": "2669 calle nebrija",
      "city": "orihuela",
      "state": "islas baleares",
      "postcode": 58624,
      "coordinates": {
        "latitude": "-87.5939",
        "longitude": "164.1883"
      },
      "timezone": {
        "offset": "-5:00",
        "description": "Eastern Time (US & Canada), Bogota, Lima"
      }
    },
    "email": "miguel.gonzalez@example.com",
    "login": {
      "uuid": "24038013-292e-4696-ba0b-7466efffc009",
      "username": "silvermouse883",
      "password": "africa",
      "salt": "FIOS0O77",
      "md5": "22be31603dfdbbc04c5e23d9096d6964",
      "sha1": "f5314064bcf33f1044131cbda5edd73de6bdb2ce",
      "sha256": "d50737975c0b79f7765078e11a72548739c6265f5975c010b9641e0c66830acd"
    },
    "dob": {
      "date": "1944-12-25T21:41:02Z",
      "age": 74
    },
    "registered": {
      "date": "2007-11-30T21:08:54Z",
      "age": 11
    },
    "phone": "910-981-632",
    "cell": "604-643-828",
    "id": {
      "name": "DNI",
      "value": "83370442-R"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/88.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/88.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/88.jpg"
    },
    "nat": "ES"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "ed",
      "last": "simpson"
    },
    "location": {
      "street": "6366 the avenue",
      "city": "sheffield",
      "state": "strathclyde",
      "postcode": "PX7Y 1LL",
      "coordinates": {
        "latitude": "-83.1014",
        "longitude": "-29.9015"
      },
      "timezone": {
        "offset": "-4:00",
        "description": "Atlantic Time (Canada), Caracas, La Paz"
      }
    },
    "email": "ed.simpson@example.com",
    "login": {
      "uuid": "8a99d2c3-cd0b-4d16-b9cb-55bf0bb76055",
      "username": "orangezebra518",
      "password": "duckie",
      "salt": "R7OP32uz",
      "md5": "3a9ce09fb3bee7ec87f19f5f515978df",
      "sha1": "b4f028eb420c29179c6eb2d86806b3b4186728b5",
      "sha256": "f51348c72dbdb331e898b0085985973f47d7f706d5afce4b77e7695690485525"
    },
    "dob": {
      "date": "1952-09-28T12:11:59Z",
      "age": 66
    },
    "registered": {
      "date": "2014-09-20T21:13:11Z",
      "age": 4
    },
    "phone": "015396 40327",
    "cell": "0777-018-825",
    "id": {
      "name": "NINO",
      "value": "YJ 37 37 92 Q"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/87.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/87.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/87.jpg"
    },
    "nat": "GB"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "hanne",
      "last": "kloth"
    },
    "location": {
      "street": "heideweg 41",
      "city": "papenburg",
      "state": "niedersachsen",
      "postcode": 73362,
      "coordinates": {
        "latitude": "-50.3427",
        "longitude": "-105.5754"
      },
      "timezone": {
        "offset": "-4:00",
        "description": "Atlantic Time (Canada), Caracas, La Paz"
      }
    },
    "email": "hanne.kloth@example.com",
    "login": {
      "uuid": "21436fef-e290-451d-985d-ce5a130022fb",
      "username": "sadmouse157",
      "password": "ruan",
      "salt": "CLzmX50B",
      "md5": "a2432525604050dec55a801b38eb5fef",
      "sha1": "600f45d6716d74a8a30874349dec38a286c0ef5f",
      "sha256": "633c1bb3e15e9bf3e3d341db372251a6b6e023d2d607dea2cd4b33c57b43a372"
    },
    "dob": {
      "date": "1981-07-22T12:12:27Z",
      "age": 38
    },
    "registered": {
      "date": "2007-03-16T18:27:53Z",
      "age": 12
    },
    "phone": "0723-3030633",
    "cell": "0176-1528457",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/1.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/1.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/1.jpg"
    },
    "nat": "DE"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "keith",
      "last": "hunt"
    },
    "location": {
      "street": "6489 valley view ln",
      "city": "wollongong",
      "state": "queensland",
      "postcode": 4805,
      "coordinates": {
        "latitude": "0.4034",
        "longitude": "71.4869"
      },
      "timezone": {
        "offset": "+11:00",
        "description": "Magadan, Solomon Islands, New Caledonia"
      }
    },
    "email": "keith.hunt@example.com",
    "login": {
      "uuid": "29413f8c-7658-423a-a7ec-ca33b29c806a",
      "username": "greenbird125",
      "password": "clark",
      "salt": "RQAKUECR",
      "md5": "f539aa6782ff522577d0a470700c191d",
      "sha1": "3810a3570e32aff8d27994726743800761af2728",
      "sha256": "01b8f2e01ef145ba950f5d4b20f7079524df2e5c402affbb662b83befff2dfac"
    },
    "dob": {
      "date": "1965-09-18T07:26:35Z",
      "age": 53
    },
    "registered": {
      "date": "2014-04-06T06:42:12Z",
      "age": 5
    },
    "phone": "00-9021-1319",
    "cell": "0416-131-965",
    "id": {
      "name": "TFN",
      "value": "728266763"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/34.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/34.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/34.jpg"
    },
    "nat": "AU"
  },
  {
    "gender": "female",
    "name": {
      "title": "ms",
      "first": "margarethe",
      "last": "frank"
    },
    "location": {
      "street": "marktplatz 68",
      "city": "bad wurzach",
      "state": "hessen",
      "postcode": 57610,
      "coordinates": {
        "latitude": "-72.5766",
        "longitude": "-110.6325"
      },
      "timezone": {
        "offset": "+5:45",
        "description": "Kathmandu"
      }
    },
    "email": "margarethe.frank@example.com",
    "login": {
      "uuid": "ba2573ae-4dfa-4ae9-864b-adcbf9bd96ef",
      "username": "ticklishdog248",
      "password": "bowtie",
      "salt": "eoKdeIYX",
      "md5": "0c63339a833ddfd4a0c008c011163eec",
      "sha1": "812dacb273f517954384afc5540ce9004959c169",
      "sha256": "5cdc164799d4dd0a9bc1f2ba1b48115ec28588c264f6ef4b96561f939d196ad9"
    },
    "dob": {
      "date": "1971-01-12T01:08:02Z",
      "age": 48
    },
    "registered": {
      "date": "2008-03-09T20:32:38Z",
      "age": 11
    },
    "phone": "0040-0477048",
    "cell": "0176-7292625",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/43.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/43.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/43.jpg"
    },
    "nat": "DE"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "thea",
      "last": "larsen"
    },
    "location": {
      "street": "7944 strandengen",
      "city": "ølstykke",
      "state": "sjælland",
      "postcode": 98759,
      "coordinates": {
        "latitude": "-33.1801",
        "longitude": "94.5275"
      },
      "timezone": {
        "offset": "+8:00",
        "description": "Beijing, Perth, Singapore, Hong Kong"
      }
    },
    "email": "thea.larsen@example.com",
    "login": {
      "uuid": "33d93db4-e775-45ff-8410-c3d38a708018",
      "username": "tinycat887",
      "password": "darrell",
      "salt": "BmMv9AdZ",
      "md5": "48beecfaee9abf951ac2491ae6981961",
      "sha1": "30daea28e6aa80f47889434ff71aca775fd5df79",
      "sha256": "c933aff95ea3cde2d5c5102ee82e14ad1bb29e9b5dbdce9a8cec7f31fa9c57c5"
    },
    "dob": {
      "date": "1954-03-18T12:37:52Z",
      "age": 65
    },
    "registered": {
      "date": "2011-08-01T05:08:41Z",
      "age": 8
    },
    "phone": "25809981",
    "cell": "67379579",
    "id": {
      "name": "CPR",
      "value": "898718-3530"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/27.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/27.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/27.jpg"
    },
    "nat": "DK"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "virginia",
      "last": "castro"
    },
    "location": {
      "street": "4314 calle de la luna",
      "city": "vitoria",
      "state": "navarra",
      "postcode": 74021,
      "coordinates": {
        "latitude": "70.8595",
        "longitude": "12.9892"
      },
      "timezone": {
        "offset": "-7:00",
        "description": "Mountain Time (US & Canada)"
      }
    },
    "email": "virginia.castro@example.com",
    "login": {
      "uuid": "714d3b98-1f61-4b61-b63b-74149edce016",
      "username": "organiccat608",
      "password": "gladiator",
      "salt": "dfnZleHc",
      "md5": "afed0d9e88456ccb53bc9208ea58d757",
      "sha1": "040459e5d895d8854736036307428e3bf9dd0fd5",
      "sha256": "2d57710a6980f84ccb9aaa54f5cf3263f31ec193d469ce40c41243112b75d3f3"
    },
    "dob": {
      "date": "1955-05-20T08:11:19Z",
      "age": 64
    },
    "registered": {
      "date": "2009-03-08T12:17:50Z",
      "age": 10
    },
    "phone": "939-377-694",
    "cell": "648-250-405",
    "id": {
      "name": "DNI",
      "value": "44885242-T"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/25.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/25.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/25.jpg"
    },
    "nat": "ES"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "sarah",
      "last": "taylor"
    },
    "location": {
      "street": "8153 great north road",
      "city": "tauranga",
      "state": "waikato",
      "postcode": 37936,
      "coordinates": {
        "latitude": "-22.1291",
        "longitude": "177.7298"
      },
      "timezone": {
        "offset": "-9:00",
        "description": "Alaska"
      }
    },
    "email": "sarah.taylor@example.com",
    "login": {
      "uuid": "1a0fc032-26aa-47aa-a79f-7002db95676d",
      "username": "greengorilla853",
      "password": "sapper",
      "salt": "tnnyVITn",
      "md5": "ac5387dd3a3827da67d5a8cd3019d986",
      "sha1": "27b10c834059f9fef34071009a5dcc0b9c894daa",
      "sha256": "00884d7ea7bd685ad614dcdf802667e7a2f4ad3b05dc467acc4db96b0d0de427"
    },
    "dob": {
      "date": "1981-07-30T06:40:30Z",
      "age": 38
    },
    "registered": {
      "date": "2003-11-03T01:40:50Z",
      "age": 15
    },
    "phone": "(847)-474-7644",
    "cell": "(411)-320-1837",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/8.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/8.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/8.jpg"
    },
    "nat": "NZ"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "corina",
      "last": "jordan"
    },
    "location": {
      "street": "schulweg 139",
      "city": "annweiler am trifels",
      "state": "rheinland-pfalz",
      "postcode": 33663,
      "coordinates": {
        "latitude": "-66.3619",
        "longitude": "90.8469"
      },
      "timezone": {
        "offset": "+5:00",
        "description": "Ekaterinburg, Islamabad, Karachi, Tashkent"
      }
    },
    "email": "corina.jordan@example.com",
    "login": {
      "uuid": "2b51b0e9-f58c-4d8e-b946-9595d4eeb0ba",
      "username": "whiteostrich238",
      "password": "636363",
      "salt": "4GvRxOAT",
      "md5": "3f5dac98990ac2e322718a87d410f252",
      "sha1": "46230383e3e85eb1aad94b0b03408f8fea3818fa",
      "sha256": "2afa5ddaccd84d8c67d8192b023f75377fc16a463edd086fa28a63016f7b234b"
    },
    "dob": {
      "date": "1951-01-02T17:15:11Z",
      "age": 68
    },
    "registered": {
      "date": "2004-01-19T21:26:16Z",
      "age": 15
    },
    "phone": "0298-1903040",
    "cell": "0178-5979217",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/3.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/3.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/3.jpg"
    },
    "nat": "DE"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "ana",
      "last": "mitchelle"
    },
    "location": {
      "street": "1466 pecan acres ln",
      "city": "maitland",
      "state": "new south wales",
      "postcode": 7090,
      "coordinates": {
        "latitude": "86.7300",
        "longitude": "-100.1075"
      },
      "timezone": {
        "offset": "-12:00",
        "description": "Eniwetok, Kwajalein"
      }
    },
    "email": "ana.mitchelle@example.com",
    "login": {
      "uuid": "0f241a42-c100-42b0-a121-4bb703101e66",
      "username": "bluepeacock783",
      "password": "martini",
      "salt": "xIep6R4I",
      "md5": "00fad1949dafa3b6ba5e69cf30094c5b",
      "sha1": "3d01004fa8393f3a43cd803d366b29c8db806960",
      "sha256": "4900ef367c841fb49a46943868b7257ff2949451d4aba14d8d4141852d750b7e"
    },
    "dob": {
      "date": "1968-05-29T10:56:53Z",
      "age": 51
    },
    "registered": {
      "date": "2014-08-05T20:03:39Z",
      "age": 5
    },
    "phone": "04-7391-2097",
    "cell": "0433-015-177",
    "id": {
      "name": "TFN",
      "value": "345691062"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/60.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/60.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/60.jpg"
    },
    "nat": "AU"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "ortwin",
      "last": "hoffmeister"
    },
    "location": {
      "street": "lessingstraße 179",
      "city": "neresheim",
      "state": "saarland",
      "postcode": 42810,
      "coordinates": {
        "latitude": "48.8053",
        "longitude": "-49.8169"
      },
      "timezone": {
        "offset": "+8:00",
        "description": "Beijing, Perth, Singapore, Hong Kong"
      }
    },
    "email": "ortwin.hoffmeister@example.com",
    "login": {
      "uuid": "34e9b888-abfa-4ff1-8ad0-5e21ed1a5407",
      "username": "lazyzebra154",
      "password": "winnie",
      "salt": "4srQxpPA",
      "md5": "3d6de3d7820258846176426282875c44",
      "sha1": "0986787e154669538c16fa4b402df9a89205e907",
      "sha256": "7404982c4eac03caa655d84bc255f32ca97b2da084c2f64ef02aa01645f2f333"
    },
    "dob": {
      "date": "1978-12-16T12:54:48Z",
      "age": 40
    },
    "registered": {
      "date": "2016-06-24T16:06:19Z",
      "age": 3
    },
    "phone": "0406-2252363",
    "cell": "0178-9128346",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/8.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/8.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/8.jpg"
    },
    "nat": "DE"
  },
  {
    "gender": "female",
    "name": {
      "title": "ms",
      "first": "ugne",
      "last": "helmersen"
    },
    "location": {
      "street": "østvangveien 4815",
      "city": "snurråsen",
      "state": "vest-agder",
      "postcode": "2034",
      "coordinates": {
        "latitude": "27.7707",
        "longitude": "-30.3132"
      },
      "timezone": {
        "offset": "-11:00",
        "description": "Midway Island, Samoa"
      }
    },
    "email": "ugne.helmersen@example.com",
    "login": {
      "uuid": "5d4ed55c-0764-4a85-8d4a-dcd4beaaed56",
      "username": "goldenfish664",
      "password": "jughead",
      "salt": "Vdl95lT6",
      "md5": "51365dbddbd5d232a13f854106a7bf63",
      "sha1": "0a8c5245873994d449dc4297f82daa8d706f4b54",
      "sha256": "906bc264f7f5c322de84c65d54df58fbdb94b445b1ff70f2106442c36f9dc01c"
    },
    "dob": {
      "date": "1995-09-17T06:14:02Z",
      "age": 23
    },
    "registered": {
      "date": "2003-03-03T17:13:43Z",
      "age": 16
    },
    "phone": "66689798",
    "cell": "98736435",
    "id": {
      "name": "FN",
      "value": "17099527188"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/30.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/30.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/30.jpg"
    },
    "nat": "NO"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "andrew",
      "last": "robinson"
    },
    "location": {
      "street": "5551 daisy dr",
      "city": "kalgoorlie",
      "state": "northern territory",
      "postcode": 7280,
      "coordinates": {
        "latitude": "-33.3323",
        "longitude": "16.3110"
      },
      "timezone": {
        "offset": "+5:30",
        "description": "Bombay, Calcutta, Madras, New Delhi"
      }
    },
    "email": "andrew.robinson@example.com",
    "login": {
      "uuid": "f72ced5b-c025-4e84-bd00-38070f5bc0f3",
      "username": "lazybear914",
      "password": "chambers",
      "salt": "12MtzFnS",
      "md5": "f765c1c4246305703ee8acdee10fa8a2",
      "sha1": "b995f959481d85447e7947ed69a4e7c108c30f59",
      "sha256": "1abbe287ad8b125229cead1ca4607d836e39d07de9c842fc78522c45311bf33b"
    },
    "dob": {
      "date": "1948-11-15T03:13:27Z",
      "age": 70
    },
    "registered": {
      "date": "2008-09-02T01:18:45Z",
      "age": 11
    },
    "phone": "01-3676-2786",
    "cell": "0489-868-300",
    "id": {
      "name": "TFN",
      "value": "764261962"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/35.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/35.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/35.jpg"
    },
    "nat": "AU"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "elias",
      "last": "pakkala"
    },
    "location": {
      "street": "9388 otavalankatu",
      "city": "kuopio",
      "state": "tavastia proper",
      "postcode": 96104,
      "coordinates": {
        "latitude": "61.0029",
        "longitude": "64.7507"
      },
      "timezone": {
        "offset": "-5:00",
        "description": "Eastern Time (US & Canada), Bogota, Lima"
      }
    },
    "email": "elias.pakkala@example.com",
    "login": {
      "uuid": "68435104-6ebd-4257-8966-2a781d5dd605",
      "username": "silverdog218",
      "password": "serious",
      "salt": "OETu0nJ7",
      "md5": "67b4ff9d24019a4c6476a6b5acfc01c1",
      "sha1": "da6c1ffb327976b838d79c3dd8e41b75044088e9",
      "sha256": "258cc0017d3a5dd65d716861162a929a55516e827afdd10c162f093eebebe272"
    },
    "dob": {
      "date": "1972-04-18T06:30:26Z",
      "age": 47
    },
    "registered": {
      "date": "2011-11-10T12:15:34Z",
      "age": 7
    },
    "phone": "05-056-970",
    "cell": "047-786-81-60",
    "id": {
      "name": "HETU",
      "value": "NaNNA913undefined"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/73.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/73.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/73.jpg"
    },
    "nat": "FI"
  },
  {
    "gender": "male",
    "name": {
      "title": "monsieur",
      "first": "bojan",
      "last": "gautier"
    },
    "location": {
      "street": "1465 rue pierre-delore",
      "city": "boningen",
      "state": "basel-landschaft",
      "postcode": 4892,
      "coordinates": {
        "latitude": "-45.3290",
        "longitude": "94.4150"
      },
      "timezone": {
        "offset": "-1:00",
        "description": "Azores, Cape Verde Islands"
      }
    },
    "email": "bojan.gautier@example.com",
    "login": {
      "uuid": "6c310500-3240-477b-a750-075d64e07bfd",
      "username": "purpleladybug319",
      "password": "skyline",
      "salt": "Wji7RFXl",
      "md5": "53a829533bf0c5f034847b985b0eac86",
      "sha1": "2eb97deaf3a1058cf52fc46dc4a5493c70c0d795",
      "sha256": "6d688c72ce941aa20be29e729a408a2aea0cf7abfe2df4f682a648a33a3828d2"
    },
    "dob": {
      "date": "1982-10-22T16:38:45Z",
      "age": 36
    },
    "registered": {
      "date": "2009-09-05T08:07:57Z",
      "age": 10
    },
    "phone": "(129)-260-2236",
    "cell": "(822)-892-2210",
    "id": {
      "name": "AVS",
      "value": "756.1782.7646.08"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/83.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/83.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/83.jpg"
    },
    "nat": "CH"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "fatma",
      "last": "akyürek"
    },
    "location": {
      "street": "2023 necatibey cd",
      "city": "bayburt",
      "state": "kastamonu",
      "postcode": 27788,
      "coordinates": {
        "latitude": "-48.3661",
        "longitude": "44.5093"
      },
      "timezone": {
        "offset": "+1:00",
        "description": "Brussels, Copenhagen, Madrid, Paris"
      }
    },
    "email": "fatma.akyürek@example.com",
    "login": {
      "uuid": "5ead7ee6-58cb-4873-bbc1-2dd48551e32e",
      "username": "greentiger815",
      "password": "newcastl",
      "salt": "6JYibyt6",
      "md5": "58ad50d1cd1a4eed144a4fe9569dad34",
      "sha1": "96d2720747f9414f1de7b6cabc5df5f63d9e0882",
      "sha256": "234038330d6ec6159e19c23705b5682625ddb0a4d3ed84800480d1fc65cac10c"
    },
    "dob": {
      "date": "1989-10-07T03:00:24Z",
      "age": 29
    },
    "registered": {
      "date": "2013-12-22T14:37:30Z",
      "age": 5
    },
    "phone": "(615)-677-6308",
    "cell": "(948)-588-8323",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/59.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/59.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/59.jpg"
    },
    "nat": "TR"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "hendrica",
      "last": "langeveld"
    },
    "location": {
      "street": "334 waterlinieweg",
      "city": "veldhoven",
      "state": "drenthe",
      "postcode": 15017,
      "coordinates": {
        "latitude": "-44.6073",
        "longitude": "48.1547"
      },
      "timezone": {
        "offset": "+5:30",
        "description": "Bombay, Calcutta, Madras, New Delhi"
      }
    },
    "email": "hendrica.langeveld@example.com",
    "login": {
      "uuid": "3da42a01-d906-4892-9ebe-36665f8d9ce5",
      "username": "ticklishpeacock480",
      "password": "hawkeyes",
      "salt": "SufG3vvj",
      "md5": "af228ee06bcb42af26072d061acbdc40",
      "sha1": "7fa6e90ce5004e9165fb627cf2a868bdeff260d2",
      "sha256": "393b2ef4048a8e42b1649aa78531d1637f54e2a8b03741b2721842028cb3ddb2"
    },
    "dob": {
      "date": "1966-08-11T09:02:41Z",
      "age": 53
    },
    "registered": {
      "date": "2014-11-26T15:15:46Z",
      "age": 4
    },
    "phone": "(192)-210-5643",
    "cell": "(236)-888-3171",
    "id": {
      "name": "BSN",
      "value": "70566203"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/21.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/21.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/21.jpg"
    },
    "nat": "NL"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "emilia",
      "last": "hokkanen"
    },
    "location": {
      "street": "7808 visiokatu",
      "city": "utajärvi",
      "state": "åland",
      "postcode": 84473,
      "coordinates": {
        "latitude": "-35.1774",
        "longitude": "94.6580"
      },
      "timezone": {
        "offset": "+5:30",
        "description": "Bombay, Calcutta, Madras, New Delhi"
      }
    },
    "email": "emilia.hokkanen@example.com",
    "login": {
      "uuid": "5cf394e6-744a-46a8-b796-3cef6cba1b40",
      "username": "goldendog406",
      "password": "toni",
      "salt": "iDKsC7cE",
      "md5": "bded93840ec2580872925f01dd7c380d",
      "sha1": "7044b77c62f3cc84186cf86024379b3ba2ca8645",
      "sha256": "eadf12f968dd4600bf1eed9cca0678ad676d5401693c5850c9a3f010650b6e02"
    },
    "dob": {
      "date": "1961-02-15T04:02:40Z",
      "age": 58
    },
    "registered": {
      "date": "2003-10-12T04:04:16Z",
      "age": 15
    },
    "phone": "02-234-021",
    "cell": "044-170-73-67",
    "id": {
      "name": "HETU",
      "value": "NaNNA726undefined"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/83.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/83.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/83.jpg"
    },
    "nat": "FI"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "oskari",
      "last": "arola"
    },
    "location": {
      "street": "7062 tehtaankatu",
      "city": "pälkäne",
      "state": "lapland",
      "postcode": 80255,
      "coordinates": {
        "latitude": "49.8802",
        "longitude": "-77.5788"
      },
      "timezone": {
        "offset": "+3:30",
        "description": "Tehran"
      }
    },
    "email": "oskari.arola@example.com",
    "login": {
      "uuid": "65151a64-a293-4e69-b302-97f7df66ba69",
      "username": "lazyostrich376",
      "password": "drake",
      "salt": "ikbGGGO0",
      "md5": "31db66b57d43199ce02e5314cb933ffb",
      "sha1": "c15d5455a67325b5e833d49f629b943e9ecd5edc",
      "sha256": "cd8d54851af7897d5bfe185ba5335c07c41bede13ed9b222a5c0eb1430d5c8d9"
    },
    "dob": {
      "date": "1990-03-07T11:45:59Z",
      "age": 29
    },
    "registered": {
      "date": "2015-08-15T12:59:35Z",
      "age": 4
    },
    "phone": "09-701-103",
    "cell": "048-353-11-59",
    "id": {
      "name": "HETU",
      "value": "NaNNA627undefined"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/15.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/15.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/15.jpg"
    },
    "nat": "FI"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "kylian",
      "last": "fontai"
    },
    "location": {
      "street": "1587 rue duguesclin",
      "city": "besançon",
      "state": "seine-et-marne",
      "postcode": 47335,
      "coordinates": {
        "latitude": "45.5910",
        "longitude": "-3.0419"
      },
      "timezone": {
        "offset": "+9:30",
        "description": "Adelaide, Darwin"
      }
    },
    "email": "kylian.fontai@example.com",
    "login": {
      "uuid": "7b35006b-51f1-4412-92f2-a262f99c4e39",
      "username": "browntiger259",
      "password": "christ",
      "salt": "SCwlyaxT",
      "md5": "9d7e188ec9f54a9089ee16854afd498f",
      "sha1": "6ac0d5df3c36d3d8dd53552313839ff836d0807d",
      "sha256": "8e5dcd5ab60e3fa3bd3611a3db45baa53b1e746166a5f779ca43fd14ca874563"
    },
    "dob": {
      "date": "1980-04-24T16:06:10Z",
      "age": 39
    },
    "registered": {
      "date": "2015-04-06T05:39:10Z",
      "age": 4
    },
    "phone": "05-02-38-28-71",
    "cell": "06-24-37-45-27",
    "id": {
      "name": "INSEE",
      "value": "1NNaN78164950 31"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/3.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/3.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/3.jpg"
    },
    "nat": "FR"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "elijah",
      "last": "gomez"
    },
    "location": {
      "street": "2508 adams st",
      "city": "toowoomba",
      "state": "new south wales",
      "postcode": 9227,
      "coordinates": {
        "latitude": "19.0238",
        "longitude": "105.4508"
      },
      "timezone": {
        "offset": "+7:00",
        "description": "Bangkok, Hanoi, Jakarta"
      }
    },
    "email": "elijah.gomez@example.com",
    "login": {
      "uuid": "b57a4ba3-fb79-4168-9390-18cc2d227570",
      "username": "goldenzebra828",
      "password": "airborne",
      "salt": "2dcp05Kt",
      "md5": "887db27d1062058e13611c6798599a63",
      "sha1": "653184dabf7cb884688abbe4776289300d83d4ef",
      "sha256": "3d0285732849113f8264377a59860561ed1fa7ada7061458cc9f5a2e12231f94"
    },
    "dob": {
      "date": "1987-06-13T22:42:43Z",
      "age": 32
    },
    "registered": {
      "date": "2004-07-23T08:13:41Z",
      "age": 15
    },
    "phone": "05-4348-5472",
    "cell": "0454-330-269",
    "id": {
      "name": "TFN",
      "value": "522414048"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/32.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/32.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/32.jpg"
    },
    "nat": "AU"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "عرشيا",
      "last": "رضایی"
    },
    "location": {
      "street": "1717 دستغیب",
      "city": "ملارد",
      "state": "فارس",
      "postcode": 27381,
      "coordinates": {
        "latitude": "-1.7681",
        "longitude": "-144.0666"
      },
      "timezone": {
        "offset": "+5:00",
        "description": "Ekaterinburg, Islamabad, Karachi, Tashkent"
      }
    },
    "email": "عرشيا.رضایی@example.com",
    "login": {
      "uuid": "06cc07ea-b4f3-4b48-959f-63dccfbf73a5",
      "username": "beautifulfrog883",
      "password": "burger",
      "salt": "kdDtGqd1",
      "md5": "1e0196f82033079c179e3d6dc8716900",
      "sha1": "9d7800d28d5ef43f22c3735345f77c6807485951",
      "sha256": "42677e4834d873a8ef74ab91e5f7a18cfe24ebfe44ffe0639a1aa4e98b31288c"
    },
    "dob": {
      "date": "1964-09-11T20:41:23Z",
      "age": 54
    },
    "registered": {
      "date": "2016-05-27T04:02:08Z",
      "age": 3
    },
    "phone": "090-14798356",
    "cell": "0975-083-2286",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/33.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/33.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/33.jpg"
    },
    "nat": "IR"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "ایلیا",
      "last": "موسوی"
    },
    "location": {
      "street": "2338 شهید شهرام امیری",
      "city": "خوی",
      "state": "فارس",
      "postcode": 81534,
      "coordinates": {
        "latitude": "85.8923",
        "longitude": "-25.4819"
      },
      "timezone": {
        "offset": "+6:00",
        "description": "Almaty, Dhaka, Colombo"
      }
    },
    "email": "ایلیا.موسوی@example.com",
    "login": {
      "uuid": "1d4e1d29-448e-40ef-92ac-5bf9bfdecc1c",
      "username": "lazyleopard350",
      "password": "dirk",
      "salt": "Xo14bICz",
      "md5": "52115469835f1296cbf354f35f178fbc",
      "sha1": "bf569734bd205dbc827ab2dcd650d63a25546e3b",
      "sha256": "487c98b21cacc0e93e1e1e1dd8e6acfa6dbef5a720438297b0cd4ec83fba4881"
    },
    "dob": {
      "date": "1978-08-25T05:46:59Z",
      "age": 41
    },
    "registered": {
      "date": "2003-01-24T16:37:36Z",
      "age": 16
    },
    "phone": "061-22725721",
    "cell": "0992-092-6465",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/35.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/35.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/35.jpg"
    },
    "nat": "IR"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "amy",
      "last": "osullivan"
    },
    "location": {
      "street": "7104 pearse street",
      "city": "longford",
      "state": "cork",
      "postcode": 33022,
      "coordinates": {
        "latitude": "-23.9018",
        "longitude": "2.0049"
      },
      "timezone": {
        "offset": "-4:00",
        "description": "Atlantic Time (Canada), Caracas, La Paz"
      }
    },
    "email": "amy.osullivan@example.com",
    "login": {
      "uuid": "516bf212-68fd-4b11-bd31-8069293644e4",
      "username": "beautifulgoose433",
      "password": "iscool",
      "salt": "wk9lJiMn",
      "md5": "cced1d4f7ac57a68588425a9554fc402",
      "sha1": "6933411ac0d679404e728d982bc6132d54ccedd3",
      "sha256": "0f0b45c565326ac2438ad7c7ce5ed9c204b757238a88e839db5271f7e9ac0acd"
    },
    "dob": {
      "date": "1954-09-03T02:34:13Z",
      "age": 65
    },
    "registered": {
      "date": "2007-12-01T05:32:15Z",
      "age": 11
    },
    "phone": "071-666-6005",
    "cell": "081-191-7595",
    "id": {
      "name": "PPS",
      "value": "8435658T"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/89.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/89.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/89.jpg"
    },
    "nat": "IE"
  },
  {
    "gender": "female",
    "name": {
      "title": "ms",
      "first": "thea",
      "last": "christiansen"
    },
    "location": {
      "street": "7710 klydevej",
      "city": "noerre alslev",
      "state": "sjælland",
      "postcode": 58636,
      "coordinates": {
        "latitude": "47.4988",
        "longitude": "92.6885"
      },
      "timezone": {
        "offset": "+11:00",
        "description": "Magadan, Solomon Islands, New Caledonia"
      }
    },
    "email": "thea.christiansen@example.com",
    "login": {
      "uuid": "ae77d481-7087-46de-9474-cdedb72d5cd4",
      "username": "smallgorilla144",
      "password": "laura1",
      "salt": "EXUoOHF8",
      "md5": "f56d9085d36b7f94b451bdcdafc1f379",
      "sha1": "8bc110780cf3f410ccddc7eeff84501004b1c567",
      "sha256": "0bdce2a9954fbfe09da62991cc0c608b12b0cbc66250529eca31c35ad2e840bd"
    },
    "dob": {
      "date": "1994-12-08T18:01:16Z",
      "age": 24
    },
    "registered": {
      "date": "2006-03-18T09:24:58Z",
      "age": 13
    },
    "phone": "53006933",
    "cell": "17353762",
    "id": {
      "name": "CPR",
      "value": "113402-6924"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/96.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/96.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/96.jpg"
    },
    "nat": "DK"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "mark",
      "last": "hamilton"
    },
    "location": {
      "street": "873 highfield road",
      "city": "kinsale",
      "state": "dún laoghaire–rathdown",
      "postcode": 28813,
      "coordinates": {
        "latitude": "-33.3751",
        "longitude": "-101.7397"
      },
      "timezone": {
        "offset": "-5:00",
        "description": "Eastern Time (US & Canada), Bogota, Lima"
      }
    },
    "email": "mark.hamilton@example.com",
    "login": {
      "uuid": "36c8b3c6-6db1-41d6-b6b7-ca767215302d",
      "username": "redbutterfly643",
      "password": "sadie",
      "salt": "8Ly8Xa0Z",
      "md5": "3b2a4bf6b3ea28ef8ed70c7ce7e254f9",
      "sha1": "bb00349ed212ebfdfe84eb3ae7c4181bf03c6e31",
      "sha256": "c22673b89b9816ad89e1a3444cf89ab943b3fc19924d49ebaf336c09a260d460"
    },
    "dob": {
      "date": "1966-05-24T04:33:48Z",
      "age": 53
    },
    "registered": {
      "date": "2008-02-21T13:02:44Z",
      "age": 11
    },
    "phone": "021-832-3336",
    "cell": "081-924-7977",
    "id": {
      "name": "PPS",
      "value": "1075344T"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/34.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/34.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/34.jpg"
    },
    "nat": "IE"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "albin",
      "last": "svingen"
    },
    "location": {
      "street": "sandåsveien 9052",
      "city": "forland",
      "state": "sogn og fjordane",
      "postcode": "7751",
      "coordinates": {
        "latitude": "-18.2912",
        "longitude": "92.0448"
      },
      "timezone": {
        "offset": "+1:00",
        "description": "Brussels, Copenhagen, Madrid, Paris"
      }
    },
    "email": "albin.svingen@example.com",
    "login": {
      "uuid": "4e364bce-0a4e-485b-aa6b-0ea21103fe2f",
      "username": "blackelephant488",
      "password": "surprise",
      "salt": "5jvSSmHx",
      "md5": "ef74cf09e014f6ff819d32f454604d70",
      "sha1": "f6e2f03fe1427c0f4f8445c866e7dc13bf27db32",
      "sha256": "e4b2d11fa55efffd39b0c0187bacece67586efc90743e5c43b30179e4e5c0199"
    },
    "dob": {
      "date": "1952-01-29T14:17:34Z",
      "age": 67
    },
    "registered": {
      "date": "2002-11-29T21:56:29Z",
      "age": 16
    },
    "phone": "25889364",
    "cell": "42713004",
    "id": {
      "name": "FN",
      "value": "29015246292"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/44.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/44.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/44.jpg"
    },
    "nat": "NO"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "abdullah",
      "last": "ehrenberg"
    },
    "location": {
      "street": "kiefernweg 178",
      "city": "aurich",
      "state": "berlin",
      "postcode": 37326,
      "coordinates": {
        "latitude": "-88.7726",
        "longitude": "-54.7166"
      },
      "timezone": {
        "offset": "-11:00",
        "description": "Midway Island, Samoa"
      }
    },
    "email": "abdullah.ehrenberg@example.com",
    "login": {
      "uuid": "060e8fbf-43cb-40b0-9404-98396814ebe8",
      "username": "redladybug393",
      "password": "abcdefg",
      "salt": "OPvjKAdL",
      "md5": "ec6db72d226b17ab059825e158f9d52a",
      "sha1": "a630fca4c587f5be7e1269809356eb531c76b248",
      "sha256": "d549132d2ba03099db3474c3a05f0ad75157830e5aa7d71c571ecf22b69c1032"
    },
    "dob": {
      "date": "1953-10-30T13:46:17Z",
      "age": 65
    },
    "registered": {
      "date": "2016-12-05T19:34:48Z",
      "age": 2
    },
    "phone": "0566-9244986",
    "cell": "0170-8609041",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/13.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/13.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/13.jpg"
    },
    "nat": "DE"
  },
  {
    "gender": "female",
    "name": {
      "title": "madame",
      "first": "yael",
      "last": "fabre"
    },
    "location": {
      "street": "1949 place du 8 février 1962",
      "city": "gsteig",
      "state": "bern",
      "postcode": 8949,
      "coordinates": {
        "latitude": "14.6650",
        "longitude": "-108.6854"
      },
      "timezone": {
        "offset": "-12:00",
        "description": "Eniwetok, Kwajalein"
      }
    },
    "email": "yael.fabre@example.com",
    "login": {
      "uuid": "cc7c97b4-f230-4ec5-8128-2bb578bf21a3",
      "username": "blackbear599",
      "password": "nimrod",
      "salt": "IagyrPus",
      "md5": "e561cf3f5fbd1ca988e2bc6653fa1d49",
      "sha1": "85477eb1751470aeaa22fb2883910b61df6c65aa",
      "sha256": "65b7328fa5b9edf5f0937773814e6dd07c392e7526556cef466a313c0ccf5da1"
    },
    "dob": {
      "date": "1981-04-23T21:55:14Z",
      "age": 38
    },
    "registered": {
      "date": "2018-04-16T14:36:14Z",
      "age": 1
    },
    "phone": "(697)-034-7336",
    "cell": "(965)-426-4954",
    "id": {
      "name": "AVS",
      "value": "756.9950.0576.83"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/26.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/26.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/26.jpg"
    },
    "nat": "CH"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "bendik",
      "last": "dyrhaug"
    },
    "location": {
      "street": "nycoveien 1796",
      "city": "neslandsvatn",
      "state": "oppland",
      "postcode": "0318",
      "coordinates": {
        "latitude": "36.5545",
        "longitude": "-127.2242"
      },
      "timezone": {
        "offset": "+2:00",
        "description": "Kaliningrad, South Africa"
      }
    },
    "email": "bendik.dyrhaug@example.com",
    "login": {
      "uuid": "43b5d399-b5e4-44b6-ba6f-8f0ae1709348",
      "username": "orangedog140",
      "password": "maestro",
      "salt": "aweQAf6G",
      "md5": "8fc1ef9f359780391efbba6c2e9dd948",
      "sha1": "1b85d11a5f9216e36ca5b7c0a5c5b3a86a6b1f02",
      "sha256": "c4d81c5c20575bba71bc34f7ad5f381c2ab83aebc9ac8b1fca967549aa545ffb"
    },
    "dob": {
      "date": "1993-09-09T18:40:11Z",
      "age": 25
    },
    "registered": {
      "date": "2006-11-18T07:28:44Z",
      "age": 12
    },
    "phone": "38831722",
    "cell": "45921395",
    "id": {
      "name": "FN",
      "value": "09099317423"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/29.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/29.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/29.jpg"
    },
    "nat": "NO"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "gonca",
      "last": "avan"
    },
    "location": {
      "street": "7996 anafartalar cd",
      "city": "batman",
      "state": "siirt",
      "postcode": 54405,
      "coordinates": {
        "latitude": "-40.6979",
        "longitude": "-65.7193"
      },
      "timezone": {
        "offset": "-11:00",
        "description": "Midway Island, Samoa"
      }
    },
    "email": "gonca.avan@example.com",
    "login": {
      "uuid": "a5df33d5-7aec-49f5-b0ef-be2c02fe3be7",
      "username": "purplegorilla170",
      "password": "mouse1",
      "salt": "oE7BbRzc",
      "md5": "955d7813a2a3808040810b0f9aac59e0",
      "sha1": "cf6e4ce27a838013a7537d6a4c168c46416b2fe4",
      "sha256": "89470d50a8454d0eca25c45839b87bff53f816a9d50de5f1faca06fecc3f136e"
    },
    "dob": {
      "date": "1972-03-12T03:30:29Z",
      "age": 47
    },
    "registered": {
      "date": "2004-05-18T16:27:41Z",
      "age": 15
    },
    "phone": "(719)-909-6515",
    "cell": "(111)-944-6642",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/85.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/85.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/85.jpg"
    },
    "nat": "TR"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "hans d.",
      "last": "bretschneider"
    },
    "location": {
      "street": "bahnhofstraße 149",
      "city": "metzingen",
      "state": "mecklenburg-vorpommern",
      "postcode": 61415,
      "coordinates": {
        "latitude": "-28.8328",
        "longitude": "-82.7941"
      },
      "timezone": {
        "offset": "-7:00",
        "description": "Mountain Time (US & Canada)"
      }
    },
    "email": "hans d..bretschneider@example.com",
    "login": {
      "uuid": "af04aabd-fbfe-4cdc-9a66-9773050cb527",
      "username": "whitekoala760",
      "password": "naruto",
      "salt": "VocPvwfI",
      "md5": "2485779439d2e300171c1636303182e1",
      "sha1": "03ab8c028a9bee1703a10e86ef6817bc2905b23b",
      "sha256": "a1879d3726ae8f3c34aedff10ca446d2ad21c269a18d75532a2b1cd5f080752b"
    },
    "dob": {
      "date": "1989-03-10T07:53:12Z",
      "age": 30
    },
    "registered": {
      "date": "2003-11-01T21:18:26Z",
      "age": 15
    },
    "phone": "0280-9777443",
    "cell": "0171-3762241",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/0.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/0.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/0.jpg"
    },
    "nat": "DE"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "frederik",
      "last": "johansen"
    },
    "location": {
      "street": "3823 grantofteparken",
      "city": "roslev",
      "state": "nordjylland",
      "postcode": 26670,
      "coordinates": {
        "latitude": "-26.8878",
        "longitude": "-111.9470"
      },
      "timezone": {
        "offset": "+4:00",
        "description": "Abu Dhabi, Muscat, Baku, Tbilisi"
      }
    },
    "email": "frederik.johansen@example.com",
    "login": {
      "uuid": "dd94683b-380e-4165-a6ab-94bdadeeae40",
      "username": "blackgorilla680",
      "password": "tuesday",
      "salt": "tRYtkHgf",
      "md5": "2ab8e956c758d961394e58340bb094ad",
      "sha1": "2b54f70ce8e30bf7a3bf3088886b342632693723",
      "sha256": "5281b7db5583983ab65adb8d48a4ec7d83784116e5375d93b04dc9095da4517c"
    },
    "dob": {
      "date": "1988-01-05T18:15:10Z",
      "age": 31
    },
    "registered": {
      "date": "2008-02-28T20:46:07Z",
      "age": 11
    },
    "phone": "94615389",
    "cell": "85538258",
    "id": {
      "name": "CPR",
      "value": "740769-5330"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/0.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/0.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/0.jpg"
    },
    "nat": "DK"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "niklas",
      "last": "ranta"
    },
    "location": {
      "street": "9456 pirkankatu",
      "city": "hamina",
      "state": "satakunta",
      "postcode": 61880,
      "coordinates": {
        "latitude": "-87.0753",
        "longitude": "92.8844"
      },
      "timezone": {
        "offset": "+3:30",
        "description": "Tehran"
      }
    },
    "email": "niklas.ranta@example.com",
    "login": {
      "uuid": "a63b2fa3-b875-44a4-b85e-fa7b5f39ecc2",
      "username": "yellowwolf603",
      "password": "bella",
      "salt": "S3yTutFC",
      "md5": "e2cb61c8cd61e3283a681d3fcfdf8f30",
      "sha1": "3fb5ca2512dd6c8a9464edd28b5ccc79a9e6ae52",
      "sha256": "bb15c6084a8ae23a6fbf368ca09a480278ad93ded851c449d9cd8a5d2fa2238d"
    },
    "dob": {
      "date": "1964-05-26T19:13:09Z",
      "age": 55
    },
    "registered": {
      "date": "2005-01-06T10:48:27Z",
      "age": 14
    },
    "phone": "09-058-003",
    "cell": "048-290-06-53",
    "id": {
      "name": "HETU",
      "value": "NaNNA785undefined"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/88.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/88.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/88.jpg"
    },
    "nat": "FI"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "linda",
      "last": "banks"
    },
    "location": {
      "street": "3632 woodlawn avenue",
      "city": "sligo",
      "state": "cork",
      "postcode": 95040,
      "coordinates": {
        "latitude": "-66.3564",
        "longitude": "8.4093"
      },
      "timezone": {
        "offset": "+4:00",
        "description": "Abu Dhabi, Muscat, Baku, Tbilisi"
      }
    },
    "email": "linda.banks@example.com",
    "login": {
      "uuid": "9b608afc-1bbe-4ae3-91f2-3332562f11ec",
      "username": "blackladybug849",
      "password": "support",
      "salt": "2ffEchq7",
      "md5": "5468ff367d461f0c9456612b6f66eaa7",
      "sha1": "4b9a6881f7a33d85d822fcc570af147b58c90c8e",
      "sha256": "432f949be43a47aa40457ef2fce541e18a07195b830ed8e431e093135776fdd8"
    },
    "dob": {
      "date": "1954-10-21T08:25:05Z",
      "age": 64
    },
    "registered": {
      "date": "2005-11-13T19:21:31Z",
      "age": 13
    },
    "phone": "011-901-6078",
    "cell": "081-879-0503",
    "id": {
      "name": "PPS",
      "value": "2829094T"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/21.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/21.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/21.jpg"
    },
    "nat": "IE"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "calvin",
      "last": "simmmons"
    },
    "location": {
      "street": "6984 grange road",
      "city": "portarlington",
      "state": "galway",
      "postcode": 77425,
      "coordinates": {
        "latitude": "-62.6889",
        "longitude": "-131.3098"
      },
      "timezone": {
        "offset": "-1:00",
        "description": "Azores, Cape Verde Islands"
      }
    },
    "email": "calvin.simmmons@example.com",
    "login": {
      "uuid": "fb8c2da7-3b7d-4624-b490-335ae33df443",
      "username": "organicmeercat978",
      "password": "californ",
      "salt": "C81Uvybf",
      "md5": "e68467830aee1407ea42a3c0e25fe552",
      "sha1": "826a7f683b18fbe8c9d9706b2402a9f2943f8015",
      "sha256": "5d3f6fd4f482c00e761ef21ae99af047df65c21c1fd7a26fcfc2e16c135045a5"
    },
    "dob": {
      "date": "1952-07-10T06:47:17Z",
      "age": 67
    },
    "registered": {
      "date": "2017-06-03T21:29:08Z",
      "age": 2
    },
    "phone": "061-949-8164",
    "cell": "081-234-7351",
    "id": {
      "name": "PPS",
      "value": "6069573T"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/59.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/59.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/59.jpg"
    },
    "nat": "IE"
  },
  {
    "gender": "male",
    "name": {
      "title": "monsieur",
      "first": "michaël",
      "last": "rolland"
    },
    "location": {
      "street": "7804 rue du bât-d'argent",
      "city": "ellikon an der thur",
      "state": "obwalden",
      "postcode": 5935,
      "coordinates": {
        "latitude": "-54.4063",
        "longitude": "-171.1616"
      },
      "timezone": {
        "offset": "-1:00",
        "description": "Azores, Cape Verde Islands"
      }
    },
    "email": "michaël.rolland@example.com",
    "login": {
      "uuid": "2cd4c97a-0de8-4617-b38d-73e9d2065ea6",
      "username": "yellowfish231",
      "password": "bluejays",
      "salt": "h4nihrVQ",
      "md5": "9b82807213ba352a085286a828dbe39d",
      "sha1": "38aa507437e150e92af01cf237b05cb02eb842ad",
      "sha256": "753279b9b0ad8764c925ece69e8dc66da106690a630eb5c49cafc058ea9c67eb"
    },
    "dob": {
      "date": "1966-02-15T11:23:07Z",
      "age": 53
    },
    "registered": {
      "date": "2018-03-25T08:00:51Z",
      "age": 1
    },
    "phone": "(147)-116-7879",
    "cell": "(486)-765-6999",
    "id": {
      "name": "AVS",
      "value": "756.0321.7555.82"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/73.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/73.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/73.jpg"
    },
    "nat": "CH"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "otto",
      "last": "vestøl"
    },
    "location": {
      "street": "john brandts vei 9967",
      "city": "leikanger",
      "state": "vestfold",
      "postcode": "2630",
      "coordinates": {
        "latitude": "71.9951",
        "longitude": "106.3532"
      },
      "timezone": {
        "offset": "+10:00",
        "description": "Eastern Australia, Guam, Vladivostok"
      }
    },
    "email": "otto.vestøl@example.com",
    "login": {
      "uuid": "db9a18ac-ba41-4cf6-99de-d545bc569b0e",
      "username": "orangefish504",
      "password": "pppp",
      "salt": "tSFaGXdT",
      "md5": "bae5cbde62ee1b9c72cb7abc92512b32",
      "sha1": "c9138741a18154c81def7a12f4d80138c15bd9cc",
      "sha256": "7f1ce97196809d1e3b4011e4fbbbd8f6785387e310b538de9162e88d087e85d6"
    },
    "dob": {
      "date": "1976-02-01T08:17:41Z",
      "age": 43
    },
    "registered": {
      "date": "2017-12-23T05:14:38Z",
      "age": 1
    },
    "phone": "75004261",
    "cell": "92662167",
    "id": {
      "name": "FN",
      "value": "01027620805"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/47.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/47.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/47.jpg"
    },
    "nat": "NO"
  },
  {
    "gender": "female",
    "name": {
      "title": "ms",
      "first": "ömür",
      "last": "atakol"
    },
    "location": {
      "street": "9359 şehitler cd",
      "city": "İzmir",
      "state": "hakkâri",
      "postcode": 64287,
      "coordinates": {
        "latitude": "64.6926",
        "longitude": "-161.2794"
      },
      "timezone": {
        "offset": "+6:00",
        "description": "Almaty, Dhaka, Colombo"
      }
    },
    "email": "ömür.atakol@example.com",
    "login": {
      "uuid": "0b518e55-26dc-466c-b2f4-420896546bde",
      "username": "whitekoala692",
      "password": "napoleon",
      "salt": "9yx7Y61f",
      "md5": "d85b187239fe223afc21fcdaa0b7d828",
      "sha1": "231da6ce11dc366e823ad8a07673c20d28e829bb",
      "sha256": "ca4ce09ee9e47516687efa5f1355ddb3a69dbd04b1481a9252f8034d90d01a14"
    },
    "dob": {
      "date": "1987-01-17T16:18:38Z",
      "age": 32
    },
    "registered": {
      "date": "2004-11-09T08:06:32Z",
      "age": 14
    },
    "phone": "(415)-256-5759",
    "cell": "(669)-655-2008",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/24.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/24.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/24.jpg"
    },
    "nat": "TR"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "christoffer",
      "last": "johansen"
    },
    "location": {
      "street": "9284 margrethevej",
      "city": "skaerbaek",
      "state": "nordjylland",
      "postcode": 50228,
      "coordinates": {
        "latitude": "57.6456",
        "longitude": "-48.8702"
      },
      "timezone": {
        "offset": "+3:30",
        "description": "Tehran"
      }
    },
    "email": "christoffer.johansen@example.com",
    "login": {
      "uuid": "2b2b09aa-3166-4832-9bcf-efd27947f07e",
      "username": "tinyswan389",
      "password": "1a2b3c",
      "salt": "RaZXurLI",
      "md5": "95c026155637d24999959bb40a44ab84",
      "sha1": "69b30efcc22a8ec46f2f8fb67a144ff468ad8995",
      "sha256": "234cbe205f60fef96cf22a4dfd9d58ecfa122d2157712510bd0fdc3648330f51"
    },
    "dob": {
      "date": "1946-10-23T17:27:50Z",
      "age": 72
    },
    "registered": {
      "date": "2007-01-05T10:48:16Z",
      "age": 12
    },
    "phone": "48859594",
    "cell": "30137512",
    "id": {
      "name": "CPR",
      "value": "533262-3870"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/34.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/34.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/34.jpg"
    },
    "nat": "DK"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "vivan",
      "last": "allen"
    },
    "location": {
      "street": "5804 oak lawn ave",
      "city": "townsville",
      "state": "new south wales",
      "postcode": 2720,
      "coordinates": {
        "latitude": "-27.9041",
        "longitude": "-118.7182"
      },
      "timezone": {
        "offset": "+7:00",
        "description": "Bangkok, Hanoi, Jakarta"
      }
    },
    "email": "vivan.allen@example.com",
    "login": {
      "uuid": "541d0457-0427-42c0-85bc-b3b77b09beb4",
      "username": "goldenpeacock342",
      "password": "hamlet",
      "salt": "1VyvxXoi",
      "md5": "47dfbce1523cd12526853df99e268a0c",
      "sha1": "6e80959b8a1fd99ec24b753eceadea79a3f426a1",
      "sha256": "181398220b8628bcd03e414737b2acd427c7a76c735d63f8b8292f792ba41209"
    },
    "dob": {
      "date": "1946-10-21T02:54:56Z",
      "age": 72
    },
    "registered": {
      "date": "2007-11-13T09:31:05Z",
      "age": 11
    },
    "phone": "05-5630-2268",
    "cell": "0467-219-949",
    "id": {
      "name": "TFN",
      "value": "639394278"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/74.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/74.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/74.jpg"
    },
    "nat": "AU"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "hector",
      "last": "walters"
    },
    "location": {
      "street": "8792 college st",
      "city": "miramar",
      "state": "mississippi",
      "postcode": 52990,
      "coordinates": {
        "latitude": "50.5105",
        "longitude": "-131.7786"
      },
      "timezone": {
        "offset": "+9:00",
        "description": "Tokyo, Seoul, Osaka, Sapporo, Yakutsk"
      }
    },
    "email": "hector.walters@example.com",
    "login": {
      "uuid": "20888af4-7a4d-4d2e-b012-15e596239fa4",
      "username": "smallladybug104",
      "password": "jammer",
      "salt": "vn3UzzD5",
      "md5": "d1abeb5fe786bfb31dd8174853a6bcda",
      "sha1": "de0f654e006cee52a4f751ef0fbdf91da0d123a4",
      "sha256": "2c6f30352fe45f4c6767d74ae4104b8713e4cb9001f01268118faed0b5652b4d"
    },
    "dob": {
      "date": "1952-01-16T14:00:08Z",
      "age": 67
    },
    "registered": {
      "date": "2015-10-12T17:29:05Z",
      "age": 3
    },
    "phone": "(075)-299-6048",
    "cell": "(985)-027-4218",
    "id": {
      "name": "SSN",
      "value": "314-53-3746"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/88.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/88.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/88.jpg"
    },
    "nat": "US"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "mathis",
      "last": "gauthier"
    },
    "location": {
      "street": "6807 main st",
      "city": "trenton",
      "state": "nova scotia",
      "postcode": "C6B 3Z2",
      "coordinates": {
        "latitude": "20.5576",
        "longitude": "10.4287"
      },
      "timezone": {
        "offset": "-1:00",
        "description": "Azores, Cape Verde Islands"
      }
    },
    "email": "mathis.gauthier@example.com",
    "login": {
      "uuid": "774e2d2d-6b75-4360-ab34-e2ac0f034d4d",
      "username": "happymouse570",
      "password": "carole",
      "salt": "bjFPEgto",
      "md5": "93dc2e7e9e6b4eb74cb81eacd4ff1230",
      "sha1": "656cf7d94ca6c7f0bc0ce0f3e8962d590923ea61",
      "sha256": "d4c87cd4fde49f229f7b1ff9fa1991ca23036f9dda80937291dd64ea803bcbba"
    },
    "dob": {
      "date": "1961-12-24T18:45:18Z",
      "age": 57
    },
    "registered": {
      "date": "2007-02-10T15:20:46Z",
      "age": 12
    },
    "phone": "621-837-0820",
    "cell": "089-563-3764",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/94.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/94.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/94.jpg"
    },
    "nat": "CA"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "wayne",
      "last": "brewer"
    },
    "location": {
      "street": "2080 taylor st",
      "city": "birmingham",
      "state": "south dakota",
      "postcode": 25352,
      "coordinates": {
        "latitude": "49.0465",
        "longitude": "-124.8167"
      },
      "timezone": {
        "offset": "+4:00",
        "description": "Abu Dhabi, Muscat, Baku, Tbilisi"
      }
    },
    "email": "wayne.brewer@example.com",
    "login": {
      "uuid": "475c784b-be2b-47f8-8520-344df0d20d00",
      "username": "purplemeercat180",
      "password": "ducati",
      "salt": "mADWZldq",
      "md5": "f34100c8b47e8b55516ae5aac9a96442",
      "sha1": "d1080ab0b0c64017d723d2b2b9a855d03fa9928e",
      "sha256": "9281390e28d4b4d50d6e3d0b374cf04e6aea304b835ae7cb44d32653ae52c2c7"
    },
    "dob": {
      "date": "1995-02-27T16:18:04Z",
      "age": 24
    },
    "registered": {
      "date": "2015-07-09T16:59:38Z",
      "age": 4
    },
    "phone": "(319)-722-1883",
    "cell": "(025)-755-1933",
    "id": {
      "name": "SSN",
      "value": "003-48-6629"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/45.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/45.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/45.jpg"
    },
    "nat": "US"
  },
  {
    "gender": "female",
    "name": {
      "title": "ms",
      "first": "gitte",
      "last": "paul"
    },
    "location": {
      "street": "lessingstraße 85",
      "city": "regis-breitingen",
      "state": "nordrhein-westfalen",
      "postcode": 40072,
      "coordinates": {
        "latitude": "-44.1270",
        "longitude": "175.2068"
      },
      "timezone": {
        "offset": "-12:00",
        "description": "Eniwetok, Kwajalein"
      }
    },
    "email": "gitte.paul@example.com",
    "login": {
      "uuid": "e9515fcc-2587-456d-97b3-9744049f9437",
      "username": "purpleelephant157",
      "password": "thedude",
      "salt": "mICTnFx1",
      "md5": "da6908c71dc8457cd0975e471c6f8db2",
      "sha1": "649c608d42dccbdd572ced6b6244cc4fcb61597a",
      "sha256": "ff7077cf709962641880879794e09a50f96659e6ffac60f9686a70cfb7bf6375"
    },
    "dob": {
      "date": "1978-12-19T06:28:18Z",
      "age": 40
    },
    "registered": {
      "date": "2010-08-26T08:59:12Z",
      "age": 9
    },
    "phone": "0160-7570420",
    "cell": "0173-7459816",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/49.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/49.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/49.jpg"
    },
    "nat": "DE"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "سام",
      "last": "موسوی"
    },
    "location": {
      "street": "4649 میدان دکتر فاطمی / جهاد",
      "city": "ساری",
      "state": "آذربایجان شرقی",
      "postcode": 11437,
      "coordinates": {
        "latitude": "-68.8072",
        "longitude": "-35.8897"
      },
      "timezone": {
        "offset": "+4:00",
        "description": "Abu Dhabi, Muscat, Baku, Tbilisi"
      }
    },
    "email": "سام.موسوی@example.com",
    "login": {
      "uuid": "07de4b39-3a24-4b83-a075-840d215d6d5e",
      "username": "silverdog290",
      "password": "575757",
      "salt": "OOgynLs2",
      "md5": "2ed5d6cc27439a90a42df13fcb0cf3d1",
      "sha1": "39db9e6a93b62eb2658d5a79cd832c0c86576b08",
      "sha256": "649cf949bda6fc03df2af2fb25e7e49714fba4adfb17294e1f0dd736028943c4"
    },
    "dob": {
      "date": "1978-06-22T09:43:13Z",
      "age": 41
    },
    "registered": {
      "date": "2006-06-13T06:49:32Z",
      "age": 13
    },
    "phone": "016-82223070",
    "cell": "0936-332-0736",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/97.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/97.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/97.jpg"
    },
    "nat": "IR"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "anwar",
      "last": "heijkoop"
    },
    "location": {
      "street": "702 nicolaasweg",
      "city": "nieuwkoop",
      "state": "noord-holland",
      "postcode": 77994,
      "coordinates": {
        "latitude": "-77.4777",
        "longitude": "-128.0722"
      },
      "timezone": {
        "offset": "-9:00",
        "description": "Alaska"
      }
    },
    "email": "anwar.heijkoop@example.com",
    "login": {
      "uuid": "6cfd58ab-80d4-433d-ab74-ac3768cc3de0",
      "username": "purpleleopard974",
      "password": "perfect1",
      "salt": "gJO5r9AM",
      "md5": "203f444df5988a9988e150ac6f97e8cd",
      "sha1": "887695494b8b04700de3ad4e838640dd0ea8025f",
      "sha256": "1ce7aba7902bbb4a68b9928a0ea34d3e47b6fa23884d39a624e3e6cda0028de2"
    },
    "dob": {
      "date": "1950-10-05T16:09:39Z",
      "age": 68
    },
    "registered": {
      "date": "2004-06-08T13:23:29Z",
      "age": 15
    },
    "phone": "(289)-871-3621",
    "cell": "(385)-629-0652",
    "id": {
      "name": "BSN",
      "value": "28159754"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/24.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/24.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/24.jpg"
    },
    "nat": "NL"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "ethan",
      "last": "ross"
    },
    "location": {
      "street": "1989 lakeview ave",
      "city": "field",
      "state": "alberta",
      "postcode": "T1A 0N4",
      "coordinates": {
        "latitude": "9.6372",
        "longitude": "-12.1459"
      },
      "timezone": {
        "offset": "-7:00",
        "description": "Mountain Time (US & Canada)"
      }
    },
    "email": "ethan.ross@example.com",
    "login": {
      "uuid": "64884a05-9243-4c38-b42e-30f3a6a89a1b",
      "username": "bigkoala837",
      "password": "blazer",
      "salt": "ADvWJCg1",
      "md5": "4b659ce65175f915f0da004fe789ae81",
      "sha1": "560650b68b29edcbe93d6dce2c9a5245f90d84a3",
      "sha256": "eac4acc06d448b2bf7f9ab5e9cbae7aba364cde0ecc3099d623381da57d966ee"
    },
    "dob": {
      "date": "1956-01-28T07:03:51Z",
      "age": 63
    },
    "registered": {
      "date": "2014-02-01T20:11:41Z",
      "age": 5
    },
    "phone": "559-196-9187",
    "cell": "466-832-9293",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/34.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/34.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/34.jpg"
    },
    "nat": "CA"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "dominic",
      "last": "lévesque"
    },
    "location": {
      "street": "4432 concession road 23",
      "city": "deer lake",
      "state": "saskatchewan",
      "postcode": "O3E 5P5",
      "coordinates": {
        "latitude": "-18.1678",
        "longitude": "-82.1165"
      },
      "timezone": {
        "offset": "-8:00",
        "description": "Pacific Time (US & Canada)"
      }
    },
    "email": "dominic.lévesque@example.com",
    "login": {
      "uuid": "ba91452f-3929-4371-a535-ee9b9b1083f2",
      "username": "silverzebra589",
      "password": "messiah",
      "salt": "j12nE3IP",
      "md5": "7620a7643f2e40f75b7704588b111f4a",
      "sha1": "52787edcf8b8f8a102b89a62421212ece3ce4e0e",
      "sha256": "7393a4bd1603d8a3956e8e7b086d1fd3f073218823fb45f57e20aba2bf6574ab"
    },
    "dob": {
      "date": "1979-03-27T10:03:22Z",
      "age": 40
    },
    "registered": {
      "date": "2009-09-17T01:28:06Z",
      "age": 9
    },
    "phone": "679-906-4434",
    "cell": "682-325-8768",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/78.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/78.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/78.jpg"
    },
    "nat": "CA"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "larry",
      "last": "richardson"
    },
    "location": {
      "street": "3695 poplar dr",
      "city": "queanbeyan",
      "state": "south australia",
      "postcode": 1167,
      "coordinates": {
        "latitude": "52.1312",
        "longitude": "16.8675"
      },
      "timezone": {
        "offset": "-7:00",
        "description": "Mountain Time (US & Canada)"
      }
    },
    "email": "larry.richardson@example.com",
    "login": {
      "uuid": "e9d758a8-e49f-41df-868b-87cb3a88f8d6",
      "username": "whitepanda724",
      "password": "town",
      "salt": "2PG0DXvc",
      "md5": "f1a69259490a317a13821bfc192949c2",
      "sha1": "823a70a50c32d8305c22e96276e2d290e0bcd219",
      "sha256": "3ee40dd74ad504355c4f9619039d78e587a2fb9d4a4bbf4e46f195357ae6eefe"
    },
    "dob": {
      "date": "1956-01-05T13:20:43Z",
      "age": 63
    },
    "registered": {
      "date": "2007-10-22T01:12:04Z",
      "age": 11
    },
    "phone": "05-8092-7651",
    "cell": "0488-927-085",
    "id": {
      "name": "TFN",
      "value": "017072054"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/96.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/96.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/96.jpg"
    },
    "nat": "AU"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "esma",
      "last": "aşıkoğlu"
    },
    "location": {
      "street": "5486 necatibey cd",
      "city": "artvin",
      "state": "İzmir",
      "postcode": 79509,
      "coordinates": {
        "latitude": "-81.1872",
        "longitude": "162.7054"
      },
      "timezone": {
        "offset": "+9:00",
        "description": "Tokyo, Seoul, Osaka, Sapporo, Yakutsk"
      }
    },
    "email": "esma.aşıkoğlu@example.com",
    "login": {
      "uuid": "3f8410bf-443c-4685-bb32-25704af46a4a",
      "username": "crazybird285",
      "password": "surgery",
      "salt": "YZUkQ8C7",
      "md5": "0a60183d1722325b753a4cb39c5dcc2e",
      "sha1": "9cb76db88239225453e9db5656fc333c6aa7ecd5",
      "sha256": "82cdcaf6d2c652706992c7b30fbdd10567336be8fe352b6fa871659b5f182379"
    },
    "dob": {
      "date": "1990-07-20T21:51:18Z",
      "age": 29
    },
    "registered": {
      "date": "2005-12-14T11:02:56Z",
      "age": 13
    },
    "phone": "(723)-763-4588",
    "cell": "(593)-156-8330",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/18.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/18.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/18.jpg"
    },
    "nat": "TR"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "glenda",
      "last": "gardner"
    },
    "location": {
      "street": "7837 groveland terrace",
      "city": "orange",
      "state": "iowa",
      "postcode": 63720,
      "coordinates": {
        "latitude": "-24.9497",
        "longitude": "-85.8873"
      },
      "timezone": {
        "offset": "-3:30",
        "description": "Newfoundland"
      }
    },
    "email": "glenda.gardner@example.com",
    "login": {
      "uuid": "15833f96-fc0f-4dca-9965-54c54555ae47",
      "username": "organicelephant453",
      "password": "roll",
      "salt": "xi0tbDEc",
      "md5": "85fdde25ab9553109a3a9c47524df042",
      "sha1": "0a835a663080fae904e0e017d134776583ca6e5b",
      "sha256": "ab88e29cf892604f45bdcb043f77ea2463432278c4528f65abe18e0601bdf066"
    },
    "dob": {
      "date": "1986-03-27T13:30:32Z",
      "age": 33
    },
    "registered": {
      "date": "2005-12-03T22:02:17Z",
      "age": 13
    },
    "phone": "(465)-618-4094",
    "cell": "(771)-726-3616",
    "id": {
      "name": "SSN",
      "value": "118-95-7940"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/65.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/65.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/65.jpg"
    },
    "nat": "US"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "nanna",
      "last": "pedersen"
    },
    "location": {
      "street": "6600 vestergårdsvej",
      "city": "københavn v",
      "state": "nordjylland",
      "postcode": 33857,
      "coordinates": {
        "latitude": "52.6596",
        "longitude": "171.0395"
      },
      "timezone": {
        "offset": "-1:00",
        "description": "Azores, Cape Verde Islands"
      }
    },
    "email": "nanna.pedersen@example.com",
    "login": {
      "uuid": "cc20c857-7c60-4d71-b2aa-e25bb386d236",
      "username": "brownfish314",
      "password": "gretzky",
      "salt": "2gDh3Jyw",
      "md5": "aa8a8b5b9d02ac682630408be6799b1c",
      "sha1": "e23a7da1fd162b797ac6defa600255b43ba8be83",
      "sha256": "826e1d79d27afdef699c25e466fcb06d332a41ec3928badba68396e17fea36ac"
    },
    "dob": {
      "date": "1957-07-26T03:51:48Z",
      "age": 62
    },
    "registered": {
      "date": "2018-03-09T11:50:19Z",
      "age": 1
    },
    "phone": "57957061",
    "cell": "55924566",
    "id": {
      "name": "CPR",
      "value": "172833-9446"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/8.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/8.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/8.jpg"
    },
    "nat": "DK"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "julie",
      "last": "brewer"
    },
    "location": {
      "street": "2482 mill lane",
      "city": "dungarvan",
      "state": "cork city",
      "postcode": 47668,
      "coordinates": {
        "latitude": "-64.6888",
        "longitude": "-164.5910"
      },
      "timezone": {
        "offset": "+3:00",
        "description": "Baghdad, Riyadh, Moscow, St. Petersburg"
      }
    },
    "email": "julie.brewer@example.com",
    "login": {
      "uuid": "718ddf5a-614c-4351-871e-d4202017024a",
      "username": "tinyduck499",
      "password": "jimjim",
      "salt": "l99vIkkg",
      "md5": "1e9e758447f4611ab12858dd746bede4",
      "sha1": "f3b1aefd215a127ca476c0074822bd83960ddc57",
      "sha256": "f2b57af198b96e2366e51c7abfa25587e191b4ed31db575cea4588c6726cf20a"
    },
    "dob": {
      "date": "1961-12-21T16:56:17Z",
      "age": 57
    },
    "registered": {
      "date": "2015-04-19T22:58:54Z",
      "age": 4
    },
    "phone": "051-719-6864",
    "cell": "081-095-7674",
    "id": {
      "name": "PPS",
      "value": "1067602T"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/78.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/78.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/78.jpg"
    },
    "nat": "IE"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "camille",
      "last": "leroux"
    },
    "location": {
      "street": "1800 rue courbet",
      "city": "reims",
      "state": "haute-vienne",
      "postcode": 45185,
      "coordinates": {
        "latitude": "30.6343",
        "longitude": "-56.6380"
      },
      "timezone": {
        "offset": "+5:00",
        "description": "Ekaterinburg, Islamabad, Karachi, Tashkent"
      }
    },
    "email": "camille.leroux@example.com",
    "login": {
      "uuid": "296091a7-52e2-499a-a477-ee90eb0e063e",
      "username": "saddog416",
      "password": "2121",
      "salt": "uVBlPQEC",
      "md5": "8b676ec8cf0c75c3e8a152f31895f824",
      "sha1": "80acdd2d9e5a0825f35f0b833c290fb969a5f7c3",
      "sha256": "64105cda0eaeab992d89ee191994a3f44bd75e52d481e011c590c88dd64441d0"
    },
    "dob": {
      "date": "1947-07-21T22:08:28Z",
      "age": 72
    },
    "registered": {
      "date": "2018-01-24T23:00:49Z",
      "age": 1
    },
    "phone": "05-68-67-47-06",
    "cell": "06-29-58-36-18",
    "id": {
      "name": "INSEE",
      "value": "2NNaN29144212 76"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/94.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/94.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/94.jpg"
    },
    "nat": "FR"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "malone",
      "last": "rodriguez"
    },
    "location": {
      "street": "8772 quai charles-de-gaulle",
      "city": "toulouse",
      "state": "seine-saint-denis",
      "postcode": 83628,
      "coordinates": {
        "latitude": "-50.3163",
        "longitude": "55.9750"
      },
      "timezone": {
        "offset": "+1:00",
        "description": "Brussels, Copenhagen, Madrid, Paris"
      }
    },
    "email": "malone.rodriguez@example.com",
    "login": {
      "uuid": "f4903453-a801-464a-94a2-08bf4bebec15",
      "username": "greenladybug749",
      "password": "porn",
      "salt": "sYTMRh7F",
      "md5": "f8b036fa94e970d6883e953e7c807ada",
      "sha1": "ee731e869a04634de54bce646b25b001ead249c6",
      "sha256": "8c6761a8391cdf2d26be0f9fa46fb29e28c719d1157c013ed8f33c467e636e93"
    },
    "dob": {
      "date": "1983-09-30T03:54:29Z",
      "age": 35
    },
    "registered": {
      "date": "2006-10-16T21:47:13Z",
      "age": 12
    },
    "phone": "01-28-42-17-75",
    "cell": "06-72-77-70-08",
    "id": {
      "name": "INSEE",
      "value": "1NNaN47661268 80"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/60.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/60.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/60.jpg"
    },
    "nat": "FR"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "batur",
      "last": "kuzucu"
    },
    "location": {
      "street": "8483 istiklal cd",
      "city": "muş",
      "state": "malatya",
      "postcode": 44940,
      "coordinates": {
        "latitude": "-0.0411",
        "longitude": "104.4757"
      },
      "timezone": {
        "offset": "+3:00",
        "description": "Baghdad, Riyadh, Moscow, St. Petersburg"
      }
    },
    "email": "batur.kuzucu@example.com",
    "login": {
      "uuid": "45beb864-97f9-47ee-9008-bac5c5228198",
      "username": "whiteswan536",
      "password": "snapper",
      "salt": "ywGjzvJq",
      "md5": "9684682c805d216faeb23bb8fb788341",
      "sha1": "aca9a8229765ac809f08bc5bf127c8949482dba7",
      "sha256": "0024455b5bab9550cbd4e240be9b19194ac962f121cb2b040defeec9048898bb"
    },
    "dob": {
      "date": "1986-10-05T12:53:33Z",
      "age": 32
    },
    "registered": {
      "date": "2006-03-14T15:48:39Z",
      "age": 13
    },
    "phone": "(142)-669-7517",
    "cell": "(079)-607-0872",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/0.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/0.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/0.jpg"
    },
    "nat": "TR"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "louisa",
      "last": "gangstad"
    },
    "location": {
      "street": "nordstrandveien 5948",
      "city": "sarpsborg",
      "state": "nord-trøndelag",
      "postcode": "5525",
      "coordinates": {
        "latitude": "6.2207",
        "longitude": "-11.8408"
      },
      "timezone": {
        "offset": "+9:30",
        "description": "Adelaide, Darwin"
      }
    },
    "email": "louisa.gangstad@example.com",
    "login": {
      "uuid": "051b61e8-9820-4e44-bde5-2b3439f425f8",
      "username": "lazybird459",
      "password": "master",
      "salt": "ofkHnS6S",
      "md5": "c6bf146af236fbb9b2b5afd7857a04f3",
      "sha1": "59d068f25fc294009d6fb57ca32bfa9a0a3b34c6",
      "sha256": "3e210eb7662e71a61ad56737fde921974b861583c40d0494b9d54bbd980144de"
    },
    "dob": {
      "date": "1953-07-14T11:01:39Z",
      "age": 66
    },
    "registered": {
      "date": "2010-04-11T22:35:53Z",
      "age": 9
    },
    "phone": "35691291",
    "cell": "93797801",
    "id": {
      "name": "FN",
      "value": "14075311908"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/68.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/68.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/68.jpg"
    },
    "nat": "NO"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "omaira",
      "last": "van wichen"
    },
    "location": {
      "street": "4561 springweg",
      "city": "bloemendaal",
      "state": "zeeland",
      "postcode": 42000,
      "coordinates": {
        "latitude": "26.9674",
        "longitude": "-115.3502"
      },
      "timezone": {
        "offset": "+4:00",
        "description": "Abu Dhabi, Muscat, Baku, Tbilisi"
      }
    },
    "email": "omaira.vanwichen@example.com",
    "login": {
      "uuid": "0e87280c-1eb7-437f-b0b6-0996182eb1fe",
      "username": "tinyladybug816",
      "password": "link",
      "salt": "0sSTIMhj",
      "md5": "082ee268fb85cc431c7d1cdc78bf1093",
      "sha1": "1dc744a611fba2d73bb7cac8eef1fbda4c08b83f",
      "sha256": "8724f987c2e80284284cf691f6042cfb4df473ecf6c17e289ee6015fc275fdbb"
    },
    "dob": {
      "date": "1968-11-04T23:02:08Z",
      "age": 50
    },
    "registered": {
      "date": "2003-10-13T05:24:19Z",
      "age": 15
    },
    "phone": "(393)-629-5107",
    "cell": "(728)-277-4069",
    "id": {
      "name": "BSN",
      "value": "34333914"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/48.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/48.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/48.jpg"
    },
    "nat": "NL"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "باران",
      "last": "احمدی"
    },
    "location": {
      "street": "951 دکتر چمران",
      "city": "کرمان",
      "state": "خراسان رضوی",
      "postcode": 14517,
      "coordinates": {
        "latitude": "-86.2374",
        "longitude": "168.1173"
      },
      "timezone": {
        "offset": "+2:00",
        "description": "Kaliningrad, South Africa"
      }
    },
    "email": "باران.احمدی@example.com",
    "login": {
      "uuid": "a818222f-779a-4644-9512-e1879c30a551",
      "username": "beautifulpeacock467",
      "password": "black",
      "salt": "PX26gDV5",
      "md5": "77da3e6fea3e07e606dceda26a887b12",
      "sha1": "84e03dff2fc98e4beaf08327d3712a5b378bfb99",
      "sha256": "baf5f7ea71183922769f0e04428cb58c955d6b906fa6300571189c844a5a7438"
    },
    "dob": {
      "date": "1972-08-31T09:59:59Z",
      "age": 47
    },
    "registered": {
      "date": "2011-01-12T05:17:59Z",
      "age": 8
    },
    "phone": "015-31290310",
    "cell": "0940-428-5866",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/92.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/92.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/92.jpg"
    },
    "nat": "IR"
  },
  {
    "gender": "female",
    "name": {
      "title": "ms",
      "first": "mercedes",
      "last": "parra"
    },
    "location": {
      "street": "6783 avenida de américa",
      "city": "valencia",
      "state": "castilla la mancha",
      "postcode": 79445,
      "coordinates": {
        "latitude": "11.1337",
        "longitude": "47.0264"
      },
      "timezone": {
        "offset": "+10:00",
        "description": "Eastern Australia, Guam, Vladivostok"
      }
    },
    "email": "mercedes.parra@example.com",
    "login": {
      "uuid": "f6bd104d-0fcb-4c67-816c-93362b405496",
      "username": "silvergoose781",
      "password": "joseph1",
      "salt": "Ln3jis1g",
      "md5": "51c97529fa5fe5a5bdb64070bf25defe",
      "sha1": "beb848f19ecff3c4a0035f1f273fbd2ffee85436",
      "sha256": "d61c823bb6ba320bd19cbe3f792aa343e182cd903fac1e25ae9fd8e8a477aec1"
    },
    "dob": {
      "date": "1992-06-26T07:20:40Z",
      "age": 27
    },
    "registered": {
      "date": "2009-12-03T16:45:17Z",
      "age": 9
    },
    "phone": "981-515-873",
    "cell": "675-290-130",
    "id": {
      "name": "DNI",
      "value": "54712009-J"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/18.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/18.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/18.jpg"
    },
    "nat": "ES"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "felix",
      "last": "mendez"
    },
    "location": {
      "street": "4380 calle de segovia",
      "city": "murcia",
      "state": "melilla",
      "postcode": 59624,
      "coordinates": {
        "latitude": "-45.2904",
        "longitude": "59.6191"
      },
      "timezone": {
        "offset": "-1:00",
        "description": "Azores, Cape Verde Islands"
      }
    },
    "email": "felix.mendez@example.com",
    "login": {
      "uuid": "a24bd528-11e2-46ad-90e7-9286ded995d3",
      "username": "organicbear551",
      "password": "2468",
      "salt": "weVj6nKW",
      "md5": "cdf33766b848f015b2a13de87e08b53c",
      "sha1": "49dbcb4af5f72c01ff1683dd655ad2e36250863b",
      "sha256": "569375bed905099d89f4b1096db28d7166d9b5786ed3d26cc67b10bf46ac2c0e"
    },
    "dob": {
      "date": "1969-06-25T20:28:02Z",
      "age": 50
    },
    "registered": {
      "date": "2014-07-13T02:25:58Z",
      "age": 5
    },
    "phone": "937-373-821",
    "cell": "623-022-883",
    "id": {
      "name": "DNI",
      "value": "52635654-A"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/98.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/98.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/98.jpg"
    },
    "nat": "ES"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "آرمین",
      "last": "علیزاده"
    },
    "location": {
      "street": "8299 میدان 15خرداد",
      "city": "اصفهان",
      "state": "گلستان",
      "postcode": 22618,
      "coordinates": {
        "latitude": "0.0290",
        "longitude": "126.5657"
      },
      "timezone": {
        "offset": "-3:30",
        "description": "Newfoundland"
      }
    },
    "email": "آرمین.علیزاده@example.com",
    "login": {
      "uuid": "b60cae85-5162-4ac9-b81a-9be6b55872ff",
      "username": "orangeostrich942",
      "password": "topdog",
      "salt": "sHOuDn3J",
      "md5": "c678bded7b4188a5583769ed52c382af",
      "sha1": "83514cab2eaa4de630316c1b8fc9a0c1e135ecb9",
      "sha256": "44a9c7b8d1bbf4dd376069dc2d14c6aefd611a87256ac7d6a9cc86b970c2ee19"
    },
    "dob": {
      "date": "1971-10-04T04:59:21Z",
      "age": 47
    },
    "registered": {
      "date": "2006-11-11T06:41:10Z",
      "age": 12
    },
    "phone": "059-13803495",
    "cell": "0945-368-5161",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/78.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/78.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/78.jpg"
    },
    "nat": "IR"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "miro",
      "last": "polon"
    },
    "location": {
      "street": "2439 tehtaankatu",
      "city": "orimattila",
      "state": "southern ostrobothnia",
      "postcode": 21848,
      "coordinates": {
        "latitude": "10.6001",
        "longitude": "-45.3927"
      },
      "timezone": {
        "offset": "-3:30",
        "description": "Newfoundland"
      }
    },
    "email": "miro.polon@example.com",
    "login": {
      "uuid": "2ef08d01-5d4f-400a-84bd-79ea0395fd2f",
      "username": "crazymouse502",
      "password": "ground",
      "salt": "RcTz1Mj4",
      "md5": "479cb5d4c1290bbc030fe1fbeaec4fea",
      "sha1": "e1b82feaa54f98f6b4a6caf438ddbfec42aefa3c",
      "sha256": "e8f7d03b7facb1c9c37f617f848a1522d1b9a8b11b62b662670a44787d614152"
    },
    "dob": {
      "date": "1969-11-05T03:11:16Z",
      "age": 49
    },
    "registered": {
      "date": "2004-04-08T03:45:27Z",
      "age": 15
    },
    "phone": "02-386-582",
    "cell": "047-468-39-08",
    "id": {
      "name": "HETU",
      "value": "NaNNA515undefined"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/69.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/69.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/69.jpg"
    },
    "nat": "FI"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "charly",
      "last": "van den eertwegh"
    },
    "location": {
      "street": "7291 billitonkade",
      "city": "ouder-amstel",
      "state": "zuid-holland",
      "postcode": 44644,
      "coordinates": {
        "latitude": "66.3521",
        "longitude": "-146.5887"
      },
      "timezone": {
        "offset": "-4:00",
        "description": "Atlantic Time (Canada), Caracas, La Paz"
      }
    },
    "email": "charly.vandeneertwegh@example.com",
    "login": {
      "uuid": "17014fd2-7d33-432f-81a1-cdecf08143d4",
      "username": "crazywolf213",
      "password": "cream",
      "salt": "F0Ugbt6g",
      "md5": "39956450efb61dc754b2e341f456b445",
      "sha1": "aa562fcc48163cc37bc2923226802ce282a517fb",
      "sha256": "9878910a93036b9695c4449b64cfaf07bd6536da6499c14439b036d4f3dd354f"
    },
    "dob": {
      "date": "1993-03-16T20:29:36Z",
      "age": 26
    },
    "registered": {
      "date": "2012-01-12T14:50:44Z",
      "age": 7
    },
    "phone": "(458)-364-0636",
    "cell": "(918)-046-0976",
    "id": {
      "name": "BSN",
      "value": "75579152"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/64.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/64.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/64.jpg"
    },
    "nat": "NL"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "rasmus",
      "last": "aalto"
    },
    "location": {
      "street": "3595 hämeenkatu",
      "city": "vihanti",
      "state": "kainuu",
      "postcode": 28109,
      "coordinates": {
        "latitude": "79.9905",
        "longitude": "-174.4638"
      },
      "timezone": {
        "offset": "+9:00",
        "description": "Tokyo, Seoul, Osaka, Sapporo, Yakutsk"
      }
    },
    "email": "rasmus.aalto@example.com",
    "login": {
      "uuid": "f7a02d6b-3c4b-47fd-8560-1399f2e9bf6f",
      "username": "silvercat474",
      "password": "eagles1",
      "salt": "YiwXZ9AU",
      "md5": "58ea233b6150c7337aa1f7adc4943a1e",
      "sha1": "dab71c53405536a2574a7c6191cf9d4dbc5ab2b1",
      "sha256": "cd05f721cac09cbd6eca6335509006ed9adbdb677069550f53626df4031823df"
    },
    "dob": {
      "date": "1976-05-19T21:48:42Z",
      "age": 43
    },
    "registered": {
      "date": "2014-12-23T15:01:40Z",
      "age": 4
    },
    "phone": "09-604-297",
    "cell": "045-797-76-37",
    "id": {
      "name": "HETU",
      "value": "NaNNA871undefined"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/24.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/24.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/24.jpg"
    },
    "nat": "FI"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "ece",
      "last": "tazegül"
    },
    "location": {
      "street": "489 bağdat cd",
      "city": "yalova",
      "state": "muş",
      "postcode": 54478,
      "coordinates": {
        "latitude": "69.7592",
        "longitude": "-140.9088"
      },
      "timezone": {
        "offset": "+8:00",
        "description": "Beijing, Perth, Singapore, Hong Kong"
      }
    },
    "email": "ece.tazegül@example.com",
    "login": {
      "uuid": "a7357b58-1a1a-4f8c-936a-e6cc4931e321",
      "username": "bigwolf175",
      "password": "barber",
      "salt": "hP9qJyvS",
      "md5": "18b84345dce9fe730a433fd62e045377",
      "sha1": "899b8a626588140fee2d0436a00347ace047503a",
      "sha256": "c7dcae243dbaca25b743b695ba199b14726f39c1e78ef0e081cd4171037a1635"
    },
    "dob": {
      "date": "1970-04-05T23:09:58Z",
      "age": 49
    },
    "registered": {
      "date": "2007-07-14T02:16:55Z",
      "age": 12
    },
    "phone": "(775)-913-8622",
    "cell": "(101)-330-3296",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/56.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/56.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/56.jpg"
    },
    "nat": "TR"
  },
  {
    "gender": "female",
    "name": {
      "title": "ms",
      "first": "linda",
      "last": "campos"
    },
    "location": {
      "street": "3888 rua são paulo ",
      "city": "ourinhos",
      "state": "rio de janeiro",
      "postcode": 50277,
      "coordinates": {
        "latitude": "-40.4471",
        "longitude": "95.2446"
      },
      "timezone": {
        "offset": "-2:00",
        "description": "Mid-Atlantic"
      }
    },
    "email": "linda.campos@example.com",
    "login": {
      "uuid": "b2f426fb-827b-4219-8dcf-6ebca8affe04",
      "username": "yellowleopard820",
      "password": "thumb",
      "salt": "Q1LatrRO",
      "md5": "e5addc540533c012427c26743bccb607",
      "sha1": "3a7cadb8f8f77988186e14af87082ab877d28523",
      "sha256": "d94fb3a755107679ac0bc97a688734f9363829827ce1c047bd1e2168059e8aec"
    },
    "dob": {
      "date": "1968-09-28T08:54:09Z",
      "age": 50
    },
    "registered": {
      "date": "2012-05-26T06:42:46Z",
      "age": 7
    },
    "phone": "(03) 4175-0679",
    "cell": "(85) 5463-6280",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/96.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/96.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/96.jpg"
    },
    "nat": "BR"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "leo",
      "last": "gauthier"
    },
    "location": {
      "street": "3723 peel st",
      "city": "carleton",
      "state": "nova scotia",
      "postcode": "T5M 6Q8",
      "coordinates": {
        "latitude": "-41.7333",
        "longitude": "-108.5178"
      },
      "timezone": {
        "offset": "+8:00",
        "description": "Beijing, Perth, Singapore, Hong Kong"
      }
    },
    "email": "leo.gauthier@example.com",
    "login": {
      "uuid": "c988d3c4-bef9-467f-85b8-08c1bb8479f7",
      "username": "blackladybug344",
      "password": "iverson",
      "salt": "pxv1quow",
      "md5": "28ef3db63142616f6964626e0f1fca90",
      "sha1": "02170d39587dfb03317213ddbb0507bb9a3d8736",
      "sha256": "9c7ce720200fc2d259ea89ce3f7ef8762da7db5a657ecdf657a6e684a8df095e"
    },
    "dob": {
      "date": "1984-03-30T21:22:30Z",
      "age": 35
    },
    "registered": {
      "date": "2008-08-08T21:51:26Z",
      "age": 11
    },
    "phone": "210-004-2360",
    "cell": "428-192-5152",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/81.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/81.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/81.jpg"
    },
    "nat": "CA"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "matias",
      "last": "kangas"
    },
    "location": {
      "street": "1726 otavalankatu",
      "city": "siikainen",
      "state": "satakunta",
      "postcode": 89367,
      "coordinates": {
        "latitude": "59.9553",
        "longitude": "28.4147"
      },
      "timezone": {
        "offset": "0:00",
        "description": "Western Europe Time, London, Lisbon, Casablanca"
      }
    },
    "email": "matias.kangas@example.com",
    "login": {
      "uuid": "0064a294-ab32-4ab9-b4ee-d1bce5659f65",
      "username": "whitebutterfly802",
      "password": "jagger",
      "salt": "O8rIqUxs",
      "md5": "035a2a316bf3165b8262f072b5896ecd",
      "sha1": "7701ab631005b18d632854c1a026e03ebed9b3d7",
      "sha256": "10232d8def510298853885a1bdbee723f91d3da832e0928f4b12077001165559"
    },
    "dob": {
      "date": "1990-09-09T02:58:11Z",
      "age": 28
    },
    "registered": {
      "date": "2016-07-04T07:47:50Z",
      "age": 3
    },
    "phone": "04-031-964",
    "cell": "046-053-79-07",
    "id": {
      "name": "HETU",
      "value": "NaNNA979undefined"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/83.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/83.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/83.jpg"
    },
    "nat": "FI"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "noham",
      "last": "gerard"
    },
    "location": {
      "street": "3851 rue louis-garrand",
      "city": "fort-de-france",
      "state": "martinique",
      "postcode": 30483,
      "coordinates": {
        "latitude": "79.8405",
        "longitude": "113.0485"
      },
      "timezone": {
        "offset": "-11:00",
        "description": "Midway Island, Samoa"
      }
    },
    "email": "noham.gerard@example.com",
    "login": {
      "uuid": "ed1ae7ac-2472-4839-a9b9-faafb98301e5",
      "username": "greenbird315",
      "password": "damon",
      "salt": "3qQi5Rtt",
      "md5": "365c0a94ea9c20ba27122efdde22394b",
      "sha1": "bb07fbf136aa13ee5f4a797e904881ca42a763f4",
      "sha256": "7b2785077c8a70dd426b26204a894c03d8b1a567beac20dc53c798460d89fd5e"
    },
    "dob": {
      "date": "1947-04-04T19:19:23Z",
      "age": 72
    },
    "registered": {
      "date": "2005-06-05T23:15:37Z",
      "age": 14
    },
    "phone": "03-98-48-31-16",
    "cell": "06-97-08-70-40",
    "id": {
      "name": "INSEE",
      "value": "1NNaN62328018 51"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/76.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/76.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/76.jpg"
    },
    "nat": "FR"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "chantal",
      "last": "zielinski"
    },
    "location": {
      "street": "eichenweg 148",
      "city": "dransfeld",
      "state": "hessen",
      "postcode": 44788,
      "coordinates": {
        "latitude": "-38.8158",
        "longitude": "-100.1634"
      },
      "timezone": {
        "offset": "+7:00",
        "description": "Bangkok, Hanoi, Jakarta"
      }
    },
    "email": "chantal.zielinski@example.com",
    "login": {
      "uuid": "49e8c87b-0dc5-4498-8ed5-0457de9e9f74",
      "username": "happyfrog143",
      "password": "sherry",
      "salt": "YeRhCpNh",
      "md5": "7879164933087d2d0c954e3ce457bf25",
      "sha1": "f560b0a4255687a4e92e254e35c9b6d4784d095f",
      "sha256": "89d3fdd38a8b07ce328ef673ec446ee73d061aa78a6a5f60208c73435a84cca4"
    },
    "dob": {
      "date": "1951-06-20T09:08:31Z",
      "age": 68
    },
    "registered": {
      "date": "2009-02-27T01:51:45Z",
      "age": 10
    },
    "phone": "0495-8068460",
    "cell": "0177-7711997",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/2.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/2.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/2.jpg"
    },
    "nat": "DE"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "angie",
      "last": "smythe"
    },
    "location": {
      "street": "1530 park avenue",
      "city": "carrick-on-shannon",
      "state": "leitrim",
      "postcode": 14652,
      "coordinates": {
        "latitude": "-86.0962",
        "longitude": "-120.6597"
      },
      "timezone": {
        "offset": "+5:30",
        "description": "Bombay, Calcutta, Madras, New Delhi"
      }
    },
    "email": "angie.smythe@example.com",
    "login": {
      "uuid": "5b813864-4a46-4db1-8bf0-9d19d31dc656",
      "username": "bigfish964",
      "password": "silly",
      "salt": "mXp8Mdpy",
      "md5": "50b6986cefd6e76a38cf5afb2e3f46cb",
      "sha1": "d74498a5aba084ed652a28a7468b4adbc01c509f",
      "sha256": "5989db946cf105e31639c8a05ffd52861b81cbe17071bbf8abaeb75fb18744d2"
    },
    "dob": {
      "date": "1975-08-18T02:34:53Z",
      "age": 44
    },
    "registered": {
      "date": "2003-02-14T17:32:11Z",
      "age": 16
    },
    "phone": "051-159-6591",
    "cell": "081-387-4799",
    "id": {
      "name": "PPS",
      "value": "6754276T"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/65.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/65.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/65.jpg"
    },
    "nat": "IE"
  },
  {
    "gender": "female",
    "name": {
      "title": "madame",
      "first": "eline",
      "last": "marie"
    },
    "location": {
      "street": "4159 avenue debourg",
      "city": "bellikon",
      "state": "luzern",
      "postcode": 9962,
      "coordinates": {
        "latitude": "53.6701",
        "longitude": "-96.6590"
      },
      "timezone": {
        "offset": "+3:00",
        "description": "Baghdad, Riyadh, Moscow, St. Petersburg"
      }
    },
    "email": "eline.marie@example.com",
    "login": {
      "uuid": "265c405c-88a5-4033-adac-42ff7fa5e6f7",
      "username": "heavypeacock539",
      "password": "blue42",
      "salt": "OUaFUXHl",
      "md5": "13be35eae00cdb61f20c046b540cb2eb",
      "sha1": "4dada43c74fe15fcf374d7027bed8ad746eb1aab",
      "sha256": "345d924f0a6f1de4607a51d19a62272e01120744ddf3802922b8bbdbc1e2daba"
    },
    "dob": {
      "date": "1960-07-10T21:31:59Z",
      "age": 59
    },
    "registered": {
      "date": "2007-04-15T13:42:16Z",
      "age": 12
    },
    "phone": "(716)-961-0720",
    "cell": "(103)-784-1359",
    "id": {
      "name": "AVS",
      "value": "756.9841.0971.70"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/63.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/63.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/63.jpg"
    },
    "nat": "CH"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "anton",
      "last": "johansen"
    },
    "location": {
      "street": "8231 mellemgade",
      "city": "ansager",
      "state": "sjælland",
      "postcode": 27899,
      "coordinates": {
        "latitude": "-51.2325",
        "longitude": "77.4085"
      },
      "timezone": {
        "offset": "+7:00",
        "description": "Bangkok, Hanoi, Jakarta"
      }
    },
    "email": "anton.johansen@example.com",
    "login": {
      "uuid": "d49f06ee-e197-4753-9b66-7e7c702de1b9",
      "username": "orangegoose400",
      "password": "142536",
      "salt": "zBovqXiV",
      "md5": "ab537b60fab4cad976e2ad0883cf14f4",
      "sha1": "c48da7b29f2336e14e20d2bc4253b805ed6b5dc1",
      "sha256": "907fc6b46a2a17d8529e8f935047ab46758b368d2d479b94db451be59f8e88b8"
    },
    "dob": {
      "date": "1953-08-04T02:03:50Z",
      "age": 66
    },
    "registered": {
      "date": "2002-10-10T15:26:40Z",
      "age": 16
    },
    "phone": "82664398",
    "cell": "11758877",
    "id": {
      "name": "CPR",
      "value": "096103-7160"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/98.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/98.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/98.jpg"
    },
    "nat": "DK"
  },
  {
    "gender": "female",
    "name": {
      "title": "ms",
      "first": "thea",
      "last": "rasmussen"
    },
    "location": {
      "street": "3900 bytoften",
      "city": "frederiksberg",
      "state": "danmark",
      "postcode": 82868,
      "coordinates": {
        "latitude": "-49.2426",
        "longitude": "148.6787"
      },
      "timezone": {
        "offset": "+11:00",
        "description": "Magadan, Solomon Islands, New Caledonia"
      }
    },
    "email": "thea.rasmussen@example.com",
    "login": {
      "uuid": "fa07efd8-03c7-431e-9278-45b7925956a9",
      "username": "bigbutterfly545",
      "password": "jimmys",
      "salt": "VEvw96nO",
      "md5": "fd6f298e138a092a2fa813b6dfe5b6af",
      "sha1": "5703bd80d9e76834a6a2eb9088474f0c9a437528",
      "sha256": "c624329bbc34382020d28a20f7dd16375f1f2bf5acd2eff2de5dd7359d77ffea"
    },
    "dob": {
      "date": "1970-11-17T16:12:02Z",
      "age": 48
    },
    "registered": {
      "date": "2016-09-10T01:28:07Z",
      "age": 2
    },
    "phone": "97209755",
    "cell": "80512676",
    "id": {
      "name": "CPR",
      "value": "115798-2645"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/15.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/15.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/15.jpg"
    },
    "nat": "DK"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "dustin",
      "last": "johnson"
    },
    "location": {
      "street": "3584 poplar dr",
      "city": "grand rapids",
      "state": "south dakota",
      "postcode": 99263,
      "coordinates": {
        "latitude": "71.7869",
        "longitude": "2.5126"
      },
      "timezone": {
        "offset": "+9:00",
        "description": "Tokyo, Seoul, Osaka, Sapporo, Yakutsk"
      }
    },
    "email": "dustin.johnson@example.com",
    "login": {
      "uuid": "e028a715-336a-4854-bb42-c5b0e400cf8a",
      "username": "sadwolf489",
      "password": "forget",
      "salt": "NhoBmSiW",
      "md5": "5d14602bb5189291f318d75b74e9df3b",
      "sha1": "072a4e56956ef793063a1c50aef58efd0a1e8103",
      "sha256": "ee5856a941fc32833fb6dc45b1efe020e0bdb13512e0ad877ec2071343fc797b"
    },
    "dob": {
      "date": "1959-09-24T12:57:56Z",
      "age": 59
    },
    "registered": {
      "date": "2002-04-16T10:46:39Z",
      "age": 17
    },
    "phone": "(911)-537-8757",
    "cell": "(995)-230-9297",
    "id": {
      "name": "SSN",
      "value": "548-01-4458"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/96.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/96.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/96.jpg"
    },
    "nat": "US"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "lois",
      "last": "palmer"
    },
    "location": {
      "street": "6054 hickory creek dr",
      "city": "coffs harbour",
      "state": "south australia",
      "postcode": 7507,
      "coordinates": {
        "latitude": "-34.2544",
        "longitude": "-52.2579"
      },
      "timezone": {
        "offset": "-6:00",
        "description": "Central Time (US & Canada), Mexico City"
      }
    },
    "email": "lois.palmer@example.com",
    "login": {
      "uuid": "ba71a04f-4f2f-4193-81d2-367cd3045a91",
      "username": "happybear516",
      "password": "redsox1",
      "salt": "L8gY68bp",
      "md5": "054001506173ffce442c16705ace26e2",
      "sha1": "9ce6b204bc391d604b32ca8b42c4925e3fc3533f",
      "sha256": "e71cfae51e7206b9b13f3f12a568d6eb136f73149b3c6c886864a1bf40c98de9"
    },
    "dob": {
      "date": "1981-06-22T22:09:20Z",
      "age": 38
    },
    "registered": {
      "date": "2013-05-04T15:39:33Z",
      "age": 6
    },
    "phone": "01-9401-6646",
    "cell": "0418-527-716",
    "id": {
      "name": "TFN",
      "value": "815313167"
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/76.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/76.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/76.jpg"
    },
    "nat": "AU"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "ceylan",
      "last": "karaböcek"
    },
    "location": {
      "street": "7128 bağdat cd",
      "city": "konya",
      "state": "şırnak",
      "postcode": 86305,
      "coordinates": {
        "latitude": "82.1077",
        "longitude": "114.8293"
      },
      "timezone": {
        "offset": "-7:00",
        "description": "Mountain Time (US & Canada)"
      }
    },
    "email": "ceylan.karaböcek@example.com",
    "login": {
      "uuid": "752eb432-ed60-448b-982f-660047ea93e4",
      "username": "heavyfish839",
      "password": "wildfire",
      "salt": "lR4s3nXH",
      "md5": "29db6c3153f689332d52d0bfe49f035a",
      "sha1": "9867ecc4d57d04beb2ef2bfb455d148ea8c8e513",
      "sha256": "9febb22f894102cb9011eb81e5b6742b49da713f1f22b03bdb3a90fde8cc858a"
    },
    "dob": {
      "date": "1956-02-17T09:06:07Z",
      "age": 63
    },
    "registered": {
      "date": "2016-01-02T12:55:09Z",
      "age": 3
    },
    "phone": "(234)-722-0371",
    "cell": "(752)-848-1554",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/women/3.jpg",
      "medium": "https://randomuser.me/api/portraits/med/women/3.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/women/3.jpg"
    },
    "nat": "TR"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "jochen",
      "last": "klinge"
    },
    "location": {
      "street": "mühlenstraße 177",
      "city": "diepholz",
      "state": "nordrhein-westfalen",
      "postcode": 65892,
      "coordinates": {
        "latitude": "6.4608",
        "longitude": "-49.6081"
      },
      "timezone": {
        "offset": "-8:00",
        "description": "Pacific Time (US & Canada)"
      }
    },
    "email": "jochen.klinge@example.com",
    "login": {
      "uuid": "ab069b95-387b-4386-9ea4-1a88191b8c07",
      "username": "lazykoala520",
      "password": "orion",
      "salt": "cL8lIdGY",
      "md5": "0f7b789560090ca5c7b1fc5062e9fc7b",
      "sha1": "1a79140ccef9c6e2e2b1d4c3b81afaa436dd4e96",
      "sha256": "592a73e5f5bf9e9e3253b95748332c5f02822799a90d8dcc2f3cee77ee4b71d4"
    },
    "dob": {
      "date": "1951-06-21T05:11:11Z",
      "age": 68
    },
    "registered": {
      "date": "2015-07-19T18:54:34Z",
      "age": 4
    },
    "phone": "0508-8718996",
    "cell": "0174-1187627",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "https://randomuser.me/api/portraits/men/63.jpg",
      "medium": "https://randomuser.me/api/portraits/med/men/63.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/63.jpg"
    },
    "nat": "DE"
  }
];

const monumentos = [
  {
    "latitude": 40.416875,
    "longitude": -3.703308,
    "city": "Madrid",
    "description": "Puerta del Sol",
    "foto": "https://www.abc.es/media/espana/2016/05/02/sol-madrid_xoptimizadax--620x349.jpg",
  },
  {
    "latitude": 40.417438,
    "longitude": -3.693363,
    "city": "Madrid",
    "description": "Museo del Prado",
    "foto": "http://img2.rtve.es/i/?w=1600&i=1511794284649.jpg",
  },
  {
    "latitude": 40.407015,
    "longitude": -3.691163,
    "city": "Madrid",
    "description": "Estación de Atocha",
    "foto": "https://www.esmadrid.com/sites/default/files/styles/content_type_full/public/recursosturisticos/infoturistica/EstaciondeAtochaBarea_1404815129.73.jpg?itok=1uMTGbUt",
  }
];

const menu = [
  {
    "nombre": "Gofres Belgas",
    "precio": 5.95,
    "descripcion": "Dos de nuestros famosos Gofres belgas con abundante sirope",
    "calorias": 650,
    "carta": "desayuno",
    "imagen": "https://i.ytimg.com/vi/kB-NtTwLYW0/maxresdefault.jpg"
  },
  {
    "nombre": "Gofres Belgas con fresas",
    "precio": 7.95,
    "descripcion": "Ligeros gofres belgas cubiertos de fresas y nata montada",
    "calorias": 900,
    "carta": "desayuno",
    "imagen": "https://images.freeimages.com/images/premium/previews/2045/20454301-belgian-waffle-with-strawberries.jpg"
  },
  {
    "nombre": "Gofres Belgas con frutas del bosque",
    "precio": 8.95,
    "descripcion": "Ligeros gofres belgas cubiertos de frutas del bosque y nata montada",
    "calorias": 900,
    "carta": "desayuno",
    "imagen": "https://previews.123rf.com/images/merc67/merc671507/merc67150700302/42737701-verano-el-desayuno-gofres-belgas-con-frutas-frescas-y-miel.jpg"
  },
  {
    "nombre": "Tostada Francesa",
    "precio": 4.5,
    "descripcion": "Dos gruesas rebanadas de nuestro pan frances casero",
    "calorias": 600,
    "carta": "desayuno",
    "imagen": "https://www.rebanando.com/media/tostadas-francesas-french-toast-jpg_crop.jpeg/rh/tostadas-francesas-french-toast.jpg"
  },
  {
    "nombre": "Desayuno de la casa",
    "precio": 6.95,
    "descripcion": "Dos huevos, bacon o salchicha, tostada y patatas fritas",
    "calorias": 950,
    "carta": "desayuno",
    "imagen": "http://www.contigosalud.com/files/content/2016/Articulos%202016/desayuno%20fuera.jpg"

  },
  {
    "nombre": "Solomillo en salsa",
    "precio": 14.50,
    "descripcion": "Medallones de solomillo con salsa de pimienta verde o woronoff a elegir",
    "calorias": 1000,
    "carta": "cena",
    "imagen": "https://www.annarecetasfaciles.com/files/solomillo-al-vino.jpg"
  },
  {
    "nombre": "Macarrones con chorizo",
    "precio": 7.95,
    "descripcion": "Macarrones con salsa italiana de tomate y chorizo seco",
    "calorias": 850,
    "carta": "almuerzo",
    "imagen": "https://www.cocinacaserayfacil.net/wp-content/uploads/2020/04/Recetas-de-comidas-para-ni%C3%B1os.jpg"
  },
  {
    "nombre": "Callos",
    "precio": 6.95,
    "descripcion": "cazuela para una persona de callos clasicos",
    "calorias": 1000,
    "carta": "almuerzo",
    "imagen": "https://i.blogs.es/19bd5c/callos/450_1000.jpg"
  },
  {
    "nombre": "Hamburguesa Gourmet",
    "precio": 10.25,
    "descripcion": "Carne de vacuno con lechuga, maiz, pepinillos, tomate, huevo frito ,etc",
    "calorias": 1000,
    "carta": "cena",
    "imagen": "https://sevilla.abc.es/gurme/wp-content/uploads/sites/24/2012/01/comida-rapida-casera.jpg"
  },
  {
    "nombre": "Tortilla de patatas",
    "precio": 4.67,
    "descripcion": "Tortilla de patatas clasica sin cebolla",
    "calorias": 500,
    "carta": "cena",
    "imagen": "https://lacocinadefrabisa.lavozdegalicia.es/wp-content/uploads/2019/05/tortilla-espa%C3%B1ola.jpg"
  }

]
const canciones = [
  {
    "titulo": "Spring Village",
    "autor": "John Sean",
    "url": "https://patrickdearteaga.com/audio/Spring%20Village.ogg"
  },
  {
    "titulo": "No Place For Straw Cowboys",
    "autor": "Max Anton",
    "url": "https://patrickdearteaga.com/audio/No%20Place%20For%20Straw%20Cowboys.ogg"
  },
  {
    "titulo": "Battleship",
    "autor": "Anthony Weack",
    "url": "https://patrickdearteaga.com/audio/Battleship.ogg"
  },
  {
    "titulo": "Not Giving Up",
    "autor": "Patrick de Arteaga",
    "url": "https://patrickdearteaga.com/audio/Not%20Giving%20Up.ogg"
  },
  {
    "titulo": "Dreaming",
    "autor": "Patrick de Arteaga",
    "url": "https://patrickdearteaga.com/audio/Dreaming.ogg"
  },
  {
    "titulo": "It´s time to run",
    "autor": "Bernard Sanders",
    "url": "https://patrickdearteaga.com/audio/It's%20Time%20To%20Run.ogg"
  },
  {
    "titulo": "Biological Weapon",
    "autor": "Anthony Weack",
    "url": "https://patrickdearteaga.com/audio/Biological%20Weapon.ogg"
  },
  {
    "titulo": "Ruined Planet",
    "autor": "John Sean",
    "url": "https://patrickdearteaga.com/audio/Ruined%20Planet.ogg"
  },
  {
    "titulo": "Central City",
    "autor": "Patrick de Arteaga",
    "url": "https://patrickdearteaga.com/audio/Central%20City.ogg"
  },
  {
    "titulo": "New Hope",
    "autor": "Patrick de Arteaga",
    "url": "https://patrickdearteaga.com/audio/New%20Hope.ogg"
  },
];
const liga = {
  "competition": {
    "id": 2021,
    "area": {
      "id": 2072,
      "name": "England"
    },
    "name": "Premier League",
    "code": "PL",
    "plan": "TIER_ONE",
    "lastUpdated": "2018-08-23T11:51:26Z"
  },
  "season": {
    "id": 151,
    "startDate": "2018-08-10",
    "endDate": "2019-05-12",
    "currentMatchday": 3,
    "availableStages": [
      "REGULAR_SEASON"
    ]
  },
  "standings": [
    {
      "stage": "REGULAR_SEASON",
      "type": "TOTAL",
      "table": [
        {
          "position": 1,
          "team": {
            "id": 65,
            "name": "Manchester City FC",
            "crestUrl": "https://upload.wikimedia.org/wikipedia/en/e/eb/Manchester_City_FC_badge.svg"
          },
          "playedGames": 2,
          "won": 2,
          "draw": 0,
          "lost": 0,
          "points": 6,
          "goalsFor": 8,
          "goalsAgainst": 1,
          "goalDifference": 7
        },
        {
          "position": 2,
          "team": {
            "id": 64,
            "name": "Liverpool FC",
            "crestUrl": "http://upload.wikimedia.org/wikipedia/de/0/0a/FC_Liverpool.svg"
          },
          "playedGames": 2,
          "won": 2,
          "draw": 0,
          "lost": 0,
          "points": 6,
          "goalsFor": 6,
          "goalsAgainst": 0,
          "goalDifference": 6
        },
        {
          "position": 3,
          "team": {
            "id": 61,
            "name": "Chelsea FC",
            "crestUrl": "http://upload.wikimedia.org/wikipedia/de/5/5c/Chelsea_crest.svg"
          },
          "playedGames": 2,
          "won": 2,
          "draw": 0,
          "lost": 0,
          "points": 6,
          "goalsFor": 6,
          "goalsAgainst": 2,
          "goalDifference": 4
        },
        {
          "position": 4,
          "team": {
            "id": 346,
            "name": "Watford FC",
            "crestUrl": "https://upload.wikimedia.org/wikipedia/en/e/e2/Watford.svg"
          },
          "playedGames": 2,
          "won": 2,
          "draw": 0,
          "lost": 0,
          "points": 6,
          "goalsFor": 5,
          "goalsAgainst": 1,
          "goalDifference": 4
        },
        {
          "position": 5,
          "team": {
            "id": 73,
            "name": "Tottenham Hotspur FC",
            "crestUrl": "http://upload.wikimedia.org/wikipedia/de/b/b4/Tottenham_Hotspur.svg"
          },
          "playedGames": 2,
          "won": 2,
          "draw": 0,
          "lost": 0,
          "points": 6,
          "goalsFor": 5,
          "goalsAgainst": 2,
          "goalDifference": 3
        },
        {
          "position": 6,
          "team": {
            "id": 1044,
            "name": "AFC Bournemouth",
            "crestUrl": "https://upload.wikimedia.org/wikipedia/de/4/41/Afc_bournemouth.svg"
          },
          "playedGames": 2,
          "won": 2,
          "draw": 0,
          "lost": 0,
          "points": 6,
          "goalsFor": 4,
          "goalsAgainst": 1,
          "goalDifference": 3
        },
        {
          "position": 7,
          "team": {
            "id": 62,
            "name": "Everton FC",
            "crestUrl": "http://upload.wikimedia.org/wikipedia/de/f/f9/Everton_FC.svg"
          },
          "playedGames": 2,
          "won": 1,
          "draw": 1,
          "lost": 0,
          "points": 4,
          "goalsFor": 4,
          "goalsAgainst": 3,
          "goalDifference": 1
        },
        {
          "position": 8,
          "team": {
            "id": 338,
            "name": "Leicester City FC",
            "crestUrl": "http://upload.wikimedia.org/wikipedia/en/6/63/Leicester02.png"
          },
          "playedGames": 2,
          "won": 1,
          "draw": 0,
          "lost": 1,
          "points": 3,
          "goalsFor": 3,
          "goalsAgainst": 2,
          "goalDifference": 1
        },
        {
          "position": 9,
          "team": {
            "id": 66,
            "name": "Manchester United FC",
            "crestUrl": "http://upload.wikimedia.org/wikipedia/de/d/da/Manchester_United_FC.svg"
          },
          "playedGames": 2,
          "won": 1,
          "draw": 0,
          "lost": 1,
          "points": 3,
          "goalsFor": 4,
          "goalsAgainst": 4,
          "goalDifference": 0
        },
        {
          "position": 10,
          "team": {
            "id": 354,
            "name": "Crystal Palace FC",
            "crestUrl": "http://upload.wikimedia.org/wikipedia/de/b/bf/Crystal_Palace_F.C._logo_%282013%29.png"
          },
          "playedGames": 2,
          "won": 1,
          "draw": 0,
          "lost": 1,
          "points": 3,
          "goalsFor": 2,
          "goalsAgainst": 2,
          "goalDifference": 0
        },
        {
          "position": 11,
          "team": {
            "id": 397,
            "name": "Brighton & Hove Albion FC",
            "crestUrl": "https://upload.wikimedia.org/wikipedia/en/f/fd/Brighton_%26_Hove_Albion_logo.svg"
          },
          "playedGames": 2,
          "won": 1,
          "draw": 0,
          "lost": 1,
          "points": 3,
          "goalsFor": 3,
          "goalsAgainst": 4,
          "goalDifference": -1
        },
        {
          "position": 12,
          "team": {
            "id": 67,
            "name": "Newcastle United FC",
            "crestUrl": "http://upload.wikimedia.org/wikipedia/de/5/56/Newcastle_United_Logo.svg"
          },
          "playedGames": 2,
          "won": 0,
          "draw": 1,
          "lost": 1,
          "points": 1,
          "goalsFor": 1,
          "goalsAgainst": 2,
          "goalDifference": -1
        },
        {
          "position": 13,
          "team": {
            "id": 340,
            "name": "Southampton FC",
            "crestUrl": "http://upload.wikimedia.org/wikipedia/de/c/c9/FC_Southampton.svg"
          },
          "playedGames": 2,
          "won": 0,
          "draw": 1,
          "lost": 1,
          "points": 1,
          "goalsFor": 1,
          "goalsAgainst": 2,
          "goalDifference": -1
        },
        {
          "position": 14,
          "team": {
            "id": 76,
            "name": "Wolverhampton Wanderers FC",
            "crestUrl": "https://upload.wikimedia.org/wikipedia/en/f/fc/Wolverhampton_Wanderers.svg"
          },
          "playedGames": 2,
          "won": 0,
          "draw": 1,
          "lost": 1,
          "points": 1,
          "goalsFor": 2,
          "goalsAgainst": 4,
          "goalDifference": -2
        },
        {
          "position": 15,
          "team": {
            "id": 328,
            "name": "Burnley FC",
            "crestUrl": "https://upload.wikimedia.org/wikipedia/en/0/02/Burnley_FC_badge.png"
          },
          "playedGames": 2,
          "won": 0,
          "draw": 1,
          "lost": 1,
          "points": 1,
          "goalsFor": 1,
          "goalsAgainst": 3,
          "goalDifference": -2
        },
        {
          "position": 16,
          "team": {
            "id": 715,
            "name": "Cardiff City FC",
            "crestUrl": "https://upload.wikimedia.org/wikipedia/en/3/3c/Cardiff_City_crest.svg"
          },
          "playedGames": 2,
          "won": 0,
          "draw": 1,
          "lost": 1,
          "points": 1,
          "goalsFor": 0,
          "goalsAgainst": 2,
          "goalDifference": -2
        },
        {
          "position": 17,
          "team": {
            "id": 57,
            "name": "Arsenal FC",
            "crestUrl": "http://upload.wikimedia.org/wikipedia/en/5/53/Arsenal_FC.svg"
          },
          "playedGames": 2,
          "won": 0,
          "draw": 0,
          "lost": 2,
          "points": 0,
          "goalsFor": 2,
          "goalsAgainst": 5,
          "goalDifference": -3
        },
        {
          "position": 18,
          "team": {
            "id": 63,
            "name": "Fulham FC",
            "crestUrl": "http://upload.wikimedia.org/wikipedia/de/a/a8/Fulham_fc.svg"
          },
          "playedGames": 2,
          "won": 0,
          "draw": 0,
          "lost": 2,
          "points": 0,
          "goalsFor": 1,
          "goalsAgainst": 5,
          "goalDifference": -4
        },
        {
          "position": 19,
          "team": {
            "id": 563,
            "name": "West Ham United FC",
            "crestUrl": "http://upload.wikimedia.org/wikipedia/de/e/e0/West_Ham_United_FC.svg"
          },
          "playedGames": 2,
          "won": 0,
          "draw": 0,
          "lost": 2,
          "points": 0,
          "goalsFor": 1,
          "goalsAgainst": 6,
          "goalDifference": -5
        },
        {
          "position": 20,
          "team": {
            "id": 394,
            "name": "Huddersfield Town AFC",
            "crestUrl": "https://upload.wikimedia.org/wikipedia/en/5/5a/Huddersfield_Town_A.F.C._logo.svg"
          },
          "playedGames": 2,
          "won": 0,
          "draw": 0,
          "lost": 2,
          "points": 0,
          "goalsFor": 1,
          "goalsAgainst": 9,
          "goalDifference": -8
        }
      ]
    }
  ]
}

const tienda = [
  {
    "titulo": "Still got the blues",
    "artista": "Gary Moore",
    "pais": "UK",
    "precio": 13.20,
    "publicacion": 1990,
    "copias": 120, //miles de copias
    "caratula": "https://images-na.ssl-images-amazon.com/images/I/71o6gIerHwL._SY355_.jpg"
  },
  {
    "titulo": "One night only",
    "artista": "Bee Gees",
    "pais": "UK",
    "precio": 11.90,
    "copias": 200,
    "publicacion": 1998,
    "caratula": "https://is5-ssl.mzstatic.com/image/thumb/Music111/v4/fe/9c/c2/fe9cc271-e47a-28f4-c5b4-505da8d2ef10/UMG_cvrart_00731455922028_01_RGB72_1800x1800_06UMGIM54033.jpg/268x0w.jpg"
  },
  {
    "titulo": "When a man loves a women",
    "artista": "Percy Sleedge",
    "pais": "USA",
    "precio": 8.70,
    "copias": 450,
    "publicacion": 1987,
    "caratula": "https://images-na.ssl-images-amazon.com/images/I/41RST7VYA1L.jpg"
  },
  {
    "titulo": "Big Willie style",
    "artista": "Will Smith",
    "pais": "USA",
    "precio": 9.90,
    "copias": 10,
    "publicacion": 1997,
    "caratula": "https://images-na.ssl-images-amazon.com/images/I/517N7Y7xjUL._SY355_.jpg"
  },
  {
    "titulo": "La cancion de Juan Perro",
    "artista": "Radio Futura",
    "pais": "ESP",
    "precio": 12,
    "copias": 68,
    "publicacion": 1987,
    "caratula": "http://lafonoteca.net/wp-content/uploads/2008/11/Radio_Futura-La_Cancion_De_Juan_Perro-Frontal-600x600.jpg"
  },
  {
    "titulo": "The dock of the bay",
    "artista": "Otis Redding",
    "pais": "USA",
    "precio": 7.9,
    "copias": 123,
    "publicacion": 1987,
    "caratula": "http://images.tritondigitalcms.com/6616/sites/374/2018/03/15091232/otis-dock-45.jpg"
  },
  {
    "titulo": "The Dark Side of the Moon",
    "artista": "Pink Floyd",
    "pais": "UK",
    "precio": 10.9,
    "copias": 50,
    "publicacion": 1987,
    "caratula": "https://www.discogs.com/es/Pink-Floyd-The-Dark-Side-Of-The-Moon/master/10362"
  },
  {
    "titulo": "Kill 'em all",
    "artista": "Metallica",
    "pais": "UK",
    "precio": 15.6,
    "copias": 123,
    "publicacion": 1986,
    "caratula": "https://pbs.twimg.com/media/EdyeXaIXkAUvn9D.png"
  },
  {
    "titulo": "Un dia cualquiera",
    "artista": "Nacha Pop",
    "pais": "ESP",
    "precio": 5.9,
    "copias": 60,
    "publicacion": 2003,
    "caratula": "https://cloud10.todocoleccion.online/musica-cds/fot/2006/07/27/3157127.jpg"
  }


];

const noticias = {
  "page": {
    "items": [
      {
        "uri": "http://www.rtve.es/api/noticias/2175876",
        "htmlUrl": "https://www.rtve.es/television/20211007/dia-mundial-depresion/2175876.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2175876/",
        "id": "2175876",
        "language": "es",
        "shortTitle": "De la tristeza a la depresión hay un paso",
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/132017",
        "popularity": "0.0",
        "popHistoric": "8.0",
        "numVisits": "0",
        "publicationDate": "07-10-2021 08:00:00",
        "expirationDate": null,
        "modificationDate": "30-09-2021 16:40:34",
        "publicationDateTimestamp": 1633586400000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2175876/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/dia-europeo-depresion/1633012602644.jpg",
        "imageSEO": "https://img2.rtve.es/n/dia-mundial-depresion_2175876.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": null,
        "anteTitleUrl": null,
        "longTitle": "De la tristeza a la depresión hay un paso",
        "frontTitle": "De la tristeza a la depresión hay un paso",
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<p><span class=\"hddn\"><a href=\"\">&nbsp;<strong>Noticia</strong>&nbsp;</a>&nbsp;<a href=\"https://www.rtve.es/television/archivo/\">&nbsp;<em>Archivo sonoro de RNE</em>&nbsp;</a>&nbsp;</span></p>\n\n<ul>\n\t<li>En el D&iacute;a Europeo de la Depresi&oacute;n recordamos esta enfermedad que cada vez padecen m&aacute;s personas</li>\n\t<li>Un recorrido que hacemos gracias a los sonidos del Archivo RNE</li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p style=\"text-align: center;\">&quot;Es una enfermedad interior tan grande que no se puede explicar con palabras, porque es la mente y el alma. No encuentras aliciente. Lo &uacute;nico que quieres es morirte&quot;.</p>\n\n<p style=\"text-align: center;\">&quot;Una depresi&oacute;n es un pozo sin fondo, sin luz, ni esperanza, ni salida. Es como un monstruo que te est&aacute; comiendo por dentro&quot;.</p>\n\n<p>Son algunos de los testimonios de personas que sufren depresi&oacute;n y que recog&iacute;an en&nbsp;<em><a href=\"https://www.rtve.es/play/audios/gente-despierta/\">Gente despierta</a>.&nbsp;</em>En la antig&uuml;edad se pensaba que, si la tristeza se prolongaba durante un periodo de tiempo largo, se estaba sufriendo melancol&iacute;a. Ese abatimiento es lo que en la actualidad denominamos como depresi&oacute;n. Un t&eacute;rmino que fue acu&ntilde;ado en el&nbsp;<strong>siglo XVIII&nbsp;</strong>y que significa empujar, oprimir hacia abajo.&nbsp;</p>\n\n<h2 class=\"ladillo\">Cu&aacute;les son los s&iacute;ntomas principales</h2>\n\n<p>Para hablar de la depresi&oacute;n cont&aacute;bamos con el testimonio de&nbsp;<strong>Jos&eacute; Luis Carrasco</strong>, catedr&aacute;tico de&nbsp;<strong>Psiquiatr&iacute;a de la Universidad Complutense de Madrid</strong>&nbsp;y director de la<strong>&nbsp;Unidad de Trastornos L&iacute;mites de la Personalidad</strong>: &quot;Es una enfermedad, una situaci&oacute;n que no es normal, por eso entra en la&#160;<a href=\"https://www.rtve.es/noticias/20210406/expertos-advierten-problemas-salud-mental-seran-otra-pandemia-tras-coronavirus/2084761.shtml\">categor&iacute;a de trastorno</a>. La podemos reconocer por dos s&iacute;ntomas fundamentales, uno es el hundimiento del estado de &aacute;nimo y el otro una p&eacute;rdida importante del inter&eacute;s por todo. Un estado que va m&aacute;s all&aacute; de una tristeza, viene de dentro&quot;.</p>\n\n<p>Adem&aacute;s, podemos saberlo porque la depresi&oacute;n se perpetua, se mantiene: &quot;A pesar de que los acontecimientos que hab&iacute;an provocado la tristeza hayan desaparecido, el sentimiento contin&uacute;a. Podemos ver tambi&eacute;n como afecta al cuerpo; el paciente que tiene depresi&oacute;n lo cuenta como algo que est&aacute; arraigado en todo su ser.&nbsp;<strong>Le hace sentir una especie de losa, le resulta imposible explicarlo</strong>&quot;.</p>\n\n<p>@@MEDIA[3971283,a]</p>\n\n<h2 class=\"ladillo\">Principales causas</h2>\n\n<p>Como en todas las enfermedades hay una vulnerabilidad. Existen causas biol&oacute;gicas y gen&eacute;ticas. Pero debe haber una trayectoria en la vida con una serie de emociones, de afrontar las situaciones, que determinan si desembocar&aacute; en un estado de depresi&oacute;n o no. En algunos casos hay una vulnerabilidad biol&oacute;gica importante, una carga gen&eacute;tica. Pero tambi&eacute;n influye el&nbsp;ambiente, el aprendizaje y el&nbsp;desarrollo.</p>\n\n<p>En<em>&nbsp;<a href=\"https://www.rtve.es/play/audios/de-vuelta-en-radio-5/\">De vuelta en Radio 5</a>&nbsp;</em>conversaron con algunos pacientes que padecen esta dura enfermedad, &iquest;Qu&eacute; supone para ellos?: &quot;La gente se piensa que la depresi&oacute;n es lo que le pasa cuando un d&iacute;a te levantas triste o sin ganas de nada, con ganas de llorar&quot;, &quot;yo me qued&eacute; en la calle, sin salario y sabiendo que mi carrera se hab&iacute;a ido a pique&quot;, &quot;la parte depresiva fue cuando muri&oacute; mi padre, todo se precipit&oacute; y decid&iacute; cerrar,&nbsp;<strong>me sent&iacute; culpable de muchas cosas</strong>&quot;, &quot;tengo dificultades para hablar, y piensas,&nbsp;<strong>&iquest;yo alg&uacute;n d&iacute;a volver&eacute; a ser la que era?</strong>&quot;, &quot;estar horas de llorar por todo, vives en una especie de niebla, pero quieres vivir y esa niebla te lo impide&quot;, &quot;<a href=\"https://www.rtve.es/noticias/20160330/suicido-sigue-como-primera-causa-muerte-externa-se-cobra-3910-vidas/1327840.shtml\">te das cuenta cuando tienes dos intentos de suicidio</a>&quot;, palabras de hombres y mujeres que nos contaban sus experiencias personales:</p>\n\n<p>@@MEDIA[6048758,a]</p>\n\n<h2 class=\"ladillo\">&quot;Depresivos, salid del armario&quot;</h2>\n\n<p>La depresi&oacute;n es una enfermedad que siempre ha estado presente. Pero&nbsp;<a href=\"https://www.rtve.es/noticias/20200630/suicidio-depresion-otra-epidemia-mas-alla-del-coronavirus/2023531.shtml\">a ra&iacute;z de la pandemia</a>, las personas que la&nbsp;padecen se han disparado.&nbsp;As&iacute; lo ha recogido<strong>&nbsp;la Organizaci&oacute;n Mundial de la Salud</strong>, han aumentado la ansiedad y las consultas en red se han incrementado en un 168,6 % desde el inicio del estado de alarma.&nbsp;<strong>Espa&ntilde;a es el cuarto pa&iacute;s de Europa con m&aacute;s casos de depresi&oacute;n</strong>. Los psic&oacute;logos y psiquiatras lo acusan ya en la consulta, el periodista&nbsp;<strong>Anxo Lugilde</strong>&nbsp;padece depresi&oacute;n desde hace 32 a&ntilde;os y lucha contra la estigmatizaci&oacute;n de esta enfermedad: &quot;<strong>Me cost&oacute; mucho contarlo</strong>, yo cre&iacute; que lo hab&iacute;a superado,&nbsp;<strong>pas&eacute; de tomar 11 pastillas a no tomar ninguna.&nbsp;</strong>Pero el confinamiento me mat&oacute;, entr&eacute; en la vor&aacute;gine de la pandemia.&nbsp;<strong>No te suelta y te lleva a deseos de muerte. Las primeras semanas de medicaci&oacute;n son horribles&quot;.</strong></p>\n\n<p>Anxo mandaba un mensaje de apoyo a todos los que la padecen: &quot;<strong>Que se dejen ayudar</strong>, que no se sientan estigmatizados, es una enfermedad como otra cualquiera, pero en el alma, en el coraz&oacute;n&quot;. Escucha la entrevista en<em>&nbsp;<a href=\"https://www.rtve.es/play/audios/las-mananas-de-rne-con-pepa-fernandez/\">De pe a pa</a>:</em></p>\n\n<p>@@MEDIA[5722321,a]</p>\n\n<h2 class=\"ladillo\">&iquest;C&oacute;mo ayudar de verdad a quien la padece?</h2>\n\n<p>Seg&uacute;n la OMS,&nbsp;<strong>m&aacute;s de trescientos millones de personas en el mundo sufren este trastorno</strong>.&nbsp;La psic&oacute;loga de cabecera,&nbsp;<strong>Alejandra Vallejo-N&aacute;gera</strong>, nos daba algunos consejos para&nbsp;cuidar a quienes sufren depresi&oacute;n: &quot;La depresi&oacute;n no tiene un term&oacute;metro, cursa con una falta de energ&iacute;a para hacer las tareas con normalidad, no te apetece nada salir, ese estado de &quot;alicaimiento&quot; es m&aacute;s acusado durante el d&iacute;a.<strong>&nbsp;Hasta que llega un momento que se unen una serie de s&iacute;ntomas que indican&nbsp;que no es una mala racha</strong>&quot;.</p>\n\n<p>Lo m&aacute;s complicado es saber por qu&eacute; y aceptar que tenemos una enfermedad por muchas razones: &quot;Lo m&aacute;s dif&iacute;cil para el deprimido y para los familiares es entender que no es algo que dependa de tu fuerza de voluntad, necesitas ayuda m&eacute;dica y terap&eacute;utica.&nbsp;<strong>Con la depresi&oacute;n se dan consejos enfocados a deber&iacute;as hacer un esfuerzo</strong>, c&oacute;mo es posible que est&eacute;s triste si lo tienes todo.<strong>&nbsp;Los pacientes tardan mucho en acudir a terapia</strong>. Como se sienten incomprendidos, llega un momento en el que se encierran en casa a llorar, solos y solas. Y si est&aacute;n en casa con m&aacute;s gente se van al ba&ntilde;o porque no se sienten&nbsp;entendidas, no se sienten&nbsp;apoyadas&quot;, aseguraba la psic&oacute;loga.</p>\n\n<p>Las personas con las que conviven a veces no las comprenden, algo que es totalmente normal seg&ccedil;un los expertos: &quot;<strong>El resto de personas que las rodean sienten que duermen mucho</strong>, pero les cuesta todo, vestirse, tomar el transporte p&uacute;blico.&nbsp;<strong>A veces, beben a escondidas para intentar reanimarse</strong>. Pero no hay que culpabilizar a la familia, ni amistades, pues no son profesionales. Los pacientes tienen miedo a la medicaci&oacute;n porque pasan de estar mal a un estado de euforia&quot;.</p>\n\n<p>Nos lo contaba en&nbsp;<strong><em>Gente despierta</em></strong>: &quot;Como familiares sin quererlo no les animamos, porque es muy desesperante y no lo entendemos.<strong><em>&nbsp;</em>Hay que ayudarle a entender que est&aacute; padeciendo una enfermedad</strong>&nbsp;y hay que acompa&ntilde;arle al m&eacute;dico al principio y no tener miedo a la medicaci&oacute;n. Tambi&eacute;n podemos preguntarle qu&eacute; podemos hacer por ellos. Y muchas veces necesitan aislarse y no les dejamos&quot;.</p>\n\n<p>@@MEDIA[4240470,a]</p>\n\n<h2 class=\"ladillo\">Depresi&oacute;n infantil</h2>\n\n<p>Muchos ni&ntilde;os y ni&ntilde;as pasan por una situaci&oacute;n de estr&eacute;s que les llevan&nbsp;a padecer esta enfermedad.&nbsp;<a href=\"https://www.rtve.es/noticias/20210714/pandemia-dispara-ansiedad-depresion-ideas-suicidas-ninos/2128561.shtml\">La pandemia ha&nbsp;venido a agravar la situaci&oacute;n</a>.&nbsp;<strong>Un informe de Save the Children&nbsp;</strong>se&ntilde;ala que tras el confinamiento&nbsp;<strong>1 de cada 6 ni&ntilde;os en nuestro pa&iacute;s</strong>&nbsp;se sent&iacute;a deprimido. Esto se debe a la p&eacute;rdida de empleo por parte de los padres o la pobreza infantil sobrevenida. En las familias con mayor vulnerabilidad econ&oacute;mica y social es donde m&aacute;s ni&ntilde;os han llorado y les han costado dormir.&nbsp;</p>\n\n<p><strong>Beatriz Mart&iacute;nez N&uacute;&ntilde;ez</strong>&nbsp;es<strong>&nbsp;psiquiatra de la infancia y la adolescencia en el hospital Ni&ntilde;o Jes&uacute;s de Madrid</strong>: &quot;<a href=\"https://www.rtve.es/noticias/20210910/pandemia-dispara-conductas-suicidas-jovenes-adolescentes/2169456.shtml\">El hecho de estar confinados ha aumentado los casos</a>, el no ver a sus compa&ntilde;eros. Problemas en el colegio con sus iguales, separaciones dif&iacute;ciles, estar enfermos, hacen al final que una preocupaci&oacute;n se encadene en la vida de los ni&ntilde;os&quot;, ha asegurado la experta.</p>\n\n<p>Nos lo contaban en<em><strong>&nbsp;Mam&aacute;s y pap&aacute;s</strong></em>&nbsp;de&nbsp;<a href=\"https://www.rtve.es/radio/radio5/\">Radio 5</a>:</p>\n\n<p>@@MEDIA[5731525,a]</p>\n\n<p>La persona que va a tener depresi&oacute;n nos manda una serie de alertas a trav&eacute;s de su cuerpo. En primer lugar, veremos que tiene un estado de &aacute;nimo bajo, una forma de retardo psicomotor, no se sienten capaces de seguir adelante. Los familiares y amigos tienen un papel fundamental a la hora de animar a acudir a un profesional. Tambi&eacute;n, podemos observar, que&nbsp;<strong>la persona que padece esta enfermedad no es capaz de generar pensamientos positivos, pierden esa capacidad natural</strong>. Pues es una enfermedad que lleva una alteraci&oacute;n del pensamiento, del estado cognitivo. Por eso, tratarla con naturalidad y&nbsp;dejar de estigmatizarla, es el primer paso para seguir adelante. Y esto, depende de todos.</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "CORA GARCÍA MONTES",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Televisión/Programas de TVE/Ciencia y Futuro/Noticias de ciencia y futuro",
        "mainCategoryLang": "Televisión/Programas de TVE/Ciencia y Futuro/Noticias de ciencia y futuro",
        "otherTopicsName": [
          "Tags Libres/Especial Noticias/Noticias RNE"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2175876/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2175876/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2175876/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2175876/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2175876/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2175876/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2175876/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2175876/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2175876/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2175876/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2175876/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2175876/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2175876/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2175876/estadisticas"
        },
        "commentOptions": {
          "code": "OP_CPERMIT",
          "description": "Permitir"
        },
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2175876/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Ciencia y futuro",
            "generoInfUid": "GE_CIENFU",
            "generoId": "136650",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "De la tristeza a la depresión hay un paso"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2181460",
        "htmlUrl": "https://www.rtve.es/noticias/20211007/podemos-universidad-otono-diaz-iglesias/2181460.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2181460/",
        "id": "2181460",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/1420",
        "popularity": "0.0",
        "popHistoric": "8.0",
        "numVisits": "0",
        "publicationDate": "07-10-2021 07:21:00",
        "expirationDate": null,
        "modificationDate": "07-10-2021 07:22:14",
        "publicationDateTimestamp": 1633584060000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2181460/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/belarra-echenique-iglesias/1633526413365.jpg",
        "imageSEO": "https://img2.rtve.es/n/podemos-universidad-otono-diaz-iglesias_2181460.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": null,
        "anteTitleUrl": null,
        "longTitle": "Podemos celebra su universidad de otoño con Iglesias y sin Díaz para relanzar su proyecto político en un momento \"crucial\"",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li>De jueves a domingo, los pesos fuertes del partido y sus m&aacute;ximos ide&oacute;logos intervendr&aacute;n en distintas ponencias</li>\n\t<li>Podemos est&aacute; &quot;reconfigurando&quot; su espacio y su marca cuando D&iacute;az, ajena al partido, se prev&eacute; candidata a las generales</li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>Es tiempo de convenciones y congresos pol&iacute;ticos. Los partidos se ponen a punto de cara al curso que acaba de comenzar y esta semana le llega el turno a&nbsp;<a href=\"https://www.rtve.es/temas/podemos/77210/\" target=\"_self\"><strong>Podemos</strong></a>, que recupera su&nbsp;<strong>Universidad de Oto&ntilde;o&nbsp;</strong>tres a&ntilde;os despu&eacute;s de la &uacute;ltima, la de 2018, con el fin de&nbsp;<strong>relanzar un proyecto pol&iacute;tico que ha perdido fuerza</strong>&nbsp;con el paso de los a&ntilde;os y redefinirse de cara a las pr&oacute;ximas generales.&nbsp;</p>\n\n<p>De jueves a domingo, ser&aacute;n&nbsp;<strong>cuatro d&iacute;as intensos de conferencias</strong>&nbsp;con protagonismo del n&uacute;cleo fuerte del partido, con nombres como Irene Montero e Ione Belarra, y de los ide&oacute;logos del mismo, con&nbsp;<strong>Juan Carlos Monedero</strong>&nbsp;a la cabeza y&nbsp;<a href=\"https://www.rtve.es/temas/pablo-iglesias/78073/\" target=\"_self\"><strong>Pablo Iglesias</strong></a>&nbsp;como broche final. No estar&aacute;, sin embargo, la vicepresidenta segunda del Gobierno y posible candidata de Unidas Podemos a las pr&oacute;ximas elecciones,&nbsp;<strong>Yolanda D&iacute;az,</strong>&nbsp;que ha aludido motivos de agenda.&nbsp;</p>\n\n<p>Se tratar&aacute;n cuestiones que siempre han estado en el coraz&oacute;n de Podemos, como el derecho a la vivienda, el feminismo o la plurinacionalidad, pero tambi&eacute;n otros que han afectado a su gesti&oacute;n en el Ejecutivo. Con todo,&nbsp;<strong>Podemos busca &ldquo;rearmarse&rdquo; ideol&oacute;gicamente</strong>, redefinir sus estrategias y marcar su agenda en un momento que los expertos en pol&iacute;tica consideran &ldquo;crucial&rdquo; para la formaci&oacute;n.</p>\n\n<p>@@NOTICIA[2103180,IMAGEN,FIRMA]</p>\n\n<p>La cita, que se celebrar&aacute; en Rivas Vaciamadrid,<strong>&nbsp;llega apenas cuatro meses despu&eacute;s de&nbsp;<a href=\"https://www.rtve.es/noticias/20210613/belarra-nueva-lider-podemos-mas-coral-feminizado-aspira-ser-hegemonico-izquierda/2103180.shtml\" target=\"_self\">la IV Asamblea Ciudadana</a>&nbsp;que erigi&oacute; a</strong>&nbsp;la ministra de Derechos Sociales,&nbsp;<strong>Ione Belarra</strong>, como l&iacute;der de la formaci&oacute;n tras la marcha de Iglesias en mayo (tras no cumplir sus expectativas electorales en Madrid).</p>\n\n<h2 class=\"ladillo\">Reconfigurar al partido ante el &quot;tir&oacute;n&quot; de D&iacute;az, ajena a &eacute;l</h2>\n\n<p>Se trata de un momento clave. &ldquo;La idea de la universidad es<strong>&nbsp;describir su proyecto pol&iacute;tico y buscar visibilidad</strong>&nbsp;en un momento en el que&nbsp;<strong>el espacio se est&aacute; reconfigurando</strong>&nbsp;o se va a reconfigurar&nbsp;<strong>en profundidad</strong>&rdquo;, se&ntilde;ala a RTVE.es el polit&oacute;logo Edu Bay&oacute;n. Y es que, tras la marcha de Iglesias, Podemos enfoca un horizonte en el que,&nbsp;<strong>por primera vez, la l&iacute;der de la formaci&oacute;n no ser&aacute; previsiblemente la candidata</strong>&nbsp;a las pr&oacute;ximas elecciones generales (previstas para 2023) sino&nbsp;<a href=\"https://www.rtve.es/noticias/20210315/yolanda-diaz-nueva-vicepresidenta-segunda/2082281.shtml\" target=\"_self\"><strong>posiblemente la vicepresidenta segunda</strong></a>&nbsp;del Gobierno y ministra de Trabajo,&nbsp;<strong>Yolanda D&iacute;az</strong>, quien sin embargo no pertenece a Podemos (sino al PCE).</p>\n\n<p>@@NOTICIA[2176782,IMAGEN]</p>\n\n<p>En este sentido, recuerda el experto que la estrategia de D&iacute;az pasa &ldquo;por<strong>&nbsp;hacer una coalici&oacute;n mucho m&aacute;s amplia e incluso con una nueva marca</strong>&rdquo; distinta a Unidas Podemos. Esto mismo es lo que dio a entender la vicepresidenta en una entrevista la semana pasada en la Cadena Ser, cuando advirti&oacute; a Unidas Podemos que&nbsp;<strong>no liderar&iacute;a un proyecto electoral centrado en &ldquo;partidos&rdquo; ni en personalismos</strong>: &quot;Estoy rodeada de egos, nunca me he peleado por estas razones; como suceda esto o haya ruido es probable que yo me vaya&quot;.</p>\n\n<p>@@NOTICIA[2143640,IMAGEN]</p>\n\n<blockquote>\n<p>Hay una necesidad de evolucionar porque la marca est&aacute; bastante quemada y el tir&oacute;n lo tiene D&iacute;az</p>\n</blockquote>\n\n<p>&ldquo;En Podemos va a haber&nbsp;<strong>una cuesti&oacute;n fundamental, una necesidad de evolucionar ya que la marca est&aacute; bastante quemada</strong>&nbsp;y que&nbsp;<strong>el tir&oacute;n lo tiene</strong>&nbsp;el personalismo de&nbsp;<strong>D&iacute;az</strong>&rdquo;, prosigue Bay&oacute;n. Precisamente,&nbsp;<strong>la ministra de Trabajo se acaba de marcar un tanto para Unidas Podemos</strong>&nbsp;con el acuerdo para la futura ley de vivienda. Varios dirigentes del partido apoyan ese nuevo proyecto de la vicepresidenta, que busca ser m&aacute;s transversal con formaciones de la izquierda. &ldquo;Se est&aacute; viendo c&oacute;mo se configuran los pesos y contrapesos en esta nueva etapa&rdquo;, prosigue el polit&oacute;logo, para quien, todo esto, derivar&aacute; en l<strong>a &ldquo;construcci&oacute;n de un nuevo &lsquo;ente&rsquo;&rdquo; donde Podemos tendr&aacute; &ldquo;menos protagonismo&rdquo;</strong>&nbsp;que antes y &ldquo;ceder&aacute; poder interno&rdquo; entre las distintas organizaciones que lo conformen.</p>\n\n<h2 class=\"ladillo\">Un foro que reivindica el esp&iacute;ritu del 15M con el n&uacute;cleo duro del partido</h2>\n\n<p>Sin embargo,<strong>&nbsp;D&iacute;az,&nbsp;no estar&aacute; en esta Universidad de Oto&ntilde;o.</strong>&nbsp;D&iacute;az no pertenece a Podemos, pero en el foro s&iacute; estar&aacute;n otros dirigentes que tampoco lo hacen, como el coordinador federal de IU, Alberto Garz&oacute;n, o el l&iacute;der del PCE, Enrique Santiago. A&uacute;n as&iacute;,&nbsp;la directora de la Escuela de Gobierno de la Universidad Complutense de Madrid (UCM), Paloma Rom&aacute;n Marug&aacute;n, subraya que se trata de&nbsp;<strong>un &ldquo;espacio del propio Podemos y de los ide&oacute;logos del partido&rdquo; y D&iacute;az no pertenece a &eacute;l</strong>. &ldquo;Se trata de un foro del n&uacute;cleo duro de la formaci&oacute;n con el fin de crear uni&oacute;n y reforzar sus ideas&rdquo;.</p>\n\n<p>El foro est&aacute;&nbsp;<strong>organizado conjuntamente por Podemos y por el Instituto 25M</strong>, una fundaci&oacute;n dirigida por&nbsp;<strong>Monedero</strong>&nbsp;que tiene por objetivo el &ldquo;an&aacute;lisis, la formaci&oacute;n y la creaci&oacute;n pol&iacute;tica y cultural democr&aacute;ticas que irrumpieron en el 15M y tuvieron su expresi&oacute;n pol&iacute;tica en el nacimiento de Podemos&rdquo;, seg&uacute;n su propia p&aacute;gina web.</p>\n\n<blockquote>\n<p>Podemos busca la comuni&oacute;n entre ser un partido de Gobierno y ser el partido de la ciudadan&iacute;a</p>\n</blockquote>\n\n<p><strong>&ldquo;Podemos naci&oacute; del 15M y ahora necesita focalizar</strong>. Se han dado cuenta de que estar en el Gobierno implica gestionar, tomar decisiones en algunos temas que a nivel ciudadano no son populares o no llevaban en su programa electoral&rdquo;, sostiene el experto en Ciencias Pol&iacute;ticas de la Universidad de Barcelona Jes&uacute;s Palomar. Seg&uacute;n &eacute;l, &ldquo;Podemos<strong>&nbsp;flaquea en su discurso cuando tiene que gobernar&rdquo;</strong>, sobre todo &ldquo;en el &aacute;mbito econ&oacute;mico&rdquo; ya que &ldquo;se da cuenta de que no puede hacer seg&uacute;n qu&eacute; actuaciones&rdquo;. Por ello, este foro sirve tambi&eacute;n para &ldquo;tratar de hacer esta&nbsp;<strong>comuni&oacute;n entre lo que es un partido de Gobierno y uno que todav&iacute;a quiere ser el partido de la ciudadan&iacute;a</strong>&rdquo;.</p>\n\n<p>Reivindicando ese esp&iacute;ritu del 15M, Monedero&nbsp;<strong>dar&aacute; la bienvenida</strong>&nbsp;este jueves junto con otros nombres como&nbsp;<strong>Belarra</strong>, la ministra de Igualdad,&nbsp;<strong>Irene Montero</strong>, la secretaria de Organizaci&oacute;n de Podemos&nbsp;<strong>Lilith Vestrynge</strong>&nbsp;o la exportavoz de Podemos en la Asamblea de Madrid<strong>&nbsp;Isa Serra.</strong></p>\n\n<p>Durante los cuatro d&iacute;as de la cita, intervendr&aacute;n como ponentes&nbsp;<strong>Garz&oacute;n</strong>&nbsp;(sobre consumo sostenible y alimentos justos); el exsecretario general de Podemos Catalu&ntilde;a y exl&iacute;der de los &lsquo;comunes&rsquo;&nbsp;<strong>Xavier Dom&egrave;nech</strong>&nbsp;(sobre plurinacionalidad); el secretario de Acci&oacute;n Pol&iacute;tica y portavoz en el Congreso,&nbsp;<strong>Pablo Echenique&nbsp;</strong>(sobre &lsquo;golpismo&rsquo; y democracia); y el secretario de relaci&oacute;n con la Sociedad Civil y Movimientos Sociales,&nbsp;<strong>Rafa Mayoral</strong>, la l&iacute;der de los &lsquo;comunes&rsquo; en el &lsquo;Parlament,&nbsp;<strong>Jessica Albiach&nbsp;</strong>y el diputado&nbsp;<strong>Gerardo Pisarello</strong>&nbsp;(que hablar&aacute;n sobre la &ldquo;crisis&rdquo; en la Monarqu&iacute;a).</p>\n\n<p>Tambi&eacute;n participar&aacute;n la magistrada y delegada del Gobierno contra la Violencia de G&eacute;nero,&nbsp;<strong>Victoria&nbsp;Rosell&nbsp;</strong>(sobre Justicia), el exsecretario de Comunicaci&oacute;n de Podemos&nbsp;<strong>Juanma del Olmo</strong>&nbsp;(que hablar&aacute; sobre &ldquo;c&oacute;mo los medios de comunicaci&oacute;n ejercen el poder)&rdquo; y&nbsp;<strong>Dina Bousselham</strong>, la exasesora de Iglesias, que hablar&aacute; sobre el &ldquo;black lives matter&rdquo;. Los tres han estado muy presentes medi&aacute;ticamente en los &uacute;ltimos meses. Rosell fue uno de los nombres vetados por el PP para renovar el CGPJ; del Olmo est&aacute; imputado por el &lsquo;caso Neurona&rsquo; y el robo de la tarjeta del m&oacute;vil de Bousselham dio lugar a una investigaci&oacute;n que acab&oacute; salpicando a Iglesias.</p>\n\n<h2 class=\"ladillo\">Iglesias vuelve para clausurar la cita</h2>\n\n<p><strong>Iglesias pondr&aacute; el domingo el broche final a la cita</strong>, acompa&ntilde;ado de su sucesora,&nbsp;<strong>Belarra</strong>. El cofundador y exl&iacute;der de Podemos ha vuelto a las tertulias medi&aacute;ticas pero&nbsp;<strong>no participaba en ning&uacute;n acto p&uacute;blico del partido desde que&nbsp;<a href=\"https://www.rtve.es/noticias/20210504/podemos-resultados-elecciones-madrid-pablo-iglesias/2088514.shtml\" target=\"_self\">dijo adi&oacute;s a la pol&iacute;tica</a></strong>&nbsp;en mayo. Ni siquiera estuvo en la proclamaci&oacute;n de Belarra porque, seg&uacute;n dijo su entorno, no quer&iacute;a &ldquo;tutelar&rdquo; al nuevo Podemos.</p>\n\n<blockquote>\n<p>Su presencia es simb&oacute;lica, vuelve como profesor de Ciencias Pol&iacute;ticas</p>\n</blockquote>\n\n<p>&ldquo;<strong>Su presencia es simb&oacute;lica. Est&aacute; al cierre</strong>, no en la construcci&oacute;n del discurso ni al inicio y eso es importante, porque implica un mensaje de que no est&aacute; vigilando el proceso&rdquo;, destaca Palomar, a lo que Rom&aacute;n a&ntilde;ade: &ldquo;Su presencia no distorsiona el foro y hay que tener en cuenta de que se trata de una universidad pol&iacute;tica e Iglesias es profesor. Es el lugar adecuado para que vuelva con un papel de&nbsp;<strong>profesor de Ciencias Pol&iacute;ticas&rdquo;.</strong></p>\n\n<p>Quien no estar&aacute; en el esta Universidad de Oto&ntilde;o ser&aacute;, precisamente, una persona que era muy cercana a Iglesias: la exsecretaria de Estado de Igualdad y exsecretaria de Feminismos y exdiputada de Podemos<strong>&nbsp;Noelia Vera</strong>. Vera&nbsp;<strong><a href=\"https://www.rtve.es/noticias/20210930/podemos-noelia-vera-renuncia-cargos-publicos/2177040.shtml\" target=\"_self\">abandon&oacute; todos sus cargos la semana pasada</a></strong>&nbsp;por motivos personales, seg&uacute;n su entorno.</p>\n\n<p>Los expertos no descartan que siga habiendo&nbsp;<strong>ciertas tensiones internas dentro del partido</strong>, aunque le restan gravedad. &ldquo;Podemos es un partido poco maduro y con unos&nbsp;<strong>principios muy idealizados y, cuando no se cumplen al 100% alguien dice &lsquo;me voy&rsquo;</strong>. Todav&iacute;a hay gente en el partido que funciona as&iacute;, aunque tambi&eacute;n hay personas que tienen ciertas aspiraciones pol&iacute;ticas que, cuando no se cumplen, deciden marcharse&rdquo;, se&ntilde;ala Palomar.</p>\n\n<p>El componente menos pol&iacute;tico aunque con un gran matiz social correr&aacute; a cuenta de&nbsp;<strong>dos actuaciones musicales</strong>, la de Anita Kuruba tras la inauguraci&oacute;n este jueves y la de Sole&aacute; Morente y Califato 3/4 el pr&oacute;ximo s&aacute;bado.</p>\n\n<p>Precisamente, Rom&aacute;n destaca la parte &ldquo;l&uacute;dica&rdquo; del foro. &ldquo;La idea tambi&eacute;n es la de que compartan todos los simpatizantes un espacio, pasen tiempo juntos y que los asistentes hagan identidad y generen relaci&oacute;n.&nbsp;<strong>Es un espacio de encuentro y reafirmaci&oacute;n</strong>&rdquo;, se&ntilde;ala. Y concluye destacando que, al igual que ocurri&oacute; con la Convenci&oacute;n Nacional del PP la semana pasada o con la de Vox de este fin de semana,&nbsp;<strong>Podemos busca &ldquo;visibilidad&rdquo;</strong>&nbsp;medi&aacute;tica para decir que &ldquo;sigue ah&iacute;, que quiere salvaguardar y ampliar su espacio electoral&rdquo;: &ldquo;Es&nbsp;<strong>una llamada de atenci&oacute;n no solo a los propios de Podemos, sino tambi&eacute;n a la sociedad&rdquo;</strong>.</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "ROCÍO GIL GRANDE",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Noticias/España",
        "mainCategoryLang": "Noticias/España",
        "otherTopicsName": [
          "Tags Libres/Pablo Iglesias",
          "Tags Libres/Unidas Podemos/Podemos",
          "Tags Libres/Irene Montero",
          "Tags Libres/Yolanda Díaz",
          "Tags Libres/Ione Belarra"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2181460/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2181460/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2181460/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2181460/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2181460/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2181460/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2181460/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2181460/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2181460/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2181460/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2181460/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2181460/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2181460/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2181460/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2181460/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Información y actualidad",
            "generoInfUid": "GE_INFOR",
            "generoId": "136528",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "Podemos celebra su universidad de otoño con Iglesias y sin Díaz para relanzar su proyecto político en un momento \"crucial\""
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2182800",
        "htmlUrl": "https://www.rtve.es/noticias/20211007/favoritos-nobel-literatura/2182800.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2182800/",
        "id": "2182800",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/827",
        "popularity": "0.0",
        "popHistoric": "8.0",
        "numVisits": "0",
        "publicationDate": "07-10-2021 07:16:00",
        "expirationDate": null,
        "modificationDate": "07-10-2021 07:17:40",
        "publicationDateTimestamp": 1633583760000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2182800/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/dramaturgo-noruego-jon-fosse-britanico-tom-stoppard/1633543757539.jpg",
        "imageSEO": "https://img2.rtve.es/n/favoritos-nobel-literatura_2182800.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": "Premios Nobel",
        "anteTitleUrl": null,
        "longTitle": "Favoritos para el Nobel de Literatura: ¿Ha abandonado la Academia Sueca a los dramaturgos?",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li>\n\t<p>El &uacute;ltimo autor plenamente dram&aacute;tico premiado fue Harold Pinter en 2005</p>\n\t</li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>No se f&iacute;en de ninguna quiniela del Nobel de Literatura. No hay favoritos porque el sistema de la Academia Sueca es completamente herm&eacute;tico (<a href=\"https://www.rtve.es/noticias/20191009/escandalo-nobel-literatura-ano-despues-filtraciones-abusos-sexuales/1980874.shtml\">salvo las sospechas del esc&aacute;ndalo de Jean-Claude Arnault</a>) y&nbsp;las listas de las casas de apuestas son solo un reflejo de lo que los apostantes creen premiable. Este jueves 7 de octubre a las 13.00 h. (en directo en RTVE), como cada a&ntilde;o, el secretario permanente de la Academia Sueca,&nbsp;<strong>Mats Malm</strong>, abrir&aacute; la puerta&nbsp;de su despacho para pronunciar un&nbsp;nombre a los periodistas agolpados.</p>\n\n<p>Entre otras cosas, lo que la estad&iacute;stica dice es que probablemente no ser&aacute; un dramaturgo. Aceptemos que la mayor&iacute;a de los escritores saltan entre g&eacute;neros (y que casi todos se inician en la poes&iacute;a), pero dando por buenas las estad&iacute;sticas de la propia academia sueca:<strong>&nbsp;80 de los premiados fueron reconocidos por su prosa, 35 por su poes&iacute;a, 14 por su dramaturgia, 3 por su filosof&iacute;a o ensayos y 2 como historiadores.</strong></p>\n\n<p>La lista de dramaturgos premiados se inicia precisamente con el espa&ntilde;ol<strong>&nbsp;Jos&eacute; Echegaray</strong>&nbsp;(1904) y su relevancia durante el primer tercio del siglo XX queda probada con los galardones a<strong>&nbsp;Maurice Maeterlinck</strong>&nbsp;(1911),&nbsp;<strong>Gerhart Hauptmann&nbsp;</strong>(1912),<strong>&nbsp;Jacinto Benavente</strong>&nbsp;(1922),&nbsp;<strong>George Bernard Shaw</strong>&nbsp;(1925),&nbsp;<strong>Luigi Pirandello</strong>&nbsp;(1934) o E<strong>ugene</strong><strong>&nbsp;O&#39;Neill</strong>&nbsp;(1936).</p>\n\n<p>A partir de ah&iacute;, mucha intermitencia:&nbsp;<strong>Albert Camus</strong>&nbsp;(1957),&nbsp;<strong>Jean-Paul Sartre (</strong>1964),&nbsp;<strong>Samuel Beckett&nbsp;</strong>(1969),&nbsp;<strong>Wole Soyinka&nbsp;</strong>(1986),<strong>&nbsp;Dario Fo&nbsp;</strong>(1997) y&nbsp;<strong>Harold Pinter&nbsp;</strong>(2005). De hecho, la lista de dramaturgos nunca premiados tiene mucho brillo:&nbsp;<strong>Henrick Ibsen, Bertolt Brecht, Arthur Miller, Tennesse Williams&nbsp;</strong>o<strong>&nbsp;Eugene Ioenesco.</strong></p>\n\n<p>Queda el particular caso de&nbsp;<a href=\"https://www.rtve.es/noticias/20191010/austriaco-peter-handke-polaca-olga-tokarczuk-premios-nobel-literatura-2018-2019/1981197.shtml\">Peter Handke, premiado en 2019</a>, que pr&aacute;cticamente le dio a todos los palos y comenz&oacute; en el teatro experimental de los 60 adem&aacute;s de ser guionista de&nbsp;importantes pel&iacute;culas del Nuevo cine alem&aacute;n de los 70, pero es especialmente reconocido por sus novelas.</p>\n\n<h2 class=\"ladillo\">Jon Fosse, la gloria noruega</h2>\n\n<p>El dramaturgo noruego<strong>&nbsp;Jon Fosse,&nbsp;</strong>de 62 a&ntilde;os, es el m&aacute;s habitual de las quinielas, seguramente porque es una gloria art&iacute;stica de su pa&iacute;s: tiene hasta una residencia p&uacute;blica oficial otorgada por el rey al artista m&aacute;s importante de la naci&oacute;n.</p>\n\n<p>Aunque est&aacute; traducido a m&aacute;s de 40 idiomas, ejemplifica bien parte del problema: su prestigio no se corresponde con su fama. El teatro no viaja tanto entre idiomas, y aunque eso no tiene que ser un factor para la Academia &ndash;y menos con un escandinavo- s&iacute; muestra el desplazamiento de la dramaturgia del centro de la cultura.</p>\n\n<p>M&aacute;s popular, por el dominio cultural del ingl&eacute;s, es&nbsp;<strong>Tom&nbsp;</strong><strong>Stoppar</strong>d, autor de&nbsp;<em>Rosencrantz y Guildenstern han muerto, La Costa de Utop&iacute;a&nbsp;</em>o<em>&nbsp;Realidad</em>. Y, m&aacute;s representado a&uacute;n, el estadounidense&nbsp;<strong>David Mamet&nbsp;</strong>(<em>Glengarry Glen Ross American Buffalo</em>).</p>\n\n<p>@@MEDIA[5646592,v]</p>\n\n<p>Y, entre los nombres de las casas de apuestas, solo una mujer: la francesa&nbsp;<strong>H&eacute;l&egrave;ne Cixous</strong>, una de las autoras fundamentales del feminismo, tambi&eacute;n tiene una importante obra teatral en la que destacan&nbsp;<em>La ciudad perjura o el despertar de las Erinias</em>&nbsp;o<em>&nbsp;Retrato de dora.</em></p>\n\n<h2 class=\"ladillo\">&iquest;Y por qu&eacute; no un guionista de cine?</h2>\n\n<p>Si la Academia se atrevi&oacute; en 2016 a buscar la poes&iacute;a en un compositor de canciones y&nbsp;<a href=\"https://www.rtve.es/noticias/20161013/bob-dylan-estatua-tan-grande-como-nobel/1424720.shtml\">premiar a Bob Dylan</a>, &iquest;por qu&eacute; no recorrer el mismo camino desde el teatro al cine y premiar a un guionista?</p>\n\n<p>Aunque algunos de los premiados, como Garc&iacute;a M&aacute;rquez, Beckett, Fo, Pinter han firmado trabajos en el cine, el paso definitivo ser&iacute;a premiar a un escritor esencialmente cinematogr&aacute;fico. Durante a&ntilde;os, se especul&oacute; con que&nbsp;<strong>Woody Allen</strong>&nbsp;podr&iacute;a ser un candidato. Y&nbsp;<strong>Aaron Sorkin&nbsp;</strong>ha sido finalista en otros premios como el Premio Princesa de Asturias.</p>\n\n<p>Aunque, por cantidad y calidad, la Academia Sueca perdi&oacute; su mejor oportunidad hace a&ntilde;os, precisamente con un compatriota:&nbsp;<a href=\"https://www.rtve.es/play/videos/dias-de-cine/dias-cine-especial-ingmar-bergman/4924436/\"><strong>Ingmar&nbsp;</strong><strong>Bergman</strong></a>. Quiz&aacute; alg&uacute;n d&iacute;a sepamos que fue candidato: las listas de finalistas al premio que maneja la Academia Sueca no se hacen p&uacute;blicas hasta 50 a&ntilde;os despu&eacute;s.</p>\n\n<div class=\"cartela\">\n<h2 class=\"ladillo\">&iquest;C&oacute;mo se elige el Nobel de Literatura?</h2>\n\n<p>18 acad&eacute;micos suecos proponen y recogen propuestas de otros ganadores y otras academias. Tras un primer corte, profesores ilustres y otros escritores reducen a 20 a la lista y, a finales de mayo, solo a 5. Durante el verano, los acad&eacute;micos estudian y elaboran un informe de los candidatos para debatirlo posteriormente.</p>\n\n<p>Completamente perdidas, las casas de apuestas dejan que sean las propias apuestas las que determinen el ratio de lo que se paga por un Nobel. Este a&ntilde;o:&nbsp;<strong>Mircea Cartarescu, Lyudmila Ulitskaya, Anne Carson, Ngugi Wa Thiongo , Annie Ernaux, Maryse Cond y Margaret Atwood</strong>. Y, por supuesto,&nbsp;<strong>Haruki Murakami</strong>, que lleva tantos a&ntilde;os como n&uacute;mero uno de las apuestas que la concesi&oacute;n del Nobel parece un tr&aacute;mite administrativo atascado.</p>\n</div>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "ESTEBAN RAMÓN",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Noticias/Cultura",
        "mainCategoryLang": "Noticias/Cultura",
        "otherTopicsName": [
          "Tags Libres/Teatro",
          "Tags Libres/Premios Nobel"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2182800/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2182800/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2182800/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2182800/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2182800/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2182800/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2182800/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2182800/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2182800/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2182800/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2182800/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2182800/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2182800/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2182800/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2182800/relacionados/relacionados-por-idioma",
        "generos": null,
        "title": "Favoritos para el Nobel de Literatura: ¿Ha abandonado la Academia Sueca a los dramaturgos?"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2183000",
        "htmlUrl": "https://www.rtve.es/noticias/20211007/pedro-castillo-acepta-renuncia-primer-ministro-peru-guido-bellido/2183000.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2183000/",
        "id": "2183000",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/3390",
        "popularity": "13.9502",
        "popHistoric": "13.9502",
        "numVisits": "49",
        "publicationDate": "07-10-2021 03:15:00",
        "expirationDate": null,
        "modificationDate": "07-10-2021 03:18:58",
        "publicationDateTimestamp": 1633569300000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2183000/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/pedro-castillo-saludando-primer-ministro/1633564836678.jpg",
        "imageSEO": "https://img2.rtve.es/n/pedro-castillo-acepta-renuncia-primer-ministro-peru-guido-bellido_2183000.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": null,
        "anteTitleUrl": null,
        "longTitle": "El presidente de Perú acepta la renuncia del primer ministro del país",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li>As&iacute; lo ha anunciado el presidente Pedro Castillo en un breve mensaje en televisi&oacute;n</li>\n\t<li>Aunque Guido Bellido lleg&oacute; al cargo hace menos de tres meses, estaba muy cuestionado por pol&iacute;ticos y ciudadanos</li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>El presidente de&nbsp;<a href=\"https://www.rtve.es/temas/peru/3390/\">Per&uacute;</a>,&nbsp;<a href=\"https://www.rtve.es/noticias/20210720/perfil-pedro-castillo-presidente-peru/2101180.shtml\">Pedro Castillo,</a>&nbsp;ha anunciado este mi&eacute;rcoles que&nbsp;<strong>ha aceptado la renuncia del primer ministro del pa&iacute;s</strong>,&nbsp;<strong>Guido Bellido</strong>, y ha nombrado a&nbsp;Mirtha Vasquez como nueva primera ministra.</p>\n\n<p><strong>&quot;He decidido tomar algunas decisiones en favor de la gobernabilidad&quot;</strong>, ha se&ntilde;alado&nbsp;Castillo en un breve mensaje por televisi&oacute;n en el que ha confirmado los rumores sobre una posible salida de Bellido, muy cuestionado por la oposici&oacute;n pol&iacute;tica y gran parte de la ciudadan&iacute;a.</p>\n\n<p>@@MEDIA[5933916,v]</p>\n\n<p>Desde que lleg&oacute; al&nbsp; cargo, el pasado 28 de julio, Bellido ha mantenido una&nbsp;<strong>disputa&nbsp;constante con la oposici&oacute;n,</strong>&nbsp;que domina&nbsp;el Congreso, y lo considera&nbsp;un pol&iacute;tico de izquierda radical que genera&nbsp;&quot;inestabilidad&quot; en el pa&iacute;s.</p>\n\n<p>En referencia a eso, Casrillo ha destacado en televisi&oacute;n que<strong>&nbsp;&quot;es momento de poner al Per&uacute; por encima de toda ideolog&iacute;a&nbsp;</strong>y posici&oacute;n partidaria&quot; y que &quot;el equilibrio de poderes es el puente entre el Estado de derecho y la democracia&quot;.</p>\n\n<h2 class=\"ladillo\">Mirtha V&aacute;squez&nbsp;nueva primera ministra</h2>\n\n<p>Adem&aacute;s, Castillo ha agradecido a Bellido &quot;sus servicios prestados&quot; y ha se&ntilde;alado poco despu&eacute;s a su sucesora,&nbsp;<strong>Mirtha V&aacute;squez,&nbsp;</strong>una pol&iacute;tica de izquierda moderada que hab&iacute;a presidido el anterior Congreso.</p>\n\n<p>@@NOTICIA[2141881,imagen]</p>\n\n<p>Durante el mensaje anunciando la renuncia, el mandatario asegur&oacute; que<a href=\"https://www.rtve.es/noticias/20210720/elecciones-peru-retos-nuevo-presidente-pedro-castillo/2101864.shtml\">&nbsp;desde que asumi&oacute; el Gobierno</a>&nbsp;est&aacute; &quot;trabajando arduamente para cumplir con todos los compromisos&quot; que asumi&oacute; durante su campa&ntilde;a electoral y al inicio de su mandato.</p>\n\n<p>Ratific&oacute;, en ese sentido, &quot;el&nbsp;<strong>compromiso del Per&uacute; con la inversi&oacute;n privada,</strong>&nbsp;remarcando la necesidad de que esta opere sin corrupci&oacute;n, con responsabilidad social, priorizando la diversificaci&oacute;n productiva nacional&quot;.</p>\n\n<p>@@NOTICIA[2101864,imagen,firma]</p>\n\n<p>&quot;En mi compromiso por abordar prioritariamente los&nbsp;<strong>grandes problemas del pa&iacute;s, como la salud, el hambre, la pobreza</strong>&quot;, sostuvo.</p>\n\n<p>Castillo tambi&eacute;n dijo que el Ejecutivo y el Congreso de su pa&iacute;s deben &quot;procurar tranquilidad y cohesi&oacute;n del gobierno&quot;, por lo que las prerrogativas constitucionales de la cuesti&oacute;n de confianza, como la interpelaci&oacute;n y la censura de ministros, &quot;no deber&iacute;a usarse para crear inestabilidad pol&iacute;tica&quot;.</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "RTVE.es",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Noticias/Mundo/Latinoamérica/Perú",
        "mainCategoryLang": "Noticias/Mundo/Latinoamérica/Perú",
        "otherTopicsName": [
          "Tags Libres/Política"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2183000/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2183000/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2183000/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2183000/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2183000/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2183000/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2183000/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2183000/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2183000/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2183000/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2183000/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2183000/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2183000/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2183000/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2183000/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Información y actualidad",
            "generoInfUid": "GE_INFOR",
            "generoId": "136528",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "El presidente de Perú acepta la renuncia del primer ministro del país"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2182980",
        "htmlUrl": "https://www.rtve.es/noticias/20211007/largas-colas-kabul-pasporte-taliban-afganistan/2182980.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2182980/",
        "id": "2182980",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/1329",
        "popularity": "15.0629",
        "popHistoric": "15.0629",
        "numVisits": "55",
        "publicationDate": "07-10-2021 01:19:00",
        "expirationDate": null,
        "modificationDate": "07-10-2021 01:51:27",
        "publicationDateTimestamp": 1633562340000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2182980/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/largas-colas-kabul-para-conseguir-pasaporte-taliban/1633540027973.jpg",
        "imageSEO": "https://img2.rtve.es/n/largas-colas-kabul-pasporte-taliban-afganistan_2182980.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": "Afganistán",
        "anteTitleUrl": null,
        "longTitle": "Largas colas en Kabul para conseguir el pasaporte talibán",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li>Los talibanes quieren emitir cada d&iacute;a el doble de documentos&nbsp;que la anterior administraci&oacute;n</li>\n\t<li>La expedici&oacute;n lleva parada desde que cay&oacute; el anterior gobierno</li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p><a href=\"https://www.rtve.es/temas/afganistan/1329/\">Cientos de afganos</a>&#160;se han agolpado a las puertas de la Oficina de pasaportes de Kabul, que&nbsp;<strong>vuelve a estar operativa</strong>. El Emirato ha comenzado a emitir los&nbsp;<a href=\"https://www.rtve.es/play/videos/noticias-24-horas/afganistan/6127626/\">nuevos documentos</a>&nbsp;bajo el nombre de<strong>&nbsp;&#39;Rep&uacute;blica Isl&aacute;mica de Afganist&aacute;n&#39; dos meses despu&eacute;s.&nbsp;</strong></p>\n\n<p>Esta reanudaci&oacute;n supone una<strong>&#160;esperanza&nbsp;para miles de afganos</strong>&#160;que ven as&iacute; como podr&iacute;an volver a tener alguna oportunidad de salir del pa&iacute;s. &quot;No hay empleo, no hay trabajo, no hay buenas condiciones para vivir aqu&iacute;...&quot;, dice Ahmad Shakib Sidiqui, uno de los muchos afganos que se agolpa a las puertas de la oficina en la capital afgana.&nbsp;</p>\n\n<p>@@NOTICIA[cambios,imagen]</p>\n\n<p>&quot;Nosotros hemos venido hasta aqu&iacute; porque<strong>&#160;llevamos dos meses intentando obtener un pasaporte</strong>&quot;, dice Mojtaba, un afgano que se queja de que la tramitaci&oacute;n haya estado paralizada desde que se hiciesen con el poder los talib&aacute;n.&nbsp;</p>\n\n<p>Sin embargo, algunos ciudadanos han denunciado que&#160;<a href=\"https://www.rtve.es/noticias/20210928/talibanes-aseguran-aplicaran-temporalmente-constitucion-monarquica-1964-cambios/2175879.shtml\">el sistema sigue sin funcionar</a>. &quot;Por ahora&#160;<strong>no hay ning&uacute;n funcionario que responda nuestras preguntas</strong>&#160;y nos diga cu&aacute;ndo podemos venir&quot;, dice Mahir Rasooli, un vecino de la capital.&nbsp;</p>\n\n<h2 class=\"ladillo\">170.000 personas lo habr&iacute;an solicitado&nbsp;&nbsp;</h2>\n\n<p>Por su parte, desde la administraci&oacute;n afgana aseguran que&nbsp;<strong>expedir&aacute;n 6.000 al d&iacute;a</strong>, el doble que antes de&nbsp;<a href=\"https://www.rtve.es/noticias/20210921/talibanes-nombramientos-gobierno-afganistan-sin-mujeres-minorias-etnicas/2172852.shtml\">su llegada al poder</a>. &quot;Planeamos distribuir primero los pasaportes de aquellos que han pagado las tasas. Habr&aacute; de 20.000 a 25.000 pasaportes primero&quot;, asegura Alam Gol Haggani, jefe del departamento.&nbsp;</p>\n\n<p>Para lograr doblar la producci&oacute;n los talib&aacute;n&#160;<strong>han convocado a todos los trabajadores disponibles, incluso las mujeres</strong>&#160;que esperan no ser excluidas m&aacute;s adelante cuando el pico de la demanda descienda. &quot;He estado trabajando en este departamento 10 a&ntilde;os, mi petici&oacute;n al emirato isl&aacute;mico es que permita que todas las empleadas trabajen dentro del marco del Islam&quot;, se&ntilde;ala&nbsp;Farida Mohammadzai, empleada del departamento de pasaportes.&nbsp;</p>\n\n<p>@@MEDIA[6127626,v]</p>\n\n<p>Fuentes del departamento citadas por la cadena de televisi&oacute;n afgana Tolo TV detallan que&#160;<strong>alrededor de 170.000 personas han presentado solicitudes</strong>&#160;durante los &uacute;ltimos dos meses para lograr hacerse con un pasaporte.&nbsp;</p>\n\n<p>Por otra parte, el portavoz del Ministerio del Interior afgano, Said Josti, ha destacado que<strong>&#160;los nuevos pasaportes ser&aacute;n emitidos por ahora con el t&iacute;tulo de Rep&uacute;blica Isl&aacute;mica de Afganist&aacute;n</strong>, a pesar de que los talib&aacute;n han anunciado la restauraci&oacute;n del Emirato Isl&aacute;mico de Afganist&aacute;n.</p>\n\n<p>Los talib&aacute;n, que se hicieron con el poder a mediados de agosto tras entrar en Kabul poco despu&eacute;s de la huida del pa&iacute;s de Ghani, han anunciado ya la formaci&oacute;n de su Gobierno,&#160;<a href=\"https://www.rtve.es/noticias/20210921/talibanes-nombramientos-gobierno-afganistan-sin-mujeres-minorias-etnicas/2172852.shtml\">marcado por la falta de mujeres y de representantes de otros grupos</a>&#160;pol&iacute;ticos de Afganist&aacute;n.</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "RTVE.es",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Noticias/Mundo/Asia/Afganistán",
        "mainCategoryLang": "Noticias/Mundo/Asia/Afganistán",
        "otherTopicsName": [
          "Tags Libres/Talibanes",
          "Tags Libres/Conflicto en Afganistán",
          "Noticias/Especiales/Misión de la OTAN en Afganistán"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2182980/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2182980/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2182980/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2182980/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2182980/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2182980/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2182980/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2182980/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2182980/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2182980/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2182980/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2182980/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2182980/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2182980/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2182980/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Información y actualidad",
            "generoInfUid": "GE_INFOR",
            "generoId": "136528",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "Largas colas en Kabul para conseguir el pasaporte talibán"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2180241",
        "htmlUrl": "https://www.rtve.es/infantil/noticias/donde-estan-mujeres-ciencia/2180241.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2180241/",
        "id": "2180241",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/83770",
        "popularity": "0.0923",
        "popHistoric": "8.0",
        "numVisits": "1",
        "publicationDate": "07-10-2021 01:00:00",
        "expirationDate": null,
        "modificationDate": "05-10-2021 10:48:06",
        "publicationDateTimestamp": 1633561200000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2180241/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/donde-estan-mujeres-ciencia/1633419876001.png",
        "imageSEO": "https://img2.rtve.es/n/donde-estan-mujeres-ciencia_2180241.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": null,
        "anteTitleUrl": null,
        "longTitle": "¿Dónde están las mujeres en la ciencia?",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<p>Visitamos Alcal&aacute; de Henares para hablar sobre ciencia y mujeres con los alumnos y las alumnas del Colegio Luis Vives y nuestra experta de la semana, Margarita del Val, vir&oacute;loga e inmun&oacute;loga del CSIC.</p>\n",
        "frontSummary": null,
        "text": "<ul>\n\t<li>&lsquo;Aprendemos en Clan. El debate&rsquo; visita Alcal&aacute; de Henares para hablar sobre ciencia y mujeres con los alumnos y las alumnas del Colegio Luis Vives</li>\n\t<li>Esta semana nos acompa&ntilde;a Margarita del Val, vir&oacute;loga e inmun&oacute;loga del CSIC</li>\n\t<li>Viernes 8 de octubre, a las 11:30 horas en Clan</li>\n</ul>\n\n<p><strong><a href=\"https://www.rtve.es/aprendemos-en-clan/el-debate/\">&lsquo;Aprendemos en Clan. El debate&rsquo;</a>&nbsp;es un espacio donde los protagonistas son los ni&ntilde;os y las ni&ntilde;as. Cada viernes, recorreremos nuestro pa&iacute;s y visitaremos un colegio para debatir sobre temas que les preocupan e interesan. Estudiantes de entre 10 y 12 a&ntilde;os expondr&aacute;n sus opiniones frente a los expertos y expertas que acompa&ntilde;ar&aacute;n a la moderadora, Laura Vives.</strong></p>\n\n<p>@@FOTO[6125664]</p>\n\n<p>&iquest;Sab&iacute;as que Hipatia de Alejandr&iacute;a defendi&oacute; las teor&iacute;as heliocentristas mucho antes que Cop&eacute;rnico, ya en el siglo IV? &iquest;O que el primer algoritmo para ser procesado por una m&aacute;quina lo escribi&oacute; una mujer, Ada Lovelace? Esta semana en &lsquo;Aprendemos en Clan. El debate&rsquo; viajaremos a<strong>&nbsp;Alcal&aacute; de Henares</strong>&nbsp;y visitaremos el&nbsp;<strong>Colegio Luis Vives</strong>. Debatiendo con sus alumnos y alumnas descubriremos&nbsp;<strong>d&oacute;nde est&aacute;n las mujeres en la ciencia</strong>.</p>\n\n<p>@@FOTO[6125665]</p>\n\n<p>En este cap&iacute;tulo nos acompa&ntilde;ar&aacute;&nbsp;<strong>Margarita del Val,&nbsp;</strong>investigadora cient&iacute;fica, vir&oacute;loga e inmun&oacute;loga que actualmente dirige la Plataforma Salud Global del CSIC contra la Covid-19. Entre todos vamos a debatir, experimentar y jugar para reflexionar y tratar de dar respuesta a cuestiones como:&nbsp;<strong>&iquest;Por qu&eacute; conocemos a tan pocas cient&iacute;ficas? &iquest;Realmente hay tan pocas? &iquest;C&oacute;mo se les puede dar m&aacute;s visibilidad?</strong>&nbsp;Poco a poco iremos cargando nuestra mochila de nuevos conocimientos y, sobre todo, de grandes aprendizajes.</p>\n\n<h2 class=\"ladillo\"><span style=\"color:#800080;\">&lsquo;Aprendemos en Clan&rsquo;</span></h2>\n\n<p>Este programa forma parte del proyecto&nbsp;<a href=\"https://www.rtve.es/aprendemos-en-clan/\">&lsquo;Aprendemos en Clan&rsquo;</a>&nbsp;y nace a ra&iacute;z de la pandemia de la Covid-19 para divulgar de forma amena las principales asignaturas para estudiantes de entre 6 y 10 a&ntilde;os. Se elabora en colaboraci&oacute;n con el Ministerio de Educaci&oacute;n y Formaci&oacute;n Profesional y su objetivo es ser &uacute;til, de una manera innovadora, a las comunidades educativas y a las familias.</p>\n\n<p>&lsquo;Aprendemos en Clan&rsquo; se emite de lunes a jueves en el canal infantil de RTVE. Ahora, se ampl&iacute;a con &lsquo;Aprendemos en Clan. El debate&rsquo;. La colaboraci&oacute;n entre ambas instituciones ha sido decisiva para que este programa educativo de televisi&oacute;n complete su oferta con episodios dirigidos especialmente a escolares de 10 a 12 a&ntilde;os. Son debates grabados en centros de Educaci&oacute;n Infantil y Primaria en los que docentes y alumnos trabajan previamente contenidos relacionados con los temas elegidos, facilitando la implicaci&oacute;n del alumnado y el progreso de su aprendizaje.</p>\n\n<p>&lsquo;Aprendemos en Clan. El debate&rsquo;, dirigido por la periodista Mar&iacute;a Jos&eacute; Malia, con Ana Ru&iacute;z al frente de la producci&oacute;n ejecutiva, es una producci&oacute;n de RTVE en colaboraci&oacute;n con la productora Patito.</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "RTVE.es Infantil",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Televisión/Programas de TVE/Infantiles/1Rediseño/Infantiles Noticias",
        "mainCategoryLang": "Televisión/Programas de TVE/Infantiles/1Rediseño/Infantiles Noticias",
        "otherTopicsName": [],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2180241/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2180241/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2180241/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2180241/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2180241/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2180241/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2180241/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2180241/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2180241/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2180241/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2180241/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2180241/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2180241/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2180241/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2180241/relacionados/relacionados-por-idioma",
        "generos": null,
        "title": "¿Dónde están las mujeres en la ciencia?"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2182960",
        "htmlUrl": "https://www.rtve.es/noticias/20211007/biden-xi-jinping-se-reuniran-virtualmente-antes-fin-ano/2182960.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2182960/",
        "id": "2182960",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/1307",
        "popularity": "13.0883",
        "popHistoric": "13.0883",
        "numVisits": "40",
        "publicationDate": "07-10-2021 00:43:00",
        "expirationDate": null,
        "modificationDate": "07-10-2021 01:04:48",
        "publicationDateTimestamp": 1633560180000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2182960/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/joe-biden-izquierda-xi-jinping-derecha-fotomontaje/1633560411759.jpg",
        "imageSEO": "https://img2.rtve.es/n/biden-xi-jinping-se-reuniran-virtualmente-antes-fin-ano_2182960.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": null,
        "anteTitleUrl": null,
        "longTitle": "Joe Biden y Xi Jinping se reunirán virtualmente antes de final de año",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li>Ser&aacute; el primer encuentro entre ambos mandatarios desde que el estadounidense lleg&oacute; al poder</li>\n\t<li>La reuni&oacute;n ha sido confirmada por los gabinetes de los dos presidentes</li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>El presidente de&#160;<a href=\"https://www.rtve.es/temas/estados-unidos/1307/\">Estados Unidos</a>, J<strong>oe Biden, y su hom&oacute;logo chino,&#160;</strong><a href=\"https://www.rtve.es/play/videos/telediario/xi-jinping-afirma-centenario-del-partido-comunista-chino-ninguna-fuerza-extranjera-volvera-someter-pais/5966859/\"><strong>Xi Jinping</strong>,</a>&#160;han acordado este mi&eacute;rcoles<strong>&#160;reunirse&nbsp;virtualmente antes de que acabe este a&ntilde;o</strong>, el primer encuentro entre los dos l&iacute;deres desde que&#160;<a href=\"https://www.rtve.es/temas/joe-biden/22510/\">Biden</a>&#160;lleg&oacute; al poder.&nbsp;</p>\n\n<p>El futuro encuentro se ha cerrado despu&eacute;s de que el asesor de seguridad nacional de Bidem, Jake Sullivam, y el m&aacute;ximo responsable de la diplomacia&#160;<a href=\"https://www.rtve.es/temas/china/1338/\">china</a>, Yang Jiechim, se reuniesen durante m&aacute;s de seis horas en Z&uacute;rich, seg&uacute;n una alta funcionaria estadounidense.&nbsp;</p>\n\n<p>@@NOTICIA[2170040,imagen]</p>\n\n<p><strong>&quot;Tenemos un acuerdo de principios para mantener una reuni&oacute;n bilateral</strong>&#160;virtual entre los l&iacute;deres antes del fin de a&ntilde;o&quot;, ha afirmado la funcionaria.&nbsp;</p>\n\n<p>&quot;Esa reuni&oacute;n formar&iacute;a parte de nuestros esfuerzos de gestionar de forma responsable la competici&oacute;n entre nuestros dos pa&iacute;ses&quot;, ha a&ntilde;adido.</p>\n\n<h2 class=\"ladillo\">Falta por cerrar los detalles del encuentro</h2>\n\n<p>La decisi&oacute;n de celebrarlo de forma virtual ha surgido despu&eacute;s de que la Casa Blanca se enterara de que&#160;<strong>Xi &quot;no tiene previsto viajar&quot; a la cumbre del G20 en Roma</strong>&#160;a finales de este mes, y de que ambos lideres no coincidir&aacute;n f&iacute;sicamente &quot;en el futuro cercano&quot;.&nbsp;</p>\n\n<p>Biden y Xi&#160;<a href=\"https://www.rtve.es/noticias/20210910/biden-conversacion-telefonica-xi-jinping/2170040.shtml\">han hablado dos veces por tel&eacute;fono este a&ntilde;o</a>, la &uacute;ltima de ellas el pasado 9 de septiembre, pero nunca se han reunido en persona.</p>\n\n<p>@@MEDIA[5789943,a]</p>\n\n<p>Desde entonces, l<strong>a relaci&oacute;n entre las dos potencias ha mantenido</strong>&#160;el&#160;<strong>grado de tensi&oacute;n que la caracteriz&oacute; durante el mandato de Donald Trump</strong>&#160;(2017-2018), con fricciones en los planos comercial, tecnol&oacute;gico, de derechos humanos o de seguridad.</p>\n\n<p>El encuentro entre Sullivan y Yang se ha producido en un clima enrarecido por las incursiones de aviones chinos cerca de Taiw&aacute;n, que han provocado que las relaciones entre Taipei y Pek&iacute;n atraviesen su peor momento en las &uacute;ltimas cuatro d&eacute;cadas, seg&uacute;n las autoridades de la isla.</p>\n\n<p>Lo que quiere Washington, ha recalcado la citada funcionaria, es&#160;<strong>&quot;conseguir un estado estable en las relaciones entre Estados Unidos y China,</strong>&#160;para poder competir de forma intensa&quot; pero &quot;responsable&quot;, aunque aun faltan por cerrar los detalles del encuentro.&nbsp;</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "RTVE.es",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Noticias/Mundo/Norteamérica/Estados Unidos",
        "mainCategoryLang": "Noticias/Mundo/Norteamérica/Estados Unidos",
        "otherTopicsName": [
          "Tags Libres/Joe Biden",
          "Tags Libres/Relaciones internacionales",
          "Tags Libres/Xi Jinping",
          "Noticias/Mundo/Asia/China"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2182960/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2182960/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2182960/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2182960/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2182960/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2182960/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2182960/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2182960/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2182960/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2182960/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2182960/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2182960/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2182960/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2182960/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2182960/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Información y actualidad",
            "generoInfUid": "GE_INFOR",
            "generoId": "136528",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "Joe Biden y Xi Jinping se reunirán virtualmente antes de final de año"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2182141",
        "htmlUrl": "https://www.rtve.es/noticias/20211007/luz-marca-su-tercer-record-semana-28853-euros-mwh-este-jueves/2182141.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2182141/",
        "id": "2182141",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/1011",
        "popularity": "33.5549",
        "popHistoric": "33.5549",
        "numVisits": "962",
        "publicationDate": "07-10-2021 00:05:00",
        "expirationDate": null,
        "modificationDate": "07-10-2021 00:08:19",
        "publicationDateTimestamp": 1633557900000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2182141/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/precio-luz/1532862461871.jpg",
        "imageSEO": "https://img2.rtve.es/n/luz-marca-su-tercer-record-semana-28853-euros-mwh-este-jueves_2182141.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": null,
        "anteTitleUrl": null,
        "longTitle": "El precio de la luz bate récords este jueves: cuesta de media 288 euros MW/h y la hora más cara supera los 300 euros",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li>El precio de la electricidad marca el tercer r&eacute;cord en una semana y se encarece en 60 euros en un solo d&iacute;a, un 26 % m&aacute;s</li>\n\t<li>La hora m&aacute;s cara de la historia se coloca en 319,03 euros MWh de 20:00 a 21:00 horas</li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>El precio medio de la electricidad&nbsp;<strong>vuelve a marcar un nuevo r&eacute;cord con 288,53&nbsp;euros&nbsp;</strong>el megavatio hora (MWh) este jueves, es la&nbsp;<strong>mayor subida en un solo d&iacute;a ya que se encarece en casi 60 euros</strong>&nbsp;con respecto a esta jornada, un 26 % m&aacute;s.</p>\n\n<p>As&iacute;, la luz contin&uacute;a&nbsp;en m&aacute;ximos durante los primeros d&iacute;as de octubre, con tres r&eacute;cords en menos de una semana,&nbsp;el pasado viernes, cuando&nbsp;<a href=\"https://www.rtve.es/noticias/20211001/precio-luz-bate-todos-records-216-euros-kwh-este-viernes/2176801.shtml\" target=\"_blank\">se elev&oacute; hasta los 216&nbsp;euros/MWh</a>&nbsp;y en&nbsp;<a href=\"https://www.rtve.es/noticias/20211006/luz-alcanza-nuevo-record-22859-euros-mwh-este-miercoles/2180700.shtml\">este mi&eacute;rcoles, 228,59 euros</a>.&nbsp; El precio&nbsp;<strong>sube un 52 % respecto a hace una semana</strong>, cuando se situaba&nbsp;en 189,8 euros/MWh.</p>\n\n<p><iframe aria-label=\"Interactive line chart\" frameborder=\"0\" height=\"400\" id=\"datawrapper-chart-6sutU\" scrolling=\"no\" src=\"https://datawrapper.dwcdn.net/6sutU/53/\" style=\"width: 0; min-width: 100% !important; border: none;\" title=\"Evolución diaria del precio del MWh en España en 2021\"></iframe><script type=\"text/javascript\">!function(){\"use strict\";window.addEventListener(\"message\",(function(e){if(void 0!==e.data[\"datawrapper-height\"]){var t=document.querySelectorAll(\"iframe\");for(var a in e.data[\"datawrapper-height\"])for(var r=0;r<t.length;r++){if(t[r].contentWindow===e.source)t[r].style.height=e.data[\"datawrapper-height\"][a]+\"px\"}}}))}();\n</script></p>\n\n<p>Tras concluir septiembre con un precio medio r&eacute;cord, solo despu&eacute;s de julio y agosto, octubre ya ha registrado<strong>&nbsp;los tres precios m&aacute;s altos vistos hasta ahora&nbsp;</strong>en solo seis jornadas, y la tendencia sigue al alza.</p>\n\n<p>La luz sigue desbocada con&nbsp;<strong>la hora m&aacute;s cara de la historia&nbsp;</strong>entre las 20:00 y las 21.00 horas del jueves, cuando superar&aacute; por primera vez la barrera de los 300 euros, con&nbsp;<strong>319,03 euros MWh</strong>. El precio m&aacute;s barato ha sido de madrugada&nbsp;entre las 04:00 y las 05:00 horas con&nbsp;249,08&nbsp;euros/MWh, un nivel m&aacute;s alto que la media de este mi&eacute;rcoles.</p>\n\n<p>Compar&aacute;ndolo con hace un a&ntilde;o, el precio de la electricidad se ha&nbsp;<strong>casi septuplicado</strong>, era de 43,02&nbsp;euros el 7&nbsp;de octubre de 2020.</p>\n\n<p><iframe aria-label=\"Interactive line chart\" frameborder=\"0\" height=\"400\" id=\"datawrapper-chart-IQx2P\" scrolling=\"no\" src=\"https://datawrapper.dwcdn.net/IQx2P/31/\" style=\"width: 0; min-width: 100% !important; border: none;\" title=\"Comparación del precio del MWh en 2020 y 2021\"></iframe><script type=\"text/javascript\">!function(){\"use strict\";window.addEventListener(\"message\",(function(e){if(void 0!==e.data[\"datawrapper-height\"]){var t=document.querySelectorAll(\"iframe\");for(var a in e.data[\"datawrapper-height\"])for(var r=0;r<t.length;r++){if(t[r].contentWindow===e.source)t[r].style.height=e.data[\"datawrapper-height\"][a]+\"px\"}}}))}();\n</script></p>\n\n<p>El precio de la electricidad en Espa&ntilde;a ya ha marcado sus mayores precios hist&oacute;ricos tanto en julio como en agosto, mientras que septiembre ha rebasado ambos registros -hasta una media de 155 euros/MWh- y octubre parece que no se quedar&aacute; atr&aacute;s, con cuatro&nbsp;d&iacute;as por encima de la barrera de los 200 euros y cerca del umbral de los 300 euros.&nbsp;</p>\n\n<p>La media del precio de la luz en lo que&nbsp;<strong>va de mes de octubre es de 201,2 euros/MWh</strong>, pr&aacute;cticamente 50 euros m&aacute;s que el promedio con que se cerr&oacute; el mes de septiembre</p>\n\n<p>@@NOTICIA[2176403,IMAGEN,FIRMA]</p>\n\n<p>Este nuevo incremento en la luz se produce en plena&nbsp;<strong>escalada mundial del precio de todas las materias primas&nbsp;</strong>vinculadas a la energ&iacute;a, como el gas, el petr&oacute;leo y el carb&oacute;n, que provoca tener que recurrir a las opciones m&aacute;s baratas, pero m&aacute;s contaminantes, lo que dispara los derechos de CO<sub>2</sub>, tambi&eacute;n en m&aacute;ximos hist&oacute;ricos.&nbsp;</p>\n\n<h2 class=\"ladillo\">Italia supera los 300 euros/MWh</h2>\n\n<p>Este jueves pa&iacute;ses en los que el precio de la electricidad suele estar por debajo del de Espa&ntilde;a, tendr&aacute;n precios m&aacute;s altos. En concreto, en&nbsp;<strong>Francia se llegar&aacute; a los 298,32 euros/MWh</strong>&nbsp;y en Alemania a 302,53 euros/MWh; mientras que en el Reino Unido, con un sistema el&eacute;ctrico aislado, el precio tambi&eacute;n ser&aacute; superior, de 264,67 libras (311,25 euros/MWh).&nbsp;<strong>Italia llegar&aacute; a los 307,72 euros/MWh</strong>.</p>\n\n<p>De acuerdo con el operador del mercado ib&eacute;rico de&nbsp;<strong>gas</strong>&nbsp;Mibgas, esta materia prima se quedar&aacute;&nbsp;<strong>en torno a&nbsp;85 euros/MWh en este mes</strong>&nbsp;de octubre, algo que previsiblemente empujar&aacute; el precio del&nbsp;<em>pool</em>.&nbsp;En Espa&ntilde;a, el precio para este mi&eacute;rcoles, es de&nbsp;<strong>113,77 euros/MWh</strong>, el gas se ha encarecido un 24,7 % en 24 horas.</p>\n\n<p>Los precios del gas, que el a&ntilde;o pasado marcaron durante el primer confinamiento de la pandemia su m&iacute;nimo hist&oacute;rico (3 euros por MWh en el mes de mayo), comenzaron a&nbsp;<strong>escalar en el pasado mes de junio</strong>&nbsp;hasta alcanzar los m&aacute;ximos actuales.</p>\n\n<h2 class=\"ladillo\">Espa&ntilde;a pide una reforma europea</h2>\n\n<p>Espa&ntilde;a se ha aliado&nbsp;con Francia, Grecia, Rep&uacute;blica Checa y Ruman&iacute;a para&nbsp;<strong>reclamar a la Comisi&oacute;n Europea una reforma&nbsp;</strong>en el mercado el&eacute;ctrico. En un comunicado, han pedido tambi&eacute;n&nbsp;<strong>coordinar la compra de gas</strong>&nbsp;en Europa por el &quot;dram&aacute;tico aumento de los precios&quot;.</p>\n\n<p>@@NOTICIA[2181480,IMAGEN]</p>\n\n<p>Las el&eacute;ctricas han respondido al recorte de beneficios impuesto por el Gobierno para bajar el recibo. Compa&ntilde;&iacute;as como Iberdrola o Endesa han instado&nbsp;<a href=\"https://www.rtve.es/noticias/20210929/electricas-revisar-contratos/2176343.shtml\" target=\"_blank\">a sus grandes clientes a revisar los contratos</a>&nbsp;de suministro a largo plazo con el fin de amortiguar el impacto de la reforma. Asimismo, la el&eacute;ctrica presidida por Ignacio Gal&aacute;n ha anunciado que paralizar&aacute; sus inversiones en energ&iacute;as renovables.</p>\n\n<p>La Asociaci&oacute;n de Empresas de Energ&iacute;a El&eacute;ctrica&nbsp;<strong>est&aacute; preocupada por el da&ntilde;o reputacional&nbsp;</strong>que les est&aacute; haciendo la subida imparable de los precios en los &uacute;ltimos meses, pero defienden en&nbsp;<em>RNE</em>&nbsp;que&nbsp;<a href=\"https://www.rtve.es/play/audios/las-mananas-de-rne-con-inigo-alfonso/empresas-electricas-dicen-sentirse-senaladas/6124300/\">directamente no pueden hacer nada por evitarlo</a>.</p>\n\n<p>En cualquier caso, el precio de la cotizaci&oacute;n que se publica cada d&iacute;a,&nbsp;<strong>seguir&aacute; en cotas elevadas y subiendo, al menos, hasta marzo</strong>&nbsp;de 2022, momento en el que decaer&aacute; el&nbsp;<a href=\"https://www.rtve.es/noticias/20210914/gobierno-lan-choque-luz-electricidad/2170921.shtml\">plan de choque del Gobierno</a>. Mientras tanto, la factura deber&iacute;a estabilizarse a pesar del alza en el mercado mayorista.</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "RTVE.es/AGENCIAS",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Noticias/Economía",
        "mainCategoryLang": "Noticias/Economía",
        "otherTopicsName": [
          "Tags Libres/Consumo",
          "Tags Libres/Energía",
          "Tags Libres/Compañías eléctricas",
          "Tags Libres/Energía eléctrica",
          "Tags Libres/Tarifas eléctricas"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2182141/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2182141/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2182141/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2182141/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2182141/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2182141/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2182141/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2182141/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2182141/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2182141/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2182141/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2182141/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2182141/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2182141/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2182141/relacionados/relacionados-por-idioma",
        "generos": null,
        "title": "El precio de la luz bate récords este jueves: cuesta de media 288 euros MW/h y la hora más cara supera los 300 euros"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2181761",
        "htmlUrl": "https://www.rtve.es/noticias/20211006/casado-ley-vivienda-tc-comunidades-pp/2181761.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2181761/",
        "id": "2181761",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/1420",
        "popularity": "37.1484",
        "popHistoric": "37.1484",
        "numVisits": "1651",
        "publicationDate": "06-10-2021 23:25:00",
        "expirationDate": null,
        "modificationDate": "06-10-2021 23:31:09",
        "publicationDateTimestamp": 1633555500000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2181761/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/casado-llevara-constitucional-ley-vivienda-comunidades-del-pp-no-aplicaran-intervencionismo-suicida/1633522692819.jpg",
        "imageSEO": "https://img2.rtve.es/n/casado-ley-vivienda-tc-comunidades-pp_2181761.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": null,
        "anteTitleUrl": null,
        "longTitle": "El PP llevará al Constitucional la ley de vivienda y sus comunidades no la aplicarán: \"El intervencionismo es suicida\"",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li>Andaluc&iacute;a, Murcia y los ayuntamientos de Madrid y Le&oacute;n (PSOE) ya han anunciado que ir&aacute;n en contra de las medidas del Gobierno</li>\n\t<li>La ley&nbsp;contempla la limitaci&oacute;n del alquiler en zonas tensionadas y un recargo del IBI del 150% para viviendas vac&iacute;as</li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>El l&iacute;der del PP,&nbsp;<a href=\"https://www.rtve.es/temas/pablo-casado/118770/\" target=\"_self\"><strong>Pablo Casado</strong></a>, ha anunciado que su formaci&oacute;n llevar&aacute;&nbsp;<strong>al Tribunal Constitucional la&nbsp;<a href=\"https://www.rtve.es/noticias/20211005/claves-ley-vivienda/2180820.shtml\" target=\"_self\">futura ley de vivienda</a></strong>&nbsp;del Gobierno&nbsp;y<strong>&nbsp;no la aplicar&aacute;n en sus comunidades</strong>&nbsp;aut&oacute;nomas. A su entender, &quot;este&nbsp;<strong>intervencionismo&nbsp;</strong>es suicida&quot; y demuestra que Espa&ntilde;a tiene &quot;el Gobierno m&aacute;s radical de la Uni&oacute;n Europea&quot;.</p>\n\n<p>En una entrevista en Telecinco, Casado ha se&ntilde;alado que esa intervenci&oacute;n en el mercado del alquiler lanza<strong>&nbsp;un &quot;mensaje de inseguridad jur&iacute;dica&quot;</strong>&nbsp;y ha se&ntilde;alado que un Gobierno no puede<strong>&nbsp;&quot;interferir&quot; en la libertad y en la propiedad privada.</strong></p>\n\n<p>El jefe de la oposici&oacute;n ha avisado que con las medidas del Gobierno lo que va a suceder es que la gente no ponga sus pisos en alquiler y al final haya menos pisos. Es m&aacute;s, ha a&ntilde;adido que no es una cuesti&oacute;n de dar ayudas sino de dar seguridad jur&iacute;dica, que vengan a Espa&ntilde;a los inversores y que los j&oacute;venes tengan empleo porque as&iacute; podr&aacute;n acceder al alquiler.</p>\n\n<p>@@NOTICIA[2180820,IMAGEN,FIRMA]</p>\n\n<p>Por eso, ha anunciado que el PP llevar&aacute; la decisi&oacute;n del Gobierno de &quot;intervenir&quot; el mercado del alquiler ante el Constitucional.&nbsp;<strong>&quot;S&aacute;nchez es reh&eacute;n de sus socios radicales</strong>&nbsp;y es una pena que Espa&ntilde;a tenga el Gobierno m&aacute;s radical de la UE&quot;, ha manifestado, para recordar que su partido tambi&eacute;n llev&oacute; al TC la ley de alquileres de Catalu&ntilde;a.</p>\n\n<p>La Ley de Vivienda anunciada este martes por el Gobierno regular&aacute; los alquileres, entre otras cosas limitando los precios a los grandes tenedores, y bajar&aacute; por ley los alquileres en base al &iacute;ndice de referencia para todos los contratos en las zonas de mercado tensionado y la retirada de privilegios fiscales.</p>\n\n<p>Seg&uacute;n el acuerdo,&nbsp;<strong>ser&aacute;n las comunidades aut&oacute;nomas las que deber&aacute;n solicitar al Gobierno la declaraci&oacute;n de zonas de mercado de alquiler tensionado</strong>, que ser&aacute; donde se aplicar&aacute; la regulaci&oacute;n de precios a los propietarios de m&aacute;s de diez viviendas.</p>\n\n<p>@@NOTICIA[2181760,IMAGEN]</p>\n\n<p>Ya este martes,<a href=\"https://www.rtve.es/noticias/20211005/pp-ceoe-reacciones-ley-vivienda/2180840.shtml\" target=\"_self\">&nbsp;el PP y la CEOE criticaron la ley como un ataque a la propiedad privada</a>. Ahora, la ministra de Transportes, Movilidad y Agenda Urbana,&nbsp;<strong>Raquel S&aacute;nchez, ha asegurado que los propietarios pueden estar tranquilos</strong>&nbsp;con la ley de vivienda porque<strong>&nbsp;&quot;en ning&uacute;n caso se produce un intervencionismo radical&quot;</strong>&nbsp;y se ha mostrado convencida de que los fondos seguir&aacute;n invirtiendo en Espa&ntilde;a. En una entrevista en Onda Cero, ha defendido que el anteproyecto de ley establece &quot;una serie de medidas que no hacen totalmente inviable a esos grandes fondos de inversi&oacute;n que inviertan en nuestro pa&iacute;s, que sigue siendo atractivo por muchas m&aacute;s cuestiones&quot;.</p>\n\n<h2 class=\"ladillo\">Andaluc&iacute;a y Murcia rechaza la limitaci&oacute;n del precio de los alquileres</h2>\n\n<p>La&nbsp;<strong>Junta de Andaluc&iacute;a</strong>, gobernada por PP y Ciudadanos, ya ha expresado este mi&eacute;rcoles su<strong>&nbsp;rechazo a la futura ley de vivienda</strong>, que ha calificado de&nbsp;<strong>&quot;intervencionista&quot;</strong>, y ha informado de que se opondr&aacute; a la limitaci&oacute;n del precio de los alquileres que plantea la norma.</p>\n\n<p>Para el Ejecutivo andaluz, las medidas provocar&aacute;n el efecto &quot;contrario&quot; al que persigue.&nbsp;As&iacute; lo ha considerado la consejera andaluza de Fomento, Marifran Carazo, quien ha opinado que la aplicaci&oacute;n de estas medidas en otros pa&iacute;ses ha supuesto<strong>&nbsp;&quot;la retirada de inversiones y ha aumentado los precios&quot;&nbsp;</strong>de los alquileres, por lo que ha zanjado que esta &quot;no es la soluci&oacute;n&quot;.</p>\n\n<p>@@MEDIA[6128358,v]</p>\n\n<p>Seg&uacute;n la consejera,&nbsp;<strong>el Gobierno andaluz trabaja en la direcci&oacute;n contraria</strong>, es decir en la promoci&oacute;n de nuevas viviendas de alquiler protegida a precio asequible con la participaci&oacute;n de los ayuntamientos y de los promotores privados.</p>\n\n<p>Por su parte, el presidente de la Regi&oacute;n de Murcia,&nbsp;Fernando L&oacute;pez Miras, ha calificado el anteproyecto como &quot;una ley expropiadora&rdquo; que no aplicar&aacute;.</p>\n\n<p>El mandatario regional, presente en Madrid con motivo de la feria hortofrut&iacute;cola Fruit Attraction 2021, ha opinado que la ley est&aacute;&nbsp;<strong>&ldquo;alejada de las pol&iacute;ticas liberales&rdquo;</strong>&nbsp;de su gobierno, por lo que buscar&aacute;n los mecanismos para &ldquo;legislar de tal forma que&nbsp;<strong>no se aplique en Murcia&rdquo;</strong>.<br />\n<br />\n&ldquo;El gobierno regional apuesta por la libertad de las personas, por la libre competencia, por la econom&iacute;a de mercado, porque cada uno trabaje, pague pocos impuestos y pueda hacer lo que le d&eacute; la gana con lo que se ha ganado con el sudor de su frente&rdquo;, ha detallado ante la prensa.</p>\n\n<h2 class=\"ladillo\">Los alcaldes dicen que el IBI no subir&aacute; en Madrid ni Le&oacute;n</h2>\n\n<p>El alcalde de Madrid y portavoz nacional del PP, Jos&eacute; Luis Mart&iacute;nez-Almeida, ha garantizado por su parte&nbsp;que<strong>&nbsp;no subir&aacute; el IBI en la capital</strong>&nbsp;pese al recargo del IVI de hasta el 150% para viviendas vac&iacute;as que contempla la ley.&nbsp;&nbsp;</p>\n\n<p>&quot;En el caso de que lo mantenga en t&eacute;rminos opcionales, el Ayuntamiento de Madrid no aplicar&aacute; el recargo (...) Y, en el caso de que nos obligue, ya articularemos las&nbsp;<strong>medidas para que todos los madrile&ntilde;os puedan seguir disfrutando de la rebaja del IBI</strong>&quot;, ha declarado Almeida a los medios tras asistir a la inauguraci&oacute;n de la South Summit 2021.</p>\n\n<p>De este modo, Almeida ha refrendado su&nbsp;<strong>compromiso de rebajar el IBI progresivamente a lo largo del mandato</strong>, llevando el tipo de gravamen general hasta el m&iacute;nimo legal del 0,4%, al tiempo que ha criticado la reforma del Ejecutivo, que a su juicio &quot;lo que va a conseguir es que los j&oacute;venes tengan cada vez m&aacute;s problemas para independizarse&quot;.</p>\n\n<p>Tambi&eacute;n&nbsp;<strong>el alcalde de Le&oacute;n, el socialista Jos&eacute; Antonio Diez</strong>, ha descartado este mi&eacute;rcoles incrementar la carga fiscal mediante el IBI.&nbsp;En declaraciones a los periodistas,ha subrayado que los impuestos que pagan los leoneses son suficientes, y ha recalcado que &quot;no es momento de aumentar la presi&oacute;n fiscal&quot;: &quot;Es cierto que este gravamen va sobre segundas y terceras propiedades, pero ahora mismo no est&aacute; sobre la mesa ning&uacute;n tipo de incremento impositivo en Le&oacute;n&quot;, ha abundado el regidor socialista.</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "RTVE.es/AGENCIAS",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Noticias/España",
        "mainCategoryLang": "Noticias/España",
        "otherTopicsName": [
          "Tags Libres/Vivienda",
          "Tags Libres/PP/Partido Popular",
          "Noticias/España/Andalucía",
          "Tags Libres/Junta de Andalucía"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2181761/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2181761/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2181761/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2181761/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2181761/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2181761/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2181761/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2181761/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2181761/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2181761/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2181761/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2181761/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2181761/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2181761/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2181761/relacionados/relacionados-por-idioma",
        "generos": null,
        "title": "El PP llevará al Constitucional la ley de vivienda y sus comunidades no la aplicarán: \"El intervencionismo es suicida\""
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2182600",
        "htmlUrl": "https://www.rtve.es/deportes/20211006/uefa-nations-league-italia-espana-cronica/2182600.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2182600/",
        "id": "2182600",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/114610",
        "popularity": "39.593",
        "popHistoric": "39.593",
        "numVisits": "2455",
        "publicationDate": "06-10-2021 22:44:00",
        "expirationDate": null,
        "modificationDate": "06-10-2021 23:29:09",
        "publicationDateTimestamp": 1633553040000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2182600/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/resumen-goles-del-italia-1-2-espana/1633554642009.jpg",
        "imageSEO": "https://img2.rtve.es/n/uefa-nations-league-italia-espana-cronica_2182600.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": "Liga de Naciones | Italia 1-2 España",
        "anteTitleUrl": null,
        "longTitle": "España culmina su 'vendetta' en casa de Italia",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": "<p><strong>Ficha t&eacute;cnica:</strong></p>\n\n<p><strong>1 - Italia</strong>: Donnarumma; Di Lorenzo, Bonucci, Bastoni, Emerson; Barella (Calabria, m.72), Jorginho (Pellegrini, m.64), Verratti (Locatelli, m.58); Bernardeschi (Chiellini, m.50), Insigne (Kean, m.58) y Chiesa.</p>\n\n<p><strong>2 - Espa&ntilde;a</strong>: Unai Sim&oacute;n; Azpilicueta, Laporte, Pau Torres, Marcos Alonso; Busquets, Koke (Mikel Merino, m.75), Gavi (Sergi Roberto, m.84); Oyarzabal, Ferran Torres (Yeremy Pino, m.49) y Sarabia (Bryan Gil, m.75).</p>\n\n<p><strong>Goles</strong>: 0-1, m.17: Ferran Torres. 0-2, m.45 (+2): Ferran Torres. 1-2, m.83: Pellegrini.</p>\n\n<p><strong>&Aacute;rbitro</strong>: Sergej Karasev (RUS). Amonest&oacute; a Locatelli (82) por Italia; y a Azpilicueta (45), Sarabia (65), Yeremy (71) y Oyarzabal (89) por Espa&ntilde;a. Expuls&oacute; a Bonucci por doble amonestaci&oacute;n (29 y 41).</p>\n\n<p><strong>Incidencias</strong>: encuentro de semifinales de la Liga de Naciones disputado en San Siro ante 37.000 espectadores, el n&uacute;mero m&aacute;ximo permitido por la normativa italiana ante el coronavirus.</p>\n",
          "photo": null
        },
        "summary": "<ul>\n\t<li>La selecci&oacute;n espa&ntilde;ola vence en San Siro por 1-2 y jugar&aacute; el domingo la final de la Liga de Naciones</li>\n\t<li><a href=\"https://www.rtve.es/play/deportes/\">Final de la UEFA Nations League en directo</a>, domingo a las 20:45 en La 1 y RTVE Play</li>\n</ul>\n",
        "frontSummary": "<ul>\n\t<li><a href=\"https://www.rtve.es/play/deportes/\">Final de la UEFA Nations League en directo</a>, domingo a las 20:45 en La 1 y RTVE Play</li>\n</ul>\n",
        "text": "<p>La<strong>&nbsp;<a href=\"https://www.rtve.es/temas/seleccion-espanola-masculina-de-futbol/10430/\">selecci&oacute;n espa&ntilde;ola masculina de f&uacute;tbol</a>&nbsp;</strong>vence a&nbsp;<strong><a href=\"https://www.rtve.es/temas/seleccion-italiana-de-futbol/38754/\">Italia</a>&nbsp;</strong>por 1-2 en la primera semifial de la&nbsp;<a href=\"https://www.rtve.es/deportes/futbol/uefa-nations-league/\"><strong>Liga de Naciones de la UEFA</strong></a>. La Roja se toma as&iacute; la revancha de&nbsp;<a href=\"https://www.rtve.es/deportes/20210707/eurocopa-2021-semifinal-italia-espana-cronica/2122381.shtml\"><strong>las semifinales de la pasada Eurocopa</strong></a>, y lo hace adem&aacute;s en un feudo hasta la fecha inexpugnable para los transalpinos como el Giuseppe Meazza de Mil&aacute;n.</p>\n\n<p>93 a&ntilde;os llevaba San Siro sin ver una derrota de Italia y 50 llevaba Espa&ntilde;a sin ganar en suelo transalpino, nunca en partido oficial. Ahora jugar&aacute; el pr&oacute;ximo domingo la final contra el&nbsp;<strong>ganador del B&eacute;lgica - Francia</strong>&nbsp;que se disputa este jueves en Tur&iacute;n. Se rompe la racha de partidos sin perder de la actual campeona de Europa y se queda en 37.</p>\n\n<p><a href=\"https://www.rtve.es/temas/luis-enrique/77090/\"><strong>Luis Enrique</strong></a>&nbsp;<strong>apost&oacute; de inicio por Gavi a sus 17 a&ntilde;os y 60 d&iacute;as</strong>&nbsp;como gran sorpresa del once. El centrocampista del Bar&ccedil;a bati&oacute; un r&eacute;cord de precocidad de 85 a&ntilde;os para Espa&ntilde;a&nbsp;y el t&eacute;cnico cerr&oacute; de un portazo el debate -por llamarlo de alguna manera- que el d&iacute;a anterior tuvo con la prensa a cuenta de su convocatoria.</p>\n\n<p>Le cost&oacute; entrar al debutante y Espa&ntilde;a casi paga las p&eacute;rdidas de bal&oacute;n en el centro del campo en los primeros minutos. El primer aviso de Chiesa desde la frontal encontr&oacute; a un atento Unai Sim&oacute;n.</p>\n\n<p>La Roja deb&iacute;a hacer frente a la presi&oacute;n de los m&aacute;s de 30.000 &#39;tiffosi&#39; que animaban desde las gradas a casi todos los suyos. Casi, porque los milanistas no perdonaban el pasado interista del meta Donnaruma.</p>\n\n<p>El actual cancerbero del PSG no tuvo que intervenir, pero minutos despu&eacute;s el &aacute;rea local vio la mejor ocasi&oacute;n espa&ntilde;ola gracias a una triangulaci&oacute;n por la izquierda entre&nbsp;<strong>Alonso, Sarabia y un Oyarzabal&nbsp;</strong>que no acert&oacute; a disparar de manera clara.</p>\n\n<p>Fue un aviso de lo que lleg&oacute; despu&eacute;s con otra apertura de Alonso y esta vez Oyarzabal hizo de asistente para que&nbsp;<strong>Ferr&aacute;n Torres la pusiera en la red al primer toque (minuto 17)</strong>. Solo un minuto despu&eacute;s tuvo que deshacer Bonucci el fallo de Donnaruma ante el disparo de Marcos Alonso.</p>\n\n<p>Quinto gol de Torres en la presente Liga de Naciones, convirti&eacute;ndose en el goleador de la selecci&oacute;n espa&ntilde;ola en la presente edici&oacute;n del torneo.</p>\n\n<p>La esperada reacci&oacute;n de los de Mancini lleg&oacute; con m&aacute;s rabia que buen juego, pero sin bajar la intensidad de la presi&oacute;n sobre la salida del bal&oacute;n espa&ntilde;ola. No obstante,&nbsp;<strong>Bernardeschi tuvo una buena ocasi&oacute;n a la media hora&nbsp;</strong>que frustraron entre Unai Sim&oacute;n y el poste.</p>\n\n<p>Parec&iacute;a m&aacute;s clara la que tuvo Insigne pocos minutos despu&eacute;s con Unai descolocado, pero la mand&oacute; fuera el del N&aacute;poles con toda la porter&iacute;a para &eacute;l. Mientras, Gavi pasaba de perder balones a robarlos y lanzar contras, cediendo a Oyarzabal para que pusiera a prueba a Donnaruma.</p>\n\n<p>El meta italiano pas&oacute; de ser blanco de las iras por su pasado en el Inter de Mil&aacute;n a se&ntilde;alado como culpable por la moment&aacute;nea victoria de Espa&ntilde;a. Pero m&aacute;s culpa tuvo&nbsp;<strong>Bonucci</strong>, capit&aacute;n en ausencia de Chiellini,&nbsp;<strong>al dejar a su equipo con uno menos</strong>&nbsp;por ver la segunda amarilla tras un codazo a Busquets.</p>\n\n<h2 class=\"ladillo\">Doblete y lesi&oacute;n de Torres</h2>\n\n<p>Se le complicaban las cosas al campe&oacute;n de Europa con el marcador en contra, un jugador menos y escasa fluidez en su juego. San Siro enmudec&iacute;a con el segundo de Espa&ntilde;a,&nbsp;<strong>el segundo de Torres, tras una gran jugada al primer toque</strong>&nbsp;y de nuevo por la banda de Marcos Alonso, con la complicidad de Sarabia y Oyarzabal&nbsp;(minuto 46).</p>\n\n<p>La mala noticia para la Roja vino en forma de lesi&oacute;n del &#39;pichichi&#39; Torres por un lance del juego nada m&aacute;s reanudarse el partido en la segunda parte. En su lugar entr&oacute; el segundo debutante de la noche, Yeremi Pino.</p>\n\n<p>Tambi&eacute;n hizo cambios Mancini dando entrada al veterano Chiellini para amarrar la defensa y evitar el coladero en que se hab&iacute;a convertido. Minutos despu&eacute;s s&iacute; que entraron hombres de ataque con Moise Kean y Locatelli, seguidos de Calabria y Pellegrini</p>\n\n<p>Italia se volc&oacute; en ataque, pero entre medias de los cambios Espa&ntilde;a tuvo&nbsp;<strong>el tercero en la cabeza de Oyarzabal&nbsp;</strong>tras un gran pase e internada de Yeremi Pino. El remate del donostiarra se fue fuera por poco. Tambi&eacute;n movi&oacute; banquillo Luis Enrique pensando en el domingo y en dar descanso a hombres como Sarabia y Koke, para dar su oportunidad a Mikel Merino y Bryan Gil.</p>\n\n<p>Los locales lo intentaban con todo y trataban de aplicar sus viejas recetas, presionando con lo poco que ten&iacute;an a los espa&ntilde;oles y al &aacute;rbitro. La Roja, con toque y paciencia, trataba por su parte de&nbsp;<strong>acercarse al tercero y lo roz&oacute; Marcos Alonso en una contra</strong>. Su disparo lo detuvo Donnaruma y el rechace cay&oacute; a Bryan Gil, pero estuvo atento Chiellini.</p>\n\n<p>Sin embargo, Italia se meti&oacute; en el partido tras un error de la defensa espa&ntilde;ola en un c&oacute;rner, cuando Pau Torres fall&oacute; en la cesi&oacute;n atr&aacute;s y se la regal&oacute; a&nbsp;<strong>Chiesa para que lanzara la contra y Pellegrini rematara&nbsp;</strong>a placer (minuto 82). Tocaba sufrir al final ante un rival en inferioridad.</p>\n\n<p>Rug&iacute;a San Siro con cada bal&oacute;n largo de los suyos, espoleando para que trataran de evitar la que se convirti&oacute; con el paso del tiempo en su primera derrota en Mil&aacute;n.</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": 754,
          "name": "ÓSCAR LÓPEZ CANENCIA",
          "firma": null,
          "photo": "https://img2.rtve.es/resources/jpg/7/5/1513600482557.jpg",
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": "25-03-2010 18:26:27",
          "numPublications": 1672,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Deportes/Fútbol/Liga de Naciones UEFA",
        "mainCategoryLang": "Deportes/Fútbol/Liga de Naciones UEFA",
        "otherTopicsName": [
          "Tags Libres/Luis Enrique",
          "Deportes/Fútbol/Selección Española Masculina de Fútbol"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2182600/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2182600/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2182600/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2182600/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2182600/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2182600/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2182600/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2182600/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2182600/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2182600/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2182600/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2182600/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2182600/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2182600/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2182600/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Deportes",
            "generoInfUid": "GE_DEPOR",
            "generoId": "136529",
            "subGeneroInfUid": "GEN_FUTBOL",
            "subGeneroInf": "Fútbol",
            "subGeneroId": "137096"
          }
        ],
        "title": "España culmina su 'vendetta' en casa de Italia"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2183062",
        "htmlUrl": "https://www.rtve.es/noticias/20211006/erupcion-volcan-palma-ultima-hora/2183062.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2183062/",
        "id": "2183062",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/141190",
        "popularity": "0.0",
        "popHistoric": "8.0",
        "numVisits": "0",
        "publicationDate": "06-10-2021 22:30:00",
        "expirationDate": null,
        "modificationDate": "07-10-2021 07:48:31",
        "publicationDateTimestamp": 1633552200000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2183062/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/varias-personas-observan-desde-tijarafela-erupcion-del-volcan-cumbre-vieja-isla-canaria-palma/1633498352083.jpg",
        "imageSEO": "https://img2.rtve.es/n/erupcion-volcan-palma-ultima-hora_2183062.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": null,
        "anteTitleUrl": null,
        "longTitle": "Así te hemos contado la estabilización de la erupción del volcán de La Palma",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li>Se ha abierto una nueva fisura &#39;inactiva&#39; a 100 metros del cr&aacute;ter que solo emana gases</li>\n\t<li><a href=\"https://www.rtve.es/play/videos/directo/informativos/erupcion-palma-cono-del-volcan/3132/\">Ver en directo la erupci&oacute;n desde el cono del volc&aacute;n</a>&nbsp;|&nbsp;<a href=\"https://www.rtve.es/play/videos/directo/informativos/erupcion-palma-oceano/3133/\">En directo, la lava cae al oc&eacute;ano</a></li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>La erupci&oacute;n del volc&aacute;n de Cumbre Vieja, que empez&oacute; el pasado 19 de septiembre, contin&uacute;a su potente actividad y, seg&uacute;n los expertos,&nbsp;<strong>no es posible conocer cu&aacute;ndo terminar&aacute;, pero nada hace&nbsp;presagiar&nbsp;un final cercano</strong>, mientras las diferentes administraciones se coordinan&nbsp;para la reconstrucci&oacute;n&nbsp;de la isla y el Consejo de Ministros ha aprobado ya este martes el segundo paquete de ayudas de m&aacute;s de 213 millones de euros.</p>\n\n<p>Las coladas de lava, que los cient&iacute;ficos mantienen monitorizadas por si&nbsp;se produjera un cambio de direcci&oacute;n,&nbsp;siguen el mismo recorrido hacia el mar, mientras el volc&aacute;n sigue ajust&aacute;ndose, a las pautas de una erupci&oacute;n estromboliana, con fases explosivas y efusivas. Se ha abierto una nueva fisura en el entorno del cono volc&aacute;nico que no emite lava pero s&iacute; gases.&nbsp;</p>\n\n<p>La&nbsp;<strong>lava&nbsp;afecta ya a m&aacute;s de 420 hect&aacute;reas en la isla canaria&nbsp;</strong>y ha&nbsp;formado una fajana de lava&nbsp;de m&aacute;s de 38&nbsp;hect&aacute;reas.&nbsp;La red de vigilancia volc&aacute;nica de seguimiento&nbsp;del Instituto Geogr&aacute;fico Nacional (IGN) sigue detectando nuevos<strong>&nbsp;sismos</strong>&nbsp;en el entorno de la erupci&oacute;n del volc&aacute;n.</p>\n\n<p>M&aacute;s&nbsp;de 6.000 personas siguen desalojadas, pero desde el pasado fin de semana no hay confinamientos preventivos por los en El Paso, Los Llanos de Aridane y Tazacorte tras comprobarse&nbsp;que los picos de gases t&oacute;xicos no suponen un peligro para la salud.</p>\n\n<p>Dos<strong>&nbsp;plantas desaladoras port&aacute;tiles se encuentran ya en&nbsp;la isla de La Palma&nbsp;</strong>y, seg&uacute;n el Gobierno canario estar&aacute;n instaladas en Puerto Naos en un plazo de dos semanas, garantizando un caudal de riego a los cultivos de m&aacute;s de 5.000 metros c&uacute;bicos&nbsp;diarios. Tambi&eacute;n se espera la llegada de un buque cisterna con 30.000 metros c&uacute;bicos de agua que permitir&aacute; aumentar de forma sustancial el caudal.<br />\n<br />\nAs&iacute; ha sido&nbsp;el minuto a minuto&nbsp;de la erupci&oacute;n este mi&eacute;rcoles:</p>\n\n<p>@@MINUTOAMINUTO idevent=27041 vista=TODO@@</p>\n\n<p></p>\n\n<p></p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "S.QUÍLEZ / D. ÁLVAREZ",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Noticias/Especiales/Erupción volcánica en La Palma",
        "mainCategoryLang": "Noticias/Especiales/Erupción volcánica en La Palma",
        "otherTopicsName": [
          "Tags Libres/Terremotos",
          "Tags Libres/Catástrofes naturales",
          "Noticias/España/Canarias/Santa Cruz de Tenerife/La Palma",
          "Tags Libres/Volcanes",
          "Noticias/Especiales/Erupción volcánica en La Palma"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2183062/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2183062/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2183062/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2183062/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2183062/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2183062/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2183062/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2183062/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2183062/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2183062/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2183062/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2183062/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2183062/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2183062/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2183062/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Información y actualidad",
            "generoInfUid": "GE_INFOR",
            "generoId": "136528",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "Así te hemos contado la estabilización de la erupción del volcán de La Palma"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2181620",
        "htmlUrl": "https://www.rtve.es/noticias/20211006/erupcion-volcan-palma-ultima-hora/2181620.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2181620/",
        "id": "2181620",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/141190",
        "popularity": "49.9004",
        "popHistoric": "49.9004",
        "numVisits": "11395",
        "publicationDate": "06-10-2021 22:30:00",
        "expirationDate": null,
        "modificationDate": "06-10-2021 22:33:15",
        "publicationDateTimestamp": 1633552200000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2181620/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/varias-personas-observan-desde-tijarafela-erupcion-del-volcan-cumbre-vieja-isla-canaria-palma/1633498352083.jpg",
        "imageSEO": "https://img2.rtve.es/n/erupcion-volcan-palma-ultima-hora_2181620.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": null,
        "anteTitleUrl": null,
        "longTitle": "Así te hemos contado la estabilización de la erupción del volcán de La Palma",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li>Se ha abierto una nueva fisura &#39;inactiva&#39; a 100 metros del cr&aacute;ter que solo emana gases</li>\n\t<li><a href=\"https://www.rtve.es/play/videos/directo/informativos/erupcion-palma-cono-del-volcan/3132/\">Ver en directo la erupci&oacute;n desde el cono del volc&aacute;n</a>&nbsp;|&nbsp;<a href=\"https://www.rtve.es/play/videos/directo/informativos/erupcion-palma-oceano/3133/\">En directo, la lava cae al oc&eacute;ano</a></li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>La erupci&oacute;n del volc&aacute;n de Cumbre Vieja, que empez&oacute; el pasado 19 de septiembre, contin&uacute;a su potente actividad y, seg&uacute;n los expertos,&nbsp;<strong>no es posible conocer cu&aacute;ndo terminar&aacute;, pero nada hace&nbsp;presagiar&nbsp;un final cercano</strong>, mientras las diferentes administraciones se coordinan&nbsp;para la reconstrucci&oacute;n&nbsp;de la isla y el Consejo de Ministros ha aprobado ya este martes el segundo paquete de ayudas de m&aacute;s de 213 millones de euros.</p>\n\n<p>Las coladas de lava, que los cient&iacute;ficos mantienen monitorizadas por si&nbsp;se produjera un cambio de direcci&oacute;n,&nbsp;siguen el mismo recorrido hacia el mar, mientras el volc&aacute;n sigue ajust&aacute;ndose, a las pautas de una erupci&oacute;n estromboliana, con fases explosivas y efusivas. Se ha abierto una nueva fisura en el entorno del cono volc&aacute;nico que no emite lava pero s&iacute; gases.&nbsp;</p>\n\n<p>La&nbsp;<strong>lava&nbsp;afecta ya a m&aacute;s de 420 hect&aacute;reas en la isla canaria&nbsp;</strong>y ha&nbsp;formado una fajana de lava&nbsp;de m&aacute;s de 38&nbsp;hect&aacute;reas.&nbsp;La red de vigilancia volc&aacute;nica de seguimiento&nbsp;del Instituto Geogr&aacute;fico Nacional (IGN) sigue detectando nuevos<strong>&nbsp;sismos</strong>&nbsp;en el entorno de la erupci&oacute;n del volc&aacute;n.</p>\n\n<p>M&aacute;s&nbsp;de 6.000 personas siguen desalojadas, pero desde el pasado fin de semana no hay confinamientos preventivos por los en El Paso, Los Llanos de Aridane y Tazacorte tras comprobarse&nbsp;que los picos de gases t&oacute;xicos no suponen un peligro para la salud.</p>\n\n<p>Dos<strong>&nbsp;plantas desaladoras port&aacute;tiles se encuentran ya en&nbsp;la isla de La Palma&nbsp;</strong>y, seg&uacute;n el Gobierno canario estar&aacute;n instaladas en Puerto Naos en un plazo de dos semanas, garantizando un caudal de riego a los cultivos de m&aacute;s de 5.000 metros c&uacute;bicos&nbsp;diarios. Tambi&eacute;n se espera la llegada de un buque cisterna con 30.000 metros c&uacute;bicos de agua que permitir&aacute; aumentar de forma sustancial el caudal.<br />\n<br />\nAs&iacute; ha sido&nbsp;el minuto a minuto&nbsp;de la erupci&oacute;n este mi&eacute;rcoles:</p>\n\n<p>@@MINUTOAMINUTO idevent=27041 vista=TODO@@</p>\n\n<p></p>\n\n<p></p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "S.QUÍLEZ / D. ÁLVAREZ",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Noticias/Especiales/Erupción volcánica en La Palma",
        "mainCategoryLang": "Noticias/Especiales/Erupción volcánica en La Palma",
        "otherTopicsName": [
          "Tags Libres/Terremotos",
          "Tags Libres/Catástrofes naturales",
          "Noticias/España/Canarias/Santa Cruz de Tenerife/La Palma",
          "Tags Libres/Volcanes",
          "Noticias/Especiales/Erupción volcánica en La Palma"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2181620/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2181620/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2181620/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2181620/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2181620/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2181620/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2181620/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2181620/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2181620/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2181620/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2181620/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2181620/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2181620/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2181620/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2181620/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Información y actualidad",
            "generoInfUid": "GE_INFOR",
            "generoId": "136528",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "Así te hemos contado la estabilización de la erupción del volcán de La Palma"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2181640",
        "htmlUrl": "https://www.rtve.es/noticias/20211006/coronavirus-covid-directo-espana-mundo-ultima-hora/2181640.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2181640/",
        "id": "2181640",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/129647",
        "popularity": "45.0373",
        "popHistoric": "45.0373",
        "numVisits": "5460",
        "publicationDate": "06-10-2021 22:23:00",
        "expirationDate": null,
        "modificationDate": "06-10-2021 22:23:48",
        "publicationDateTimestamp": 1633551780000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2181640/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/homenaje-antepasados-india-sin-distancia-seguridad/1633500201982.jpg",
        "imageSEO": "https://img2.rtve.es/n/coronavirus-covid-directo-espana-mundo-ultima-hora_2181640.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": "Coronavirus",
        "anteTitleUrl": "https://www.rtve.es/noticias/coronavirus-covid-19/",
        "longTitle": "Coronavirus España, 6 de octubre | Sanidad notifica 2.303 contagios y 57 muertes y la incidencia baja a 51",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li><a href=\"https://www.rtve.es/noticias/20211001/mapa-del-coronavirus-espana/2004681.shtml\">Mapa de Espa&ntilde;a</a>&nbsp;|&nbsp;<a href=\"https://www.rtve.es/noticias/20210920/curva-contagios-muertes-coronavirus-espana-dia-dia/2010514.shtml\">Evoluci&oacute;n de la curva</a><a href=\"https://www.rtve.es/noticias/20210921/curva-contagios-muertes-coronavirus-espana-dia-dia/2010514.shtml\">&nbsp;|</a>&nbsp;<a href=\"https://www.rtve.es/noticias/20210921/ocupacion-camas-covid-19-hospitales-espanoles/2042349.shtml\">Hospitales y UCI</a></li>\n\t<li><a href=\"https://www.rtve.es/noticias/20211001/campana-vacunacion-espana/2062499.shtml\">Vacunas en Espa&ntilde;a</a>&nbsp;|&nbsp;<a href=\"https://www.rtve.es/noticias/20211001/mapa-confinamientos-espana-coronavirus-restricciones/2041269.shtml\">Gu&iacute;a de restricciones</a>&nbsp;|&nbsp;<a href=\"https://www.rtve.es/noticias/20211001/mapa-mundial-del-coronavirus/1998143.shtml\">Mapa mundial&#8203;</a>&nbsp;|&nbsp;<a href=\"https://www.rtve.es/lab/vacunacion-espana-coronavirus/\">Especial: La gran vacunaci&oacute;n</a></li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>Sanidad ha notificado 2.303 contagios de COVID-19 y 57 muertes en las &uacute;ltimas 24 horas. La incidencia del coronavirus en Espa&ntilde;a sigue bajando, aunque a menor velocidad:&nbsp;<strong>se detectan 50,96&nbsp;casos de COVID-19&nbsp;</strong>por cada 100.000 habitantes.</p>\n\n<p>La campa&ntilde;a de vacunaci&oacute;n avanza a buen ritmo, m&aacute;s de 36,7 millones de personas tienen la pauta completa (77,5 % de la poblaci&oacute;n espa&ntilde;ola), y m&aacute;s de 37,7 millones han recibido al menos una dosis (79,5 % de los residentes en Espa&ntilde;a).</p>\n\n<p>La Agencia Europea de Medicamentos (EMA) recomienda&nbsp;una&nbsp;<strong>tercera dosis de la vacuna para personas inmunodeprimidas</strong>&nbsp;y una dosis adicional de refuerzo para la poblaci&oacute;n general. En la&nbsp;<strong>Comisi&oacute;n de Salud P&uacute;blica,&nbsp;</strong>donde se reunen las comunidades aut&oacute;nomas con el Ministerio de Sanidad, Madrid y Galicia votaron en contra de las inyecciones extra por falta de suficiente evidencia cient&iacute;fica, pero la propuesta sali&oacute; adelante.</p>\n\n<p>As&iacute; te hemos contado la actualidad sobre la pandemia de coronavirus:</p>\n\n<p>@@MINUTOAMINUTO idevent=27061 vista=TODO@@</p>\n\n<p></p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "CRISTINA PÉREZ / NOA G. SANTIAGO",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Noticias/Especiales/Coronavirus",
        "mainCategoryLang": "Noticias/Especiales/Coronavirus",
        "otherTopicsName": [
          "Tags Libres/Epidemias",
          "Tags Libres/Enfermedades infecciosas",
          "Tags Libres/Vacunas",
          "Tags Libres/Virus",
          "Noticias/España"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2181640/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2181640/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2181640/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2181640/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2181640/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2181640/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2181640/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2181640/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2181640/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2181640/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2181640/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2181640/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2181640/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2181640/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2181640/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Información y actualidad",
            "generoInfUid": "GE_INFOR",
            "generoId": "136528",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "Coronavirus España, 6 de octubre | Sanidad notifica 2.303 contagios y 57 muertes y la incidencia baja a 51"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2183060",
        "htmlUrl": "https://www.rtve.es/noticias/20211006/coronavirus-covid-directo-espana-mundo-ultima-hora/2183060.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2183060/",
        "id": "2183060",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/129647",
        "popularity": "0.0",
        "popHistoric": "8.0",
        "numVisits": "0",
        "publicationDate": "06-10-2021 22:23:00",
        "expirationDate": null,
        "modificationDate": "07-10-2021 07:48:54",
        "publicationDateTimestamp": 1633551780000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2183060/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/sanitaria-prepara-dosis-vacuna-pfizer-portugal/1633439835456.jpg",
        "imageSEO": "https://img2.rtve.es/n/coronavirus-covid-directo-espana-mundo-ultima-hora_2183060.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": "Coronavirus",
        "anteTitleUrl": "https://www.rtve.es/noticias/coronavirus-covid-19/",
        "longTitle": "Coronavirus España, hoy | España roza el riesgo bajo de contagios en el que ya se encuentran diez CC.AA",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li><a href=\"https://www.rtve.es/noticias/20211001/mapa-del-coronavirus-espana/2004681.shtml\">Mapa de Espa&ntilde;a</a>&nbsp;|&nbsp;<a href=\"https://www.rtve.es/noticias/20210920/curva-contagios-muertes-coronavirus-espana-dia-dia/2010514.shtml\">Evoluci&oacute;n de la curva</a><a href=\"https://www.rtve.es/noticias/20210921/curva-contagios-muertes-coronavirus-espana-dia-dia/2010514.shtml\">&nbsp;|</a>&nbsp;<a href=\"https://www.rtve.es/noticias/20210921/ocupacion-camas-covid-19-hospitales-espanoles/2042349.shtml\">Hospitales y UCI</a></li>\n\t<li><a href=\"https://www.rtve.es/noticias/20211001/campana-vacunacion-espana/2062499.shtml\">Vacunas en Espa&ntilde;a</a>&nbsp;|&nbsp;<a href=\"https://www.rtve.es/noticias/20211001/mapa-confinamientos-espana-coronavirus-restricciones/2041269.shtml\">Gu&iacute;a de restricciones</a>&nbsp;|&nbsp;<a href=\"https://www.rtve.es/noticias/20211001/mapa-mundial-del-coronavirus/1998143.shtml\">Mapa mundial&#8203;</a>&nbsp;|&nbsp;<a href=\"https://www.rtve.es/lab/vacunacion-espana-coronavirus/\">Especial: La gran vacunaci&oacute;n</a></li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>Sanidad ha notificado 2.303 contagios de COVID-19 y 57 muertes en las &uacute;ltimas 24 horas. La incidencia del coronavirus en Espa&ntilde;a sigue bajando, aunque a menor velocidad:&nbsp;<strong>se detectan 50,96&nbsp;casos de COVID-19&nbsp;</strong>por cada 100.000 habitantes.</p>\n\n<p>La campa&ntilde;a de vacunaci&oacute;n avanza a buen ritmo, m&aacute;s de 36,7 millones de personas tienen la pauta completa (77,5 % de la poblaci&oacute;n espa&ntilde;ola), y m&aacute;s de 37,7 millones han recibido al menos una dosis (79,5 % de los residentes en Espa&ntilde;a).</p>\n\n<p>La Agencia Europea de Medicamentos (EMA) recomienda&nbsp;una&nbsp;<strong>tercera dosis de la vacuna para personas inmunodeprimidas</strong>&nbsp;y una dosis adicional de refuerzo para la poblaci&oacute;n general. En la&nbsp;<strong>Comisi&oacute;n de Salud P&uacute;blica,&nbsp;</strong>donde se re&uacute;nen las comunidades aut&oacute;nomas con el Ministerio de Sanidad, Madrid y Galicia votaron en contra de las inyecciones extra por falta de suficiente evidencia cient&iacute;fica, pero la propuesta sali&oacute; adelante.</p>\n\n<p>As&iacute; te hemos contado la actualidad sobre la pandemia de coronavirus:</p>\n\n<p>@@MINUTOAMINUTO idevent=27081 vista=TODO@@</p>\n\n<p></p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "CRISTINA PÉREZ",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Noticias/Especiales/Coronavirus",
        "mainCategoryLang": "Noticias/Especiales/Coronavirus",
        "otherTopicsName": [
          "Tags Libres/Epidemias",
          "Tags Libres/Enfermedades infecciosas",
          "Tags Libres/Vacunas",
          "Tags Libres/Virus",
          "Noticias/España"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2183060/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2183060/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2183060/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2183060/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2183060/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2183060/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2183060/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2183060/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2183060/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2183060/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2183060/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2183060/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2183060/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2183060/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2183060/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Información y actualidad",
            "generoInfUid": "GE_INFOR",
            "generoId": "136528",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "Coronavirus España, hoy | España roza el riesgo bajo de contagios en el que ya se encuentran diez CC.AA"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2182920",
        "htmlUrl": "https://www.rtve.es/noticias/20211006/turquia-ultimo-pais-ratificar-acuerdo-climatico-paris/2182920.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2182920/",
        "id": "2182920",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/1418",
        "popularity": "15.2866",
        "popHistoric": "15.2866",
        "numVisits": "56",
        "publicationDate": "06-10-2021 21:59:00",
        "expirationDate": null,
        "modificationDate": "06-10-2021 22:28:34",
        "publicationDateTimestamp": 1633550340000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2182920/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/turquia-ultimo-pais-ratificar-acuerdo-climatico-paris/1633550437774.jpg",
        "imageSEO": "https://img2.rtve.es/n/turquia-ultimo-pais-ratificar-acuerdo-climatico-paris_2182920.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": null,
        "anteTitleUrl": null,
        "longTitle": "Turquía, el último país en ratificar el acuerdo climático de París",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li>El estado asegura que lo implantar&aacute; siempre que no&nbsp;&quot;perjudique a su econom&iacute;a&quot;</li>\n\t<li>El presidente, Tayyip Erdogan, anunci&oacute; su compromiso durante la cumbre de la ONU</li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>El Parlamento de Turqu&iacute;a ha ratificado<a href=\"https://www.rtve.es/noticias/20151213/planeta-tierra-vuelve-sonreir-tras-acuerdo-paris/1272721.shtml\">&nbsp;el&nbsp;</a><strong><a href=\"https://www.rtve.es/noticias/20151213/planeta-tierra-vuelve-sonreir-tras-acuerdo-paris/1272721.shtml\">Acuerdo de Par&iacute;s</a>&nbsp;</strong>este mi&eacute;rcoles, lo que lo convierte en el &uacute;ltimo pa&iacute;s del G20&nbsp;en hacerlo. Despu&eacute;s de esperar durante a&ntilde;os porque consideraban que era un acuerdo injusto, finalmente se han sumado al pacto contra el cambio clim&aacute;tico</p>\n\n<p>Turqu&iacute;a, que es signataria del acuerdo de Par&iacute;s desde abril de 2016, todav&iacute;a no lo hab&iacute;a formalizado. Desde Ankara alegaban que no deb&iacute;an ser considerados como&nbsp;<strong>un pa&iacute;s desarrollado</strong>, ya que, al ser as&iacute;, tendr&iacute;an una mayor responsabilidad y Turqu&iacute;a es&nbsp;hist&oacute;ricamente responsable de una proporci&oacute;n muy peque&ntilde;a de emisiones de carbono.</p>\n\n<p>@@NOTICIA[1272721, IMAGEN]</p>\n\n<p>El pa&iacute;s ya hab&iacute;a anunciado que se sumar&iacute;a al acuerdo en&nbsp;Estados Unidos&nbsp;<a href=\"https://www.rtve.es/noticias/20210921/biden-promete-nueva-era-diplomacia-tras-retirada-afganistan/2173009.shtml\">durante la&nbsp;Asamblea General de Naciones Unidas</a>. Sin embargo, el presidente Tayyip Erdogan asegur&oacute; que los&nbsp;pa&iacute;ses que tienen una&nbsp;<strong>&quot;responsabilidad hist&oacute;rica&quot;&nbsp;</strong>&#8203;&#8203;en el cambio clim&aacute;tico deber&iacute;an hacer un&nbsp;mayor esfuerzo.</p>\n\n<p>&quot;Quien haya causado el mayor da&ntilde;o a la naturaleza, a nuestro aire, a nuestra agua, a nuestro suelo; quien explot&oacute; salvajemente los recursos naturales debe hacer<strong>&nbsp;mayor contribuci&oacute;n a la lucha contra el cambio clim&aacute;tico &quot;</strong>,dijo.</p>\n\n<p>@@NOTICIA[1988641, IMAGEN]</p>\n\n<p>La Convenci&oacute;n de las Naciones Unidas sobre el Cambio Clim&aacute;tico actualmente incluye a Turqu&iacute;a en el grupo del Anexo I, por lo que entra en el grupo de los pa&iacute;ses industrializados. No obstante, desde&nbsp;el Parlamento mantienen que firman el&nbsp;acuerdo como pa&iacute;s en desarrollo y lo implementaran siempre que no&nbsp;<strong>&quot;perjudique a su econom&iacute;a y al desarrollo social&quot;.</strong></p>\n\n<p>Turqu&iacute;a ha&nbsp;enviado una propuesta a las Naciones Unidas para que se les elimine de la lista de pa&iacute;ses desarrollados. De ser as&iacute;, podr&iacute;an beneficiarse de inversiones, seguros y transferencia de tecnolog&iacute;a que forman parte del convenio.&nbsp;</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "RTVE.es/AGENCIAS",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Noticias/Mundo/Europa/Turquía",
        "mainCategoryLang": "Noticias/Mundo/Europa/Turquía",
        "otherTopicsName": [
          "Tags Libres/Cambio climático",
          "Noticias/Mundo/Europa/Turquía",
          "Tags Libres/Acuerdo de París"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2182920/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2182920/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2182920/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2182920/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2182920/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2182920/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2182920/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2182920/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2182920/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2182920/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2182920/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2182920/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2182920/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2182920/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2182920/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Información y actualidad",
            "generoInfUid": "GE_INFOR",
            "generoId": "136528",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "Turquía, el último país en ratificar el acuerdo climático de París"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2179240",
        "htmlUrl": "https://www.rtve.es/television/20211006/miguel-gila-guerra-soldado-lazos-sangre/2179240.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2179240/",
        "id": "2179240",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/128571",
        "popularity": "21.3769",
        "popHistoric": "21.3769",
        "numVisits": "147",
        "publicationDate": "06-10-2021 21:58:00",
        "expirationDate": null,
        "modificationDate": "06-10-2021 21:23:40",
        "publicationDateTimestamp": 1633550280000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2179240/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/lazos-sangre-gila-artista-polivalente/1633342421775.jpg",
        "imageSEO": "https://img2.rtve.es/n/miguel-gila-guerra-soldado-lazos-sangre_2179240.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": "Lazos de sangre",
        "anteTitleUrl": null,
        "longTitle": "Gila y la guerra, ¿por qué el soldado era su mejor personaje?",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<p><span class=\"hddn\"><strong>Noticia</strong>&nbsp;<a href=\"https://www.rtve.es/play/videos/lazos-de-sangre/\"><em>Lazos de sangre</em></a>&nbsp;</span></p>\n\n<ul>\n\t<li>Miguel Gila fue&#160;<a href=\"https://www.rtve.es/television/20211006/gila-arruinado-muerte-entierro-lazos-sangre/2180560.shtml\">un gran genio que muri&oacute; arruinado</a></li>\n\t<li>Disfruta del&nbsp;<a href=\"https://www.rtve.es/play/videos/como-nos-reimos/como-reimos-gila/5070085/\">programa que le dedicaron en &#39;C&oacute;mo nos re&iacute;mos&#39;</a>&nbsp;</li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>Es imposible que hayas escuchado hablar de Miguel Gila y no de su personaje m&aacute;s famoso:&nbsp;<strong>el soldado de guerra</strong>. Fue su primer n&uacute;mero humor&iacute;sitico y le vali&oacute; muchos aplausos y reconocimientos como hemos visto en el&nbsp;<a href=\"https://www.rtve.es/play/videos/lazos-de-sangre/miguel-gila/6113092/\"><strong>documental de &#39;Lazos de sangre&#39;</strong></a>. Un trabajo fruto de una de las etapas m&aacute;s dif&iacute;ciles de su vida, y es que el propio Gila estuvo en la Guerra Civil Espa&ntilde;ola y tiene una historia que merece la pena contar.</p>\n\n<h2 class=\"ladillo\">Un humor que conquistaba en los dos bandos</h2>\n\n<p>Tras el estallido de la Guerra Civil, Gila se alist&oacute; en el bando republicano, se fue a la guerra cuando acababa de cumplir 17 a&ntilde;os y sali&oacute; de la c&aacute;rcel&nbsp;con 27. Diez a&ntilde;os duros que marcaron su vida para siempre y le inspiraron para crear: el soldado. Un personaje que le ayudar&iacute;a a cosechar a&ntilde;os y a&ntilde;os de &eacute;xitos y con el que pod&iacute;a hacer una&nbsp;<strong>cr&iacute;tica s&uacute;til a la guerra&nbsp;</strong>como cuenta el pol&iacute;tico Joaqu&iacute;n Leguina en el documental. &laquo;Odiaba la guerra, pero triunf&oacute; con el tema de la guerra porque ridiculizaba la guerra&raquo;, cuenta tambi&eacute;n su hijo Miguel Gila, fruto de su relaci&oacute;n con Carmen Visuerte, que no ha dudado en hablarnos de aquellos duros a&ntilde;os en la vida de su padre.</p>\n\n<p>Una escena en la que todos hemos imaginado una trinchera en nuestra mente e incluso al enemigo. Una verdadera obra de arte con la que fue&nbsp;<strong>capaz de unir a los dos bandos&nbsp;</strong>que hab&iacute;an luchado en la guerra, y sino que se lo digan a&nbsp;<strong>Carmen Polo, la mujer del dictador Francisco Franco</strong>. La esposa del dictador era una verdadera&nbsp;<strong>fan&aacute;tica del humorista</strong>&nbsp;y el matrimonio le invitaba siempre a su fiesta de cumplea&ntilde;os para hacerle&nbsp;re&iacute;r. Una aut&eacute;ntica virtud, ya que &eacute;l, como ya hemos mencionado, militaba en el bando contrario.&nbsp;</p>\n\n<h2 class=\"ladillo\">Su an&eacute;cdota m&aacute;s conocida</h2>\n\n<p>Gila nunca escondi&oacute; ni sus inclinaciones pol&iacute;ticas ni su paso por la guerra, y la historia de &quot;su fusilamiento&quot;, es ya una historia&nbsp;conocida por todos y que nos cuenta Carlos Latre en este documental. El bando enemigo estuvo a punto de fusilarle, de hecho lo intentaron, pero seg&uacute;n el humurista estaban &quot;tan borrachos&quot; que fallaron, &eacute;l&nbsp;<strong>se hizo el muerto y consigui&oacute; escapar</strong>.&nbsp;Pero no solo eso, la periodista Carmen Ro, tambi&eacute;n aporta luz a esta historia y cuenta c&oacute;mo se salv&oacute; a &eacute;l y a un compa&ntilde;ero, al que port&oacute; a hombros durante&nbsp;18&nbsp;kil&oacute;metros. Una historia que muchos no se creen, pero de la que Miguel, su hijo, no duda ni un instante.&nbsp;</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "RTVE.es",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Televisión/Programas de TVE/Moda, famosos y tendencias/Noticias de Moda, famosos y tendencias",
        "mainCategoryLang": "Televisión/Programas de TVE/Moda, famosos y tendencias/Noticias de Moda, famosos y tendencias",
        "otherTopicsName": [
          "Tags Libres/Especial Noticias/Noticias Lazos de sangre"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2179240/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2179240/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2179240/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2179240/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2179240/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2179240/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2179240/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2179240/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2179240/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2179240/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2179240/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2179240/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2179240/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2179240/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2179240/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Moda, famosos y tendencias",
            "generoInfUid": "GE_MOFAT",
            "generoId": "136615",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "Gila y la guerra, ¿por qué el soldado era su mejor personaje?"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2182860",
        "htmlUrl": "https://www.rtve.es/noticias/20211006/volcan-palma-binter-canaryfly-anulan-vuelos/2182860.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2182860/",
        "id": "2182860",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/141190",
        "popularity": "28.1273",
        "popHistoric": "28.1273",
        "numVisits": "423",
        "publicationDate": "06-10-2021 21:33:00",
        "expirationDate": null,
        "modificationDate": "06-10-2021 22:15:33",
        "publicationDateTimestamp": 1633548780000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2182860/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/erupcion-vista-desde-paso/1633549469555.jpg",
        "imageSEO": "https://img2.rtve.es/n/volcan-palma-binter-canaryfly-anulan-vuelos_2182860.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": null,
        "anteTitleUrl": null,
        "longTitle": "Binter y Canaryfly anulan sus vuelos con La Palma por el avance de la nube volcánica",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li>Ninguna otra aerol&iacute;nea se ha pronunciado y el resto de vuelos en el archipi&eacute;lago seguir&aacute; desarroll&aacute;ndose con normalidad</li>\n\t<li>Los expertos confirmaron la aparici&oacute;n de una<strong>&nbsp;</strong>nueva fisura &quot;inactiva&quot;&nbsp;a 100 metros del cr&aacute;ter</li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>Los vientos de componente suroeste direcci&oacute;n noreste&nbsp;<strong>han empeorado las condiciones de visibilidad del aeropuerto de Santa Cruz de La Palma</strong>&nbsp;hasta el punto que las aerol&iacute;neas Binter y Canaryfly han decidido suspender los vuelos con origen y llegada en la isla<strong>&nbsp;programados para el jueves 7 de octubre</strong>.</p>\n\n<p>La nube de cenizas y polvo que emana del volc&aacute;n de Cumbre Vieja se ha trasladado durante&nbsp;<a href=\"https://www.rtve.es/noticias/20211006/erupcion-volcan-palma-ultima-hora/2181620.shtml\">la tarde del mi&eacute;rcoles</a>&nbsp;a la zona este de La Palma, empeorando las condiciones de visibilidad en el aer&oacute;dromo.&nbsp;<strong>Un avi&oacute;n de Binter tuvo que dar la vuelta hacia Tenerife</strong>&nbsp;cuando estaba a punto de aterrizar en la &#39;isla bonita&#39;. Ese ha sido el &uacute;nico incidente en una jornada en la que el resto de operaciones a&eacute;reas programadas en la isla se han realizado sin mayores problemas.</p>\n\n<p>Sin embargo, la previsi&oacute;n pesimista&nbsp;de las pr&oacute;ximas horas ha llevado a Binter y Canaryfly a anular sus conexiones con la isla al menos para este jueves. El resto de la programaci&oacute;n de vuelos en el archipi&eacute;lago seguir&aacute; desarroll&aacute;ndose con normalidad y&nbsp;<strong>ninguna otra aerol&iacute;nea se ha pronunciado sobre su operatividad en La Palma</strong>.</p>\n\n<p>@@MEDIA[6127543,v]</p>\n\n<h2 class=\"ladillo\">El ministro Luis&nbsp;Planas aplaza su viaje a La Palma</h2>\n\n<p>El ministro de Agricultura, Pesca y Alimentaci&oacute;n, Luis Planas, ha aplazado el viaje que ten&iacute;a programado este jueves a La Palma como consecuencia de las nubes de ceniza desprendidas de la actividad volc&aacute;nica, pero mantendr&aacute; reuniones telem&aacute;ticas con representantes del sector agroalimentario.</p>\n\n<p>El ministro ten&iacute;a previsto reunirse en la isla con los representantes del sector del pl&aacute;tano, principal sector impactado por la erupci&oacute;n, as&iacute; como con los representantes de otros sectores agroalimentarios afectados por el volc&aacute;n.</p>\n\n<p>Seg&uacute;n la agenda emitida por el Ministerio, Planas mantendr&aacute; una reuni&oacute;n por videoconferencia con la consejera de Agricultura, Ganader&iacute;a y Pesca de Canarias, Alicia Vanoostende, y con representantes del sector pesquero de La Palma afectado por la erupci&oacute;n del volc&aacute;n.</p>\n\n<p>@@MEDIA[6117428,a]</p>\n\n<p>Este mi&eacute;rcoles, el director t&eacute;cnico del&nbsp;Plan de Emergencias Volc&aacute;nicas de Canarias&nbsp;(Pevolca), Miguel &Aacute;ngel Morcuende, ha informado que de la superficie&nbsp;afectada por la lava - 421,93 hect&aacute;reas-:&nbsp;<strong>93,4&nbsp;son de cultivos agr&iacute;colas</strong>, de las cuales 35,6 hect&aacute;reas son plataneras, 32,9 vi&ntilde;edos, 6,7 aguacateras&nbsp;y el resto otros cultivos.</p>\n\n<h2 class=\"ladillo\">Nueva fisura y tubo volc&aacute;nico</h2>\n\n<p>En la ma&ntilde;ana del mi&eacute;rcoles, los expertos confirmaron la aparici&oacute;n de una<strong>&nbsp;nueva fisura &quot;inactiva&quot;</strong>&nbsp;<a href=\"https://www.rtve.es/play/videos/telediario-matinal/palma-volcan-tiene-nueva-fisura-no-emana-lava-pero-si-gases/6127031/\">a 100 metros del cr&aacute;ter</a>&nbsp;en su vertiente noroeste&nbsp;que&nbsp;<strong>no emana lava&nbsp;pero s&iacute; gases</strong>.</p>\n\n<p>@@MEDIA[6127741,v]</p>\n\n<p>Los vulcan&oacute;logos desplazados a la zona del volc&aacute;n tambi&eacute;n han&nbsp;indicado que&nbsp;<strong>la erupci&oacute;n mantiene una &quot;situaci&oacute;n estable&quot;</strong>, con &quot;un comportamiento del volc&aacute;n de variables constantes&quot;, que al &quot;continuar su camino por donde lo est&aacute; haciendo, ya no hace m&aacute;s da&ntilde;o a la poblaci&oacute;n&quot;, indic&oacute; Morcuende.</p>\n\n<p>Tambi&eacute;n especific&oacute; la existencia de&nbsp;<a href=\"https://www.rtve.es/noticias/20211006/asi-son-tubos-volcanicos-pueden-ayudar-desalojar-lava-palma/2182101.shtml\">un tubo l&aacute;vico o volc&aacute;nico en la colada principal</a>,&nbsp;una especie de tuber&iacute;a producida al enfriarse la parte superior de la lengua. La lava circula por su interior de forma fluida, un fen&oacute;meno com&uacute;n en las islas canarias y que seg&uacute;n Morcuende podr&iacute;a ser beneficioso para evitar que aumenten a lo ancho las hect&aacute;reas arrasadas por el material volc&aacute;nico.</p>\n\n<p>@@MEDIA[6127742,v]</p>\n\n<p>En cuanto a la fajana -el delta l&aacute;vico en el mar- en la &uacute;ltima jornada ha ralentizado su crecimiento en solo dos hect&aacute;reas, 38 en total, y una profundidad de 250 metros.</p>\n\n<p>@@MEDIA[6127769,v]</p>\n\n<p>Las<a href=\"https://www.rtve.es/noticias/20211005/expertos-no-descartan-nuevas-bocas-volcan/2180261.shtml\">&nbsp;dos desaladoras port&aacute;tiles</a>&nbsp;que se destinar&aacute;n al riego de los cultivos en el sur de la isla, tras romperse por la erupci&oacute;n las dos tuber&iacute;as que lo suministraban,&nbsp;<strong>ya&nbsp;se encuentran en Puerto Naos</strong>, donde&nbsp;podr&aacute;n comenzar a funcionar en un plazo de dos semanas.</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "RTVE.es",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Noticias/Especiales/Erupción volcánica en La Palma",
        "mainCategoryLang": "Noticias/Especiales/Erupción volcánica en La Palma",
        "otherTopicsName": [
          "Tags Libres/Aeropuertos",
          "Noticias/España/Canarias/Santa Cruz de Tenerife/La Palma",
          "Tags Libres/Volcanes",
          "Tags Libres/Nube volcánica",
          "Tags Libres/Transportes"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2182860/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2182860/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2182860/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2182860/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2182860/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2182860/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2182860/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2182860/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2182860/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2182860/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2182860/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2182860/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2182860/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2182860/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2182860/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Información y actualidad",
            "generoInfUid": "GE_INFOR",
            "generoId": "136528",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "Binter y Canaryfly anulan sus vuelos con La Palma por el avance de la nube volcánica"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2180382",
        "htmlUrl": "https://www.rtve.es/television/20211006/miguel-gila-boda-dinero-lazos-sangre/2180382.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2180382/",
        "id": "2180382",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/128571",
        "popularity": "28.494",
        "popHistoric": "28.494",
        "numVisits": "451",
        "publicationDate": "06-10-2021 21:30:00",
        "expirationDate": null,
        "modificationDate": "06-10-2021 21:21:11",
        "publicationDateTimestamp": 1633548600000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2180382/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/lazos-sangre-amores-gila/1633347238957.jpg",
        "imageSEO": "https://img2.rtve.es/n/miguel-gila-boda-dinero-lazos-sangre_2180382.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": "Lazos de sangre",
        "anteTitleUrl": null,
        "longTitle": "Gila se casó por dinero y no le importaba reconocerlo",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<p><span class=\"hddn\"><strong>Noticia</strong>&nbsp;<a href=\"https://www.rtve.es/play/videos/lazos-de-sangre/\"><em>Lazos de sangre</em></a>&nbsp;</span></p>\n\n<ul>\n\t<li>Se cas&oacute; con su casera para sobrevivir a la pobreza tras la Guerra Civil</li>\n\t<li>Despu&eacute;s la abandon&oacute; para irse con una bailaora de flamenco a la que tambi&eacute;n abandon&oacute;</li>\n\t<li>Disfruta del&nbsp;<a href=\"https://www.rtve.es/play/videos/como-nos-reimos/como-reimos-gila/5070085/\">programa que le dedic&oacute; &#39;C&oacute;mo nos re&iacute;mos&#39;</a></li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>Esta semana el&#160;<strong><a href=\"https://www.rtve.es/play/videos/lazos-de-sangre/miguel-gila/6113092/\">documental de&nbsp;&#39;Lazos de sangre&#39;</a></strong>&#160;se ha adentrado en la vida de uno de los&nbsp;<strong>grandes genios del humor, Miguel Gila</strong>. Un hombre con un talento extraordinario para hacer re&iacute;r a los dem&aacute;s, pero poco responsables. El problema de Gila siempre fue el dinero, primero porque&nbsp;<strong>volvi&oacute; de la Guerra Civil</strong>&nbsp;despu&eacute;s de estar varios a&ntilde;os en prisi&oacute;n y no ten&iacute;a nada en la cartera, despu&eacute;s porque&#160;<a href=\"https://www.rtve.es/television/20211006/gila-arruinado-muerte-entierro-lazos-sangre/2180560.shtml\">no supo gestionar su patrimonio y muri&oacute; arruinado</a>. Por suerte siempre tuvo alguien que le ayud&oacute; a sobrevivir, en la primera ocasi&oacute;n su &aacute;ngel de la guarda fue Ricarda.&nbsp;</p>\n\n<p>Un joven Gila volvi&oacute; de la guerra y se hosped&oacute; en una pensi&oacute;n en Zaragoza buscando trabajo, all&iacute; conoci&oacute; a&nbsp;<strong>Ricarda, la hija de la patrona,</strong>&nbsp;y viendo que &quot;era un buen partido&quot;, decidi&oacute; casarse con ella. Gila nunca tuvo reparos en reconocerlo, se cas&oacute; por dinero, ella&nbsp;<strong>ten&iacute;a adjudicada una pensi&oacute;n</strong>&nbsp;bastante buena y &eacute;l necesitaba alguien que lo mantuviera. Es raro ver esta f&oacute;rmula, pero Gila no quiso esconder la verdadera naturaleza de la relaci&oacute;n. &Eacute;l nunca quiso a Ricarda, solo buscaba algo que comer, un sitio donde dormir y como mucho, un poco de cari&ntilde;o, pero sobre todo era una&nbsp;<strong>cuesti&oacute;n de supervivencia</strong>.&nbsp;</p>\n\n<h2 class=\"ladillo\">La ilusi&oacute;n de su vida: su hijo</h2>\n\n<p>Su relaci&oacute;n dur&oacute; cuatro a&ntilde;os y no tuvieron hijos, al contrario que con&nbsp;<strong>Carmen Visuerte</strong>. Era bailaora de flamenco y Gila se qued&oacute; prendado de ella en cuanto la vio. A&uacute;n estaba casado con Ricarda, a la que hab&iacute;a dejado en Zaragoza para irse a Madrid a triunfar como humorista, cuando la conoci&oacute;, pero en aquella &eacute;poca no importaba. Vivieron su amor con locura y&nbsp;<strong>tuvieron a su primer hijo, Miguel Gila</strong>, que, aunque hab&iacute;a nacido fuera del matrimonio, pudo llevar el apellido de su padre gracias a la insistencia del conocido dibujante de vi&ntilde;etas.</p>\n\n<p>No fue solo la insistencia, tambi&eacute;n&nbsp;<strong>una buena donaci&oacute;n a la iglesia (2 millones de pesetas de la &eacute;poca pag&oacute; para que lo bautizaran)</strong>, pero a Gila no le importaba, quer&iacute;a que su hijo llevase sus apellidos y fuese completamente suyo y eso no ten&iacute;a precio. Con su segunda hija el procedimiento fue muy diferente, cuando ella naci&oacute;, &eacute;l se hab&iacute;a ido a M&eacute;xico a grabar, y desde la distancia todo se complic&oacute;. Nadie sabe los verdaderos motivos, si fue por miedo o desinter&eacute;s, pero Carmen<strong>&nbsp;<a href=\"https://www.rtve.es/television/20211006/miguel-gila-padre-ausente-hija-lazos-sangre/2179120.shtml\">nunca fue reconocida por Gila como su hija</a></strong>&nbsp;a pesar de ser la m&aacute;s querida. Algo que saben tanto Carmen como Miguel, el primog&eacute;nito:&nbsp;&laquo;Mi hermana era su favorita&raquo;.</p>\n\n<p>Aquell&oacute; caus&oacute; un profundo dolor a Carmen que vivi&oacute; con la sensaci&oacute;n de rechazo toda su vida, hasta el momento en el que&nbsp;<strong>decidi&oacute; poner una demanda de paternidad</strong>. Quiz&aacute;s lo hizo en el peor momento porque tan solo unos meses despu&eacute;s su padre, Gila, falleci&oacute;, pero ahora tiene la conciencia tranquila: la justicia le dio la raz&oacute;n y puede&nbsp;<strong>llevar con orgullo el apellido de su padre</strong>.&nbsp;</p>\n\n<h2 class=\"ladillo\">La mujer que volvi&oacute; loco a Gila y le hizo dejar Espa&ntilde;a</h2>\n\n<p>Pero ellos no fueron los &uacute;nicos hijos del humorista, Gila tuvo una tercera hija con la que consider&oacute;&nbsp;<strong>el gran amor de su vida, Mar&iacute;a Dolores Cabo</strong>. Una mujer de la que se enamor&oacute; cuando a&uacute;n estaba con Carmen y cuando segu&iacute;a casado con Ricarda. Por eso, Ricarda, cansada de los amor&iacute;os de su esposo, decidi&oacute; denunciarle por adulterio. Gracias a un chivatazo, Gila consigui&oacute;<strong>&nbsp;huir con Mar&iacute;a Dolores hasta M&eacute;xico</strong>, donde vivieron m&aacute;s de 35 a&ntilde;os y&nbsp;<strong>se casaron tres veces</strong>. Un amor que resisti&oacute; el paso del tiempo y las dificultades, y que<strong>&nbsp;trajo al mundo a Malena</strong>, la hija de que de verdad pudo disfrutarle como padre, ya que por primera vez Gila se implic&oacute; en la educaci&oacute;n de un hijo.</p>\n\n<p>Tres relaciones, que no amores, que marcaron la vida de Gila. La primera por inter&eacute;s, la segunda como amor calmado y la tercera una desmedida pasi&oacute;n que acab&oacute; derribando tab&uacute;es y el paso del tiempo.&nbsp;</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "RTVE.es",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Televisión/Programas de TVE/Moda, famosos y tendencias/Noticias de Moda, famosos y tendencias",
        "mainCategoryLang": "Televisión/Programas de TVE/Moda, famosos y tendencias/Noticias de Moda, famosos y tendencias",
        "otherTopicsName": [
          "Tags Libres/Especial Noticias/Noticias Lazos de sangre"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2180382/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2180382/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2180382/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2180382/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2180382/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2180382/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2180382/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2180382/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2180382/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2180382/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2180382/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2180382/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2180382/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2180382/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2180382/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Moda, famosos y tendencias",
            "generoInfUid": "GE_MOFAT",
            "generoId": "136615",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "Gila se casó por dinero y no le importaba reconocerlo"
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2182100",
        "htmlUrl": "https://www.rtve.es/television/20211006/dani-martin-nuevo-tema-canto-del-loco/2182100.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2182100/",
        "id": "2182100",
        "language": "es",
        "shortTitle": "Dani Martín y la letra de 'No, no vuelve': \"Me arruiné con tanta pose\"",
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/129770",
        "popularity": "26.4757",
        "popHistoric": "26.4757",
        "numVisits": "326",
        "publicationDate": "06-10-2021 21:25:00",
        "expirationDate": null,
        "modificationDate": "06-10-2021 21:32:27",
        "publicationDateTimestamp": 1633548300000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2182100/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/dani-martin-se-confiesa-no-no-vuelve/1633547834489.jpg",
        "imageSEO": "https://img2.rtve.es/n/dani-martin-nuevo-tema-canto-del-loco_2182100.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": "La verdad sobre El Canto del Loco",
        "anteTitleUrl": null,
        "longTitle": "Dani Martín se confiesa en 'No, no vuelve': \"Me arruiné con tanta pose\"",
        "frontTitle": "Dani Martín y la letra de 'No, no vuelve': \"Me arruiné con tanta pose\"",
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li><strong>Dani Mart&iacute;n</strong>&nbsp;estrena su&nbsp;<strong>canci&oacute;n in&eacute;dita</strong>, con una potente letra sobre su historia con<strong>&nbsp;El Canto del Loco&nbsp;</strong></li>\n\t<li>El grupo fue el&nbsp;<a href=\"https://www.rtve.es/television/20211004/memes-caida-whatsapp-facebook-instagram-nostalgia-canto-loco-tuenti/2179860.shtml\">protagonista de los memes sobre la ca&iacute;da de Whatsapp e Instagram</a>&nbsp;pero&nbsp;<strong>&quot;No, no vuelve&quot;</strong></li>\n\t<li><a href=\"https://www.rtve.es/television/20211006/dani-martin-canto-loco-integrantes-david-otero-chema-ruiz-ivan-ganchegui/2181942.shtml\" target=\"_blank\"><strong>&iquest;Qu&eacute; fue de los integrantes de El Canto del Loco?</strong>&nbsp;Les seguimos la pista</a></li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p><strong>&quot;Llega el ego, la envidia y nos parte en dos&quot;</strong>, dice la potent&iacute;sima letra de&nbsp;<strong>&#39;No, no vuelve</strong>, el homenaje de Dani Mart&iacute;n a El Canto del Loco. Una canci&oacute;n dura que suena al inconfundible sello del cantante, indisociable del<strong>&nbsp;recuerdo de la banda que lo lanz&oacute; a la fama</strong>. Tras una&nbsp;<strong>estrategia de marketing&nbsp;</strong>que ha funcionado de maravilla, en la que&nbsp;<a href=\"https://www.rtve.es/playz/20211004/volvera-canto-del-loco-6-octubre-sabremos/2178940.shtml\">Dani Mart&iacute;n y su equipo daban a entender que pod&iacute;amos estar ante la vuelta de El Canto del Loco</a>, se descubr&iacute;a la verdad:<strong>&nbsp;&quot;No, no vuelve&quot;</strong>.</p>\n\n<p>&ldquo;<strong>As&iacute; es c&oacute;mo se llama el homenaje que le he hecho a la banda de mi vida. He regrabado 10 canciones de la historia d El&nbsp;Canto del Loco, y una in&eacute;dita</strong>&rdquo;, dec&iacute;a Dani Mart&iacute;n, que ya ha estrenado el videoclip de la canci&oacute;n, llena de referencias a la ilusi&oacute;n adolescente de formar un grupo, y dedicaba este mensaje a sus fans.&nbsp;</p>\n\n<h2 class=\"ladillo\">Una banda que naci&oacute; en el sal&oacute;n de sus padres</h2>\n\n<p>&quot;Durante 10 a&ntilde;os tuve una banda que ahora es vuestra. Desde que ECDL termin&oacute;, muchas veces, me han preguntado cu&aacute;ndo &iacute;bamos a volver.&nbsp;<strong>La vida pasa; las personas elegimos, crecemos, somos felices tambi&eacute;n en otros lugares</strong>, pero no significa que no queramos mantener vivo un recuerdo que ha hecho nuestro camino y que nos ha tra&iacute;do hasta el presente. Por eso es precioso ordenar las fotos, elegir las mejores, hacer el collage que te hace sonre&iacute;r y quedarte con lo bonito de lo vivido. El tiempo lo cura todo.&nbsp;<strong>Este es mi homenaje a aquellos a&ntilde;os</strong>. A Chema, David, Iv&aacute;n, Jandro, Nigel y a todos aquellos que formasteis parte de mi ilusi&oacute;n, de<strong>&nbsp;aquella que naci&oacute; en el sal&oacute;n de mis padres</strong>, EL CANTO DEL LOCO&quot;.</p>\n\n<p>El videoclip recrea estas situaciones, en las que unos j&oacute;venes forman el grupo de sus vidas. Dani Mart&iacute;n, mientras tanto, canta sobre algo muy diferente: el desencanto, el tedio y la &quot;pose&quot; que termin&oacute; adoptando durante los a&ntilde;os en que la banda se encontraba en lo m&aacute;s alto de los tops de nuestro pa&iacute;s, y las razones por las que El Canto del Loco se termin&oacute; separando. &quot;No, no vuelve&quot; es una constataci&oacute;n, un homenaje y una confesi&oacute;n.</p>\n<script async src=\"https://platform.twitter.com/widgets.js\" charset=\"utf-8\"></script>\n\n<p><iframe allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen=\"\" frameborder=\"0\" height=\"315\" src=\"https://www.youtube.com/embed/UOyu9dOf2u0\" title=\"YouTube video player\" width=\"560\"></iframe></p>\n\n<h2 class=\"ladillo\">As&iacute; es la letra de &#39;No, no vuelve&#39;</h2>\n\n<p><em>Unas &#39;All Star&#39;, un coraz&oacute;n<br />\nque pint&eacute; en un banco con la pasi&oacute;n&nbsp;<br />\ndel que cree que todo es para siempre&nbsp;<br />\nEl olor del &eacute;xito alrededor&nbsp;<br />\ny sentirme el l&iacute;der de la emoci&oacute;n&nbsp;<br />\ncon aquel discurso adolescente.&nbsp;</em></p>\n\n<p><em>Yo tuve una banda que ahora es vuestra,&nbsp;<br />\ncanciones que te atrapan, que recuerdan&nbsp;<br />\nque hoy me recuerdan.</em></p>\n\n<p><em>Me cans&eacute; de o&iacute;r mi nombre<br />\nMe aburr&iacute; del falso amor<br />\nDel vac&iacute;o que dej&oacute;<br />\nMe arruin&eacute; con tanta pose<br />\nY solo queda la canci&oacute;n</em></p>\n\n<p><em>El dolor de tripas, la decepci&oacute;n<br />\nVino una tormenta que se llev&oacute;<br />\nLa ilusi&oacute;n de golpe y cay&oacute; mi suerte</em></p>\n\n<p><em>Tanto ruido cambia la direcci&oacute;n<br />\nLlega el ego, la envidia y nos parte en dos<br />\nDesde entonces s&eacute; que esto no vuelve</em></p>\n\n<p><em>Yo tuve una banda que ahora es vuestra,&nbsp;<br />\ncanciones que te atrapan, que recuerdan<br />\nQue hoy me recuerdan</em></p>\n\n<p><em>Me cans&eacute; de o&iacute;r mi nombre<br />\nMe aburr&iacute; del falso amor<br />\nDel vac&iacute;o que dej&oacute;<br />\nMe arruin&eacute; con tanta pose<br />\nY solo queda la canci&oacute;n<br />\nHoy solo queda la canci&oacute;n</em></p>\n\n<p><em>No vuelve, no<br />\nNo vuelve, no<br />\nNo vuelve, no<br />\nNo vuelve, no<br />\nNo vuelve, no<br />\nNo vuelve, no</em></p>\n\n<p><em>Y s&oacute;lo queda la canci&oacute;n</em></p>\n\n<h2 class=\"ladillo\"><em>El Canto del Loco</em>, un fen&oacute;meno social</h2>\n\n<p>La banda fue todo un fen&oacute;meno social que marc&oacute; a toda una generaci&oacute;n de adolescentes que se atrev&iacute;an con cualquier locura para seguir de cerca a su grupo favorito. Lograban mover a una gran masa de seguidores incondicionales que llenaban cualquier sala y se desplazaban por toda Espa&ntilde;a para no perderse ni un solo concierto.&nbsp;<strong>A d&iacute;a de hoy la mayor&iacute;a de los&nbsp;<em>fans&nbsp;</em>ya han crecido, pero siguen teniendo muy presentes algunas de sus canciones como &lsquo;Zapatillas&rsquo;, &lsquo;Besos&rsquo; o &lsquo;Volver&aacute;&rsquo;</strong>; y pensar en un nuevo enfoque de estos temazos, de la mano del&nbsp;mism&iacute;simo Dani Mart&iacute;n, nos pone los pelos de punta.</p>\n\n<h2 class=\"ladillo\">&iquest;Por qu&eacute; triunfaron tanto?</h2>\n\n<p>Hay que poner en valor el &eacute;xito de<em>&nbsp;El Canto del Loco</em>&nbsp;ya que&nbsp;<strong>triunfaron en un momento en el que a&uacute;n no exist&iacute;an las redes sociales</strong>&nbsp;<strong>y ten&iacute;an una repercusi&oacute;n entre los adolescentes que no se hab&iacute;a visto antes</strong>. Consiguieron vender m&aacute;s de un mill&oacute;n de discos (que en aquel momento era una locura) y ganaron 3 Premios Ondas (2004, 2005 y 2008); 2 MTV Europe Music Awards (2003 y 2005) y &lsquo;reventaron&rsquo; los Premios de los 40 Principales en 2008 con la mejor canci&oacute;n, mejor grupo, mejor gira, mejor &aacute;lbum y mejor videoclip musical.</p>\n\n<p>@@NOTICIA[2181942,IMAGEN,FIRMA]</p>\n\n<p>La banda estaba formada por&nbsp;<strong>Dani Mart&iacute;n, David Otero, Iv&aacute;n Ganchegui, Chema Ruiz y Jandro Vel&aacute;zquez</strong>. Un grupo de chicos aparentemente normales que triunfaron precisamente por eso, por ser normales y acercarse a la realidad de los m&aacute;s j&oacute;venes que se sent&iacute;an muy identificados con ellos.</p>\n\n<p>@@FOTO[6127467]</p>\n\n<p>Los grandes referentes de la m&uacute;sica actual como&nbsp;<strong>C. Tangana, Rosal&iacute;a u Omar Montes hablan de limusinas, diamantes y dinero</strong>&nbsp;mientras que las letras de las canciones del<em>&nbsp;Canto del Loco</em>&nbsp;trataban temas cotidianos que les ocurr&iacute;an a los chicos y las chicas j&oacute;venes de los 2000. &ldquo;<strong>Quiero entrar en tu garito con zapatillas, que no me miren mal al pasar</strong>&rdquo; o &ldquo;<strong>Y dime por qu&eacute;, te has tirado tres horas en el espejo, pa&#39; ponerte guapo pa&#39; ligar</strong>&rdquo; fueron algunos de los versos que m&aacute;s gritaban los&nbsp;<em>fans&nbsp;</em>en sus conciertos y que, a d&iacute;a de hoy, despiertan una sensaci&oacute;n de nostalgia cuando los volvemos a escuchar en la radio.</p>\n\n<p>@@FOTO[6127478]</p>\n\n<p>Adem&aacute;s,&nbsp;<strong>a nivel est&eacute;tico tampoco llamaban la atenci&oacute;n como lo hacen los artistas a de hoy en d&iacute;a</strong>. Ahora parece que los artistas necesitan una est&eacute;tica atrevida, provocativa, llamativa y sobre todo, de marca (si es cara mejor que mejor). Sin embargo,&nbsp;<em>El Canto del Loco</em>&nbsp;consigui&oacute; llamar la atenci&oacute;n de los m&aacute;s j&oacute;venes con sus estilos casual.&nbsp;<strong>Acorde a su m&uacute;sica, vest&iacute;an con looks rockeros y un poco &lsquo;canallas&rsquo;, pero siempre dentro del marco de lo &lsquo;com&uacute;n&rsquo;</strong>.</p>\n\n<p>@@FOTO[6127466]</p>\n\n<p>Tambi&eacute;n destacaban sus canciones por el estilo propio&nbsp;de Dani Mart&iacute;n.&nbsp;<strong>Con una voz rasgada y siendo &eacute;l muy expresivo en sus conciertos y videoclips, lograba cautivar a todos sus seguidores</strong>. De hecho, hizo de su voz una marca, y a d&iacute;a de hoy es inconfundible cuando suena. Si lo comparamos con los fen&oacute;menos musicales de ahora,&nbsp;<strong>es pr&aacute;cticamente imposible encontrar alguna canci&oacute;n sin autotune&nbsp;</strong>y esto pone m&aacute;s en valor lo que hac&iacute;a el&nbsp;<em>Canto del Loco</em>&nbsp;en los 2000.</p>\n\n<p>@@FOTO[6127465]</p>\n\n<h2 class=\"ladillo\">De &iacute;dolo de adolescentes a una madurez serena</h2>\n\n<p><strong>Desde que se disolvi&oacute; el grupo en 2010, Dani Mart&iacute;n ha seguido con su carrera en solitario</strong>&nbsp;y hemos visto en sus canciones una evoluci&oacute;n art&iacute;stica y personal. Una evoluci&oacute;n en la que no se ha preocupado en caer mejor o peor, sino que se ha centrado en su yo interior. A principios de este mismo verano, Dani nos hablaba de su &uacute;ltimo disco &ldquo;<strong>Lo que me d&eacute; la gana</strong>&rdquo; y posiblemente nos daba alguna pista de lo que ha hecho ahora: &quot;<strong>Me queda hacer el mejor disco de mi vida. Me queda aprender un mont&oacute;n. Y, sobre todo, me queda ser feliz</strong>&rdquo;.</p>\n\n<p>@@MEDIA[5922624]</p>\n\n<p>En su camino hemos podido ver muchos cambios de&nbsp;<em>look</em>,&nbsp;pelo azul, rapado, tatuajes, camisetas con mensaje, o recoger premios como si estuviera en los conciertos: &ldquo;<strong>Con El Canto Del Loco recuerdo recoger un premio Ondas vestidos de skaters, porque &eacute;ramos as&iacute;. Con un pantal&oacute;n corto, unos calcetines altos, y unas All Star</strong>&rdquo;.</p>\n\n<p><a href=\"https://www.rtve.es/television/20210602/dani-martin-permiso-para-gana/2097059.shtml\" target=\"_blank\"><strong>As&iacute; es Dani Mart&iacute;n</strong></a>, que tras una carrera de 20 a&ntilde;os, se muestra siempre tal y como es y pretende volver a vivir sus inicios. Esta claro que nada volver&aacute; a ser como antes, pero&nbsp;<strong>ver de nuevo a Dani Mart&iacute;n relacionado con El Canto del Loco siempre ser&aacute; una buena noticia</strong>.</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "Santiago Pérez Payá",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Televisión/Programas de TVE/Moda, famosos y tendencias/Noticias de Moda, famosos y tendencias/Famosos",
        "mainCategoryLang": "Televisión/Programas de TVE/Moda, famosos y tendencias/Noticias de Moda, famosos y tendencias/Famosos",
        "otherTopicsName": [
          "Tags Libres/Música"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2182100/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2182100/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2182100/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2182100/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2182100/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2182100/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2182100/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2182100/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2182100/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2182100/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2182100/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2182100/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2182100/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2182100/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2182100/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Moda, famosos y tendencias",
            "generoInfUid": "GE_MOFAT",
            "generoId": "136615",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "Dani Martín y la letra de 'No, no vuelve': \"Me arruiné con tanta pose\""
      },
      {
        "uri": "http://www.rtve.es/api/noticias/2178884",
        "htmlUrl": "https://www.rtve.es/noticias/20211006/babi-yar-barranco-donde-nazis-mataron-34000-judios/2178884.shtml",
        "htmlShortUrl": "https://www.rtve.es/n/2178884/",
        "id": "2178884",
        "language": "es",
        "shortTitle": null,
        "mainCategoryRef": "http://www.rtve.es/api/tematicas/1419",
        "popularity": "22.5362",
        "popHistoric": "22.5362",
        "numVisits": "176",
        "publicationDate": "06-10-2021 21:18:00",
        "expirationDate": null,
        "modificationDate": "06-10-2021 21:30:03",
        "publicationDateTimestamp": 1633547880000,
        "breadCrumbRef": "http://www.rtve.es/api/noticias/2178884/breadcrumb",
        "image": "https://img2.rtve.es/imagenes/aniversario-masacre-babi-yar/1633330278460.jpg",
        "imageSEO": "https://img2.rtve.es/n/babi-yar-barranco-donde-nazis-mataron-34000-judios_2178884.png",
        "contentType": "noticia",
        "statistics": {
          "numComentarios": 0,
          "numCompartidas": 0
        },
        "contentInitDate": null,
        "contentEndDate": null,
        "anteTitle": "Ucrania",
        "anteTitleUrl": null,
        "longTitle": "Babi Yar, el barranco donde los nazis mataron a 34.000 judíos ",
        "frontTitle": null,
        "tabTitle": null,
        "ticker": {
          "tickerSports": false,
          "tickerNews": false
        },
        "essentialInfo": {
          "info": null,
          "photo": null
        },
        "summary": "<ul>\n\t<li>Hasta 1943, en este barranco cerca de Kiev fueron asesinadas 150.000 personas</li>\n\t<li>Los presidentes de Ucrania, Israel y Alemania homenajean a las v&iacute;ctimas</li>\n\t<li>La memoria del Holocausto en Europa del Este queda diluida con la de la dominaci&oacute;n sovi&eacute;tica</li>\n</ul>\n",
        "frontSummary": null,
        "text": "<p>Entre el 29 y el 30 de septiembre de 1941, durante la Segunda Guerra Mundial, los nazis mataron a tiros a casi&nbsp;<strong>34.000 jud&iacute;os ucranianos</strong>&nbsp;(hombres, mujeres y ni&ntilde;os) en&nbsp;<strong>Babi Yar</strong>&nbsp;(el &quot;barranco de la abuela&quot;, en ucraniano), un lugar situado en un bosque a las afueras de la capital de Ucrania, Kiev.</p>\n\n<p>Esta fue solo una de las matanzas que se produjeron en el lugar. Hasta que los alemanes se retiraron en&nbsp;1943,<strong>&nbsp;m&aacute;s de 150.000 personas fueron asesinadas en Babi Yar</strong>, la mayor parte de ellas jud&iacute;os, pero tambi&eacute;n gitanos, prisioneros de guerra sovi&eacute;ticos o polacos, comunistas, nacionalistas ucranianos y otros enemigos de la Alemania de Hitler.</p>\n\n<p>Ucrania celebr&oacute; el aniversario de la matanza la semana pasada, pero este mi&eacute;rcoles se ha inaugurado un memorial con la presencia de su presidente,&nbsp;Volod&iacute;mir Zelenski, y sus hom&oacute;logos de Alemania e&nbsp;Israel, Frank-Walter Steinmeier e&nbsp;Isaac Herzog.</p>\n\n<h2 class=\"ladillo\">&quot;Fueron a Babi Yar y nunca regresaron&quot;</h2>\n\n<p><strong>Polina Dudchenko</strong>, m&eacute;dica de 48 a&ntilde;os, es una de miles de residentes de Kiev cuyos familiares fueron asesinados en ese lugar: su abuelo, Noah Lifshitz; su t&iacute;o-abuelo, Mois&eacute;s; y su bisabuela, Sof&iacute;a.&nbsp;</p>\n\n<p>&quot;Los nazis les dijeron a todos los jud&iacute;os que vinieran a Babi Yar con sus documentos y pertenencias. Se rumoreaba que los enviar&iacute;an a trabajar a Alemania&quot;, ha explicado Dudchenko a Efe. &quot;Mi abuela comenz&oacute; a hacer la maleta, pero su esposo le dijo: &#39;qu&eacute;date en casa con nuestro hijo; mi hermano y yo iremos a ver qu&eacute; est&aacute; pasando&#39;.&nbsp;<strong>Fueron a Babi Yar con su madre y nunca regresaron</strong>&quot;.</p>\n\n<p>Los&nbsp;<strong>Einsatzgruppen</strong>&nbsp;(escuadrones de la muerte que actuaban a las &oacute;rdenes de&nbsp;las SS)&nbsp;conduc&iacute;an a ni&ntilde;os, mujeres y hombres de forma indiscriminada hasta el borde del barranco, donde eran ejecutados sistem&aacute;ticamente a tiros para que sus cuerpos desnudos cayeran cuesta abajo en una enorme fosa com&uacute;n y an&oacute;nima.</p>\n\n<blockquote>\n<p>Fue la primera gran matanza de jud&iacute;os publicitada desde que empez&oacute; la ofensiva sobre la URSS</p>\n</blockquote>\n\n<p>Esta no fue la primera ni la &uacute;ltima masacre perpetrada por los nazis en Europa del Este, pero si fue &quot;<strong>la primera gran matanza de jud&iacute;os publicitada</strong>&nbsp;desde que empez&oacute; la ofensiva sobre la URSS, en junio de 1941&quot;, explica a RTVE.es&nbsp;<strong>Francesc Vilanova</strong>, director del Departamento de Historia Moderna y Contempor&aacute;nea de la Universitat Aut&ograve;noma de Barcelona. &quot;Puso sobre la mesa la pr&aacute;ctica criminal usual, que ser&aacute; habitual en el espacio sovi&eacute;tico, de las&nbsp;<strong>matanzas continuas de poblaci&oacute;n jud&iacute;a</strong>&quot;, a&ntilde;ade.&nbsp;</p>\n\n<p>Su impacto hist&oacute;rico es mayor a&uacute;n porque&nbsp;<strong>los nazis tomaron fotograf&iacute;as</strong>&nbsp;para documentar el exterminio.&nbsp;</p>\n\n<p>Para Vilanova, &quot;Babi Yar es la piedra angular a partir de la cual se pueden explicar y vincular el resto de grandes episodios&quot; ocurridos en los pa&iacute;ses b&aacute;lticos, Polonia o la URSS.&nbsp;</p>\n\n<p>Solo en Ucrania,&nbsp;<strong>los nazis mataron al menos a 1,5 millones de jud&iacute;os</strong>, una cuarta parte de todas las v&iacute;ctimas del Holocausto en Europa, seg&uacute;n datos del gobierno ucraniano.&nbsp;</p>\n\n<p>@@MEDIA[5950760,v]</p>\n\n<p>Algunos de los miembros de los escuadrones de la muerte que participaron en la matanza fueron posteriormente juzgados por este y otros cr&iacute;menes contra la humanidad, entre ellos&nbsp;<strong>Paul Bloble</strong>, comandante de inteligencia de las SS, ejecutado en 1951. Otros responsables del exterminio escaparon a cualquier persecuci&oacute;n judicial.&nbsp;</p>\n\n<h2 class=\"ladillo\">Una memoria dif&iacute;cil&nbsp;</h2>\n\n<p>Babi Yar se ha convertido en un s&iacute;mbolo de la brutalidad de los nazis&nbsp;y en un episodio clave en la memoria del Holocausto. As&iacute; se representa, por ejemplo, en el&nbsp;<a href=\"https://www.yadvashem.org/education/educational-materials/learning-environment/babi-yar/historical-background3.html\" target=\"_blank\">Museo Yad Vashem</a>, en Jerusal&eacute;n. Sin embargo, esta memoria no est&aacute; exenta de conflicto en los pa&iacute;ses donde sucedieron los hechos.&nbsp;</p>\n\n<p>&quot;En los pa&iacute;ses de la antigua &oacute;rbita sovi&eacute;tica, la&nbsp;<strong>memoria del exterminio nazi de la poblaci&oacute;n jud&iacute;a</strong>, as&iacute; como de poblaci&oacute;n ucraniana, polaca o rusa,&nbsp;<strong>ha quedado en parte oculta o diluida</strong>&nbsp;en otro estrato memorial&iacute;stico, que es la&nbsp;<strong>memoria de la dominaci&oacute;n sovi&eacute;tica</strong>&quot;, explica Vilanova. &quot;No se ha perdido, pero se ha tergiversado&quot;&nbsp;para minimizar la participaci&oacute;n de los colaboracionistas locales.&nbsp;</p>\n\n<p>El profesor pone como ejemplo la&nbsp;<a href=\"https://www.rtve.es/noticias/20180201/polonia-prohibira-ley-referencia-campos-concentracion-polacos/1671142.shtml\" target=\"_blank\">ley polaca que criminaliza a quienes se atreven a sugerir la colaboraci&oacute;n de los polacos</a>&nbsp;con la ocupaci&oacute;n y el exterminio, y que ha causado&nbsp;<a href=\"https://www.rtve.es/noticias/20210209/polonia-dos-historiadores-disculparse-denunciar-complicidad-alcalde-nazis/2074622.shtml\" target=\"_blank\">indignaci&oacute;n entre los historiadores</a>.&nbsp;</p>\n\n<p>@@NOTICIA[2074622,IMAGEN]</p>\n\n<p>La&nbsp;familia de&nbsp;Polina Dudchenko ocult&oacute; su identidad jud&iacute;a durante la ocupaci&oacute;n alemana e incluso una vez terminada la guerra, y ahora la est&aacute;&nbsp;redescubriendo. Esta nieta de supervivientes subraya la necesidad de no olvidar a las v&iacute;ctimas.&nbsp;&quot;Necesitamos recordarlas, porque&nbsp;<strong>si no lo hacemos esas atrocidades pueden repetirse</strong>&quot;, advierte.</p>\n",
        "refreshSeconds": 0,
        "sign": {
          "ctvId": null,
          "name": null,
          "firma": "RTVE.es",
          "photo": null,
          "twitter": null,
          "facebook": null,
          "otras": null,
          "publicationDate": null,
          "numPublications": null,
          "instagram": null
        },
        "pubState": {
          "code": "ENPUB",
          "description": "En publicación"
        },
        "mainCategory": "Noticias/Mundo/Europa/Ucrania",
        "mainCategoryLang": "Noticias/Mundo/Europa/Ucrania",
        "otherTopicsName": [
          "Tags Libres/Historia",
          "Tags Libres/Judaísmo",
          "Tags Libres/Holocausto",
          "Tags Libres/Nazis"
        ],
        "otherTopicsRef": "http://www.rtve.es/api/noticias/2178884/tematicas",
        "newsRelatedRef": "http://www.rtve.es/api/noticias/2178884/noticias/relacionados",
        "newsEspecialesRef": "http://www.rtve.es/api/noticias/2178884/noticias/especiales",
        "multimediaRelatedRef": "http://www.rtve.es/api/noticias/2178884/multimedias/relacionados",
        "multimediaTotemRef": "http://www.rtve.es/api/noticias/2178884/multimedias/totem",
        "multimediaDestacadoRef": "http://www.rtve.es/api/noticias/2178884/multimedias/destacado",
        "links": {
          "galeriasRelacionadasRef": "http://www.rtve.es/api/noticias/2178884/galerias/relacionadas",
          "galeriasTotemRef": "http://www.rtve.es/api/noticias/2178884/galerias/totem",
          "encuestaDestacadaRef": "http://www.rtve.es/api/noticias/2178884/encuestas/destacada",
          "encuestasRelacionadasRef": "http://www.rtve.es/api/noticias/2178884/encuestas/relacionadas",
          "encuestasTotemRef": "http://www.rtve.es/api/noticias/2178884/encuestas/totem",
          "comentariosRef": "http://www.rtve.es/api/noticias/2178884/comentarios",
          "tagsRef": "http://www.rtve.es/api/noticias/2178884/tags",
          "estadisticasRef": "http://www.rtve.es/api/noticias/2178884/estadisticas"
        },
        "commentOptions": null,
        "rightModule": null,
        "relatedByLangRef": "http://www.rtve.es/api/noticias/2178884/relacionados/relacionados-por-idioma",
        "generos": [
          {
            "generoInf": "Información y actualidad",
            "generoInfUid": "GE_INFOR",
            "generoId": "136528",
            "subGeneroInfUid": null,
            "subGeneroInf": null,
            "subGeneroId": null
          }
        ],
        "title": "Babi Yar, el barranco donde los nazis mataron a 34.000 judíos "
      }
    ],
    "number": 1,
    "size": 20,
    "offset": 0,
    "total": 379168,
    "totalPages": 18959,
    "numElements": 20
  }
}


