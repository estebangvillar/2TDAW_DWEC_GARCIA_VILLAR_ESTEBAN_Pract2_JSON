"use strict"
const mostrarplato=(plato)=>{
    return `<div class="item">
                <h1>${plato["nombre"]}</h1>
                <p>${plato["descripcion"]}</p>
                <h2>${plato["precio"]}€,
                    ${plato["calorias"]} cal</h2>
                <img src="${plato["imagen"]}">
                </div>`;                                    
}

const mostrarplato1=(plato)=>{
    document.write(`<div class="item">
                <h1>${plato["nombre"]}</h1>
                <p>${plato["descripcion"]}</p>
                <h2>${plato["precio"]}€,
                    ${plato["calorias"]} cal</h2>
                <img src="${plato["imagen"]}">
                </div>`);                                    
}

// for(let i=0;i<menu.length;i++){
//     document.write(mostrarplato(menu[i]));
// }

// for(let plato of menu){
//     document.write(mostrarplato(plato));
// }

const mostrarForeach=(plato)=>{
    document.write(mostrarplato(plato));
}

// menu.forEach(mostrarForeach);
// menu.forEach(mostrarplato1);    

// let precio=parseFloat(prompt("A partir de que precio?"));

// let filtrado=menu.filter(
//     (plato)=>{
//         return plato["precio"]>precio;
//         //return plato["nombre"].toUpperCase().includes("CHO");
//     }
// )
// filtrado.sort(
//     (a,b)=>{
//         //return b["precio"]-a["precio"];
//         return a["nombre"].localeCompare(b["nombre"]);
//     }
// )

// //filtrado.forEach(mostrarForeach);

let busqueda=prompt("Que quieres comer");

let buscado=menu.find(
    (plato)=>{
        return plato["nombre"].toUpperCase()
         .includes(busqueda.toUpperCase());
    }
)

if(buscado===undefined){
    document.write("No tenemos de eso");
}else{
    document.write(mostrarplato(buscado));
}

busqueda=prompt("Que quieres comer");

let filtrado=menu.filter(
    (plato)=>{
        return plato["nombre"].toUpperCase()
                              .includes(busqueda
                                        .toUpperCase());
    }
)

filtrado.forEach(mostrarForeach);

